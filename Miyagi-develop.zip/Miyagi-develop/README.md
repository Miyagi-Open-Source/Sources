<img src="./static/miyagi-logo.svg" width="64" height="64" alt="" />

# Miyagi

- using Node 16 and pnpm 7

## Developing

You need an .env.development to build the app for development.

- installed dependencies: `pnpm install`

- start a development server: `pnpm dev`

- start Histoire (stories): `pnpm story:dev`

- format code: `pnpm format`

- lint code: `pnpm lint`

- run svelte-check : `pnpm check`

## Building

You need an .env to build the app for production.

- build production version of Miyagi: `pnpm build`

- preview production version of Miyagi: `pnpm preview`

## Testing

An .env and .env.development file is required.

You need to install playwright once: `npx playwright install`

- run unit test (watching for file changes): `pnpm vitest`

- run e2e tests: `pnpm playwright`

- run all tests (once): `pnpm test`

# Conventions

- When a component reaches ten levels of indentation, you should consider splitting it up into multiple smaller components.
