import adapter from '@sveltejs/adapter-cloudflare';
import preprocess from 'svelte-preprocess';

/** @type {import('@sveltejs/kit').Config} */
const config = {
	vitePlugin: {
		experimental: {
			inspector: {
				// default for windows and best for linux is 'control-shift'
				// https://github.com/sveltejs/vite-plugin-svelte/pull/555
				// toggleKeyCombo: 'control-shift',
				holdMode: true,
			},
		},
	},
	preprocess: [
		preprocess({
			typescript: true,
			postcss: true,
			sourceMap: true,
		}),
	],
	kit: {
		adapter: adapter(),
		alias: {
			$components: './src/components',
			$types: './src/types',
			$lib: './src/lib',
		},
		files: {
			hooks: {
				server: 'src/hooks/hooks.server.ts',
				client: 'src/hooks/hooks.client.ts',
			},
		},
	},
};

export default config;
