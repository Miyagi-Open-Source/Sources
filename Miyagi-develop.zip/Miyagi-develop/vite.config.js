import { sveltekit } from '@sveltejs/kit/vite';
import Icons from 'unplugin-icons/vite';

// FIXME: there is no dependency @supabase/postgrest-js in package.json \o/
const INLINE_DEPS = ['date-fns', '@supabase/postgrest-js'];

/** @type {import('vite').UserConfig} */
const config = {
	plugins: [
		sveltekit(),
		Icons({
			compiler: 'svelte',
		}),
	],
	test: {
		setupFiles: './vitest/setup.ts',
		environment: 'jsdom',
		reporters: ['default', 'junit'],
		outputFile: 'reports/vitest.junit.xml',
		exclude: ['**/e2e/**', '**/node_modules/**', '**/dist/**', '**/cypress/**', '**/.{idea,git,cache,output,temp}/**'],
		deps: {
			inline: INLINE_DEPS,
		},
	},
	server: {
		watch: {
			usePolling: true,
		},
		// port: 3000,
	},
};

export default config;
