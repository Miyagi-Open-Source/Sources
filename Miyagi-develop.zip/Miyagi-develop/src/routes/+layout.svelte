<script lang="ts">
	import '$lib/stores/organization'; // prevent cyclic dependencies
	import '$lib/db/auth';

	import { dev } from '$app/environment';
	import DialogFunction2 from '$components/dialog/dialog-function/dialog-function.svelte';
	import FeedbackFab from '$components/layout/feedback-fab';
	import Header from '$components/layout/header';
	import LoginSignup from '$components/login/login-signup.svelte';
	import { page } from '$app/stores';
	import '../global.css';

	import { invalidate } from '$app/navigation';
	import { onMount } from 'svelte';
	import { supabase } from '$lib/db';

	onMount(() => {
		const {
			data: { subscription },
		} = supabase.auth.onAuthStateChange(() => invalidate('supabase:auth'));

		return subscription.unsubscribe;
	});
</script>

<svelte:head>
	{#if dev}
		<title>Miyagi — DEV</title>
	{/if}
</svelte:head>

<a class="skip-main" href="#main">Skip to main content</a>

<DialogFunction2 />
{#if $page.data.session}
	<Header />
	<main id="main">
		<slot />
	</main>
{:else}
	<LoginSignup />
{/if}

<footer>
	<!-- <a href="/known-bugs">Known Bugs</a> -->
	{#if $page.params.organization && $page.params.project}
		<a href="./settings">Project Settings</a>
	{:else}
		&nbsp;
	{/if}
	<!-- if the page url is /licences don't show this link -->
	{#if $page.route.id !== '/licenses'}
		<a href="/licenses">Licenses</a>
	{/if}
</footer>
<FeedbackFab />

<style lang="postcss">
	main {
		flex-direction: column;
		margin-block: var(--size-3);

		/* margin-bottom: var(--size-3); */
		padding-inline: var(--size-7);
	}

	a.skip-main {
		position: absolute;
		top: 0;
		left: 0;
		overflow: hidden;
		width: 0;
		height: 0;
	}

	a.skip-main:focus,
	a.skip-main:active {
		z-index: 999;
		width: auto;
		height: auto;
		border-radius: var(--radius-2);
		padding-block: var(--size-3);
		padding-inline: var(--size-5);
		background-color: var(--surface-1);
		color: var(--text-1);
		font-weight: var(--font-weight-6);
	}

	footer {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		margin-top: auto;
		padding: var(--size-3) var(--size-5);
		background-color: var(--gray-9); /* changed the color to a more muted blue */
		color: #ffffff;
	}

	footer a {
		width: fit-content;
		color: #ffffff;
		font-weight: bold;
		text-decoration: none;
		transition: color 0.2s;
	}

	footer a:hover {
		color: #cccccc;
	}
</style>
