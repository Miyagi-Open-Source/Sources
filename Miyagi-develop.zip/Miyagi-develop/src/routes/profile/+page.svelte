<script lang="ts">
	import IcEdit from '~icons/ic/round-edit';
	import IcUpload from '~icons/ic/round-upload';
	import Button from '$components/button/button.svelte';
	import clickOutside from '$lib/actions/click-outside';
	import { signOut, userStore } from '$lib/db/auth';
	import { supabase } from '$lib/db';
	import { GET, resizeImage } from '$lib/helper';
	import Avatar from '$components/avatar/avatar.svelte';
	import { dialog } from '$components/dialog/dialog-function/dialog-function';
	import { organizations } from '$lib/stores';
	import type { Member } from '$types/member';

	let name = 'getting name...';
	let email = 'getting email...';
	let password = '';
	let passwordConfirm = '';
	let isEditingName = false;
	let isEditingEmail = false;
	let isEditingPassword = false;

	let files: FileList;

	const setName = () => $userStore?.username && (name = $userStore?.username);
	$: $userStore?.username, setName();

	const setEmail = () => $userStore?.email && (email = $userStore?.email);
	$: $userStore?.email, setEmail();

	let passwordEL: HTMLInputElement;
	let passwordConfirmEL: HTMLInputElement;

	const deleteAccount = async () => {
		const userId = $userStore?.id;
		if (!userId) return;

		const usersOrganization = $organizations.find((org) => org.owner === userId)!;

		let confirmString: string | null = null;
		let newOwner: Member | null = null;

		const possibleNewOwners = usersOrganization.projects
			.flatMap((project) => project.members)
			.filter((member) => member.id !== userId)
			.filter((a, i, self) => self.findIndex((b) => b.id === a.id) === i);

		if (possibleNewOwners.length) {
			[newOwner, confirmString] = await dialog(
				'Delete Account',
				[
					{
						label: `new owner`,
						input: 'user',
						users: usersOrganization.projects
							.flatMap((project) => project.members)
							.filter((member) => member.id !== userId)
							.filter((a, i, self) => self.findIndex((b) => b.id === a.id) === i),
					},
					{
						label: "type 'delete' to confirm",
						input: 'string',
					},
				] as const,
				{
					message: `Are you sure you want to delete your account? This action cannot be undone.
Your organization has ${usersOrganization.projects.length} projects. You can choose to transfer ownership of these projects to another user.`,
					cancel: true,
					confirmLabel: 'Delete Account',
				}
			);
		} else {
			[confirmString] = await dialog(
				'Delete Account',
				[
					{
						label: "type 'delete' to confirm",
						input: 'string',
					},
				] as const,
				{
					message: 'Are you sure you want to delete your account? This action cannot be undone.',
					cancel: true,
					confirmLabel: 'Delete Account',
				}
			);
		}

		if (confirmString !== 'delete')
			return dialog('Delete Canceled', {
				cancel: false,
				confirmLabel: 'Ok',
			});

		const { error } = await GET({
			action: 'deleteUser',
			userId,
			newOwnerId: newOwner?.id,
		});

		if (error)
			return dialog('Error', {
				message:
					'There was an error deleting your account. Some data might be corrupted, please contact support. Error: ' +
					error.message,
				cancel: false,
			});

		signOut();
	};

	const saveName = async () => {
		toggleEditName();
		userStore.update((user) => {
			if (user) user.username = name;
			return user;
		});
		await supabase.from('profiles').update({ username: name }).match({ id: $userStore?.id });
	};

	const saveEmail = async () => {
		toggleEditEmail();
		await supabase.auth.updateUser({ email });
	};

	const savePassword = async () => {
		if (password == '') {
			passwordEL.setCustomValidity('The password must not be empty');
			return;
		}
		validatePassword();
		// const { data, error } =
		await supabase.auth.updateUser({ password });
		toggleEditPassword();
	};

	const toggleEditName = () => {
		isEditingName = !isEditingName;
	};

	const toggleEditEmail = () => {
		isEditingEmail = !isEditingEmail;
	};

	const toggleEditPassword = () => {
		isEditingPassword = !isEditingPassword;
		password = '';
		passwordConfirm = '';
	};

	const validatePassword = () => {
		if (password !== passwordConfirm) {
			passwordEL.setCustomValidity('The passwords do not match');
			passwordConfirmEL.setCustomValidity('The passwords do not match');
		} else if (password.length < 8) {
			passwordEL.setCustomValidity('The password must be at least 8 characters long');
			passwordConfirmEL.setCustomValidity('The password must be at least 8 characters long');
		} else {
			passwordEL.setCustomValidity('');
			passwordConfirmEL.setCustomValidity('');
		}
	};

	const avatarBasePath = `${import.meta.env.VITE_SUPABASE_URL}/storage/v1/object/public/avatars/`;

	const onFileSelected = async () => {
		const [imageFile] = files;

		const resizedImageFile = await resizeImage(imageFile, 64, 64);

		const { data, error } = await supabase.storage
			.from('avatars')
			.upload(`avatar-${$userStore?.id}`, resizedImageFile, {
				cacheControl: '3600',
				upsert: true,
			});

		if (error) throw error;

		const newPath = `${avatarBasePath}${data.path}?${crypto.randomUUID().substring(0, 3)}`; // prevent image from being cached
		const { error: error2 } = await supabase
			.from('profiles')
			.update({ avatarUrl: newPath })
			.match({ id: $userStore?.id });

		if (error2) throw error2;

		userStore!.update((user) => {
			user!.avatarUrl = newPath;
			return user;
		});
	};

	// debug userStore subscription
	// const unsubscribe = userStore!.subscribe((user) => {
	// 	if (user) {
	// 		console.log('userStore changed', user, user?.app_metadata?.provider);
	// 	}
	// });

	$: emailAuth = $userStore?.app_metadata?.provider === 'email';
</script>

<h1>Profile</h1>

<p>Logged in via {$userStore?.app_metadata?.provider}</p>

<div class="sections">
	<div class="left">
		<label
			>Name:
			<form
				class="group"
				use:clickOutside={{
					enabled: isEditingName,
					func: toggleEditName,
				}}
			>
				{#if isEditingName}
					<input
						type="text"
						bind:value={name}
						on:keyup={(event) => event.key === 'Enter' && saveName()}
						minlength={1}
					/>
					<Button on:mouseup={saveName} variant="primary">Save</Button>
				{:else}
					<p>{name}</p>
					<Button on:mouseup={toggleEditName}><IcEdit /></Button>
				{/if}
			</form>
		</label>

		<label
			>Email:
			<form
				class="group"
				use:clickOutside={{
					enabled: isEditingEmail,
					func: toggleEditEmail,
				}}
			>
				{#if isEditingEmail}
					<input type="email" bind:value={email} on:keyup={(event) => event.key === 'Enter' && saveEmail()} />
					<Button on:mouseup={saveEmail} variant="primary">Save</Button>
				{:else}
					<p>{email}</p>
					<Button on:mouseup={toggleEditEmail}><IcEdit /></Button>
				{/if}
			</form>
		</label>

		{#if emailAuth}
			<label
				>Password:
				<form
					class="group"
					on:submit|preventDefault={() => {
						savePassword();
					}}
					use:clickOutside={{
						enabled: isEditingPassword,
						func: toggleEditPassword,
					}}
				>
					{#if isEditingPassword}
						<input type="text" hidden value={$userStore} autocomplete="username" />
						<!-- svelte-ignore a11y-autofocus -->
						<input
							type="password"
							autocomplete="new-password"
							bind:this={passwordEL}
							bind:value={password}
							on:input={validatePassword}
							minlength="8"
							autofocus
						/>
						<input
							type="password"
							autocomplete="new-password"
							bind:this={passwordConfirmEL}
							bind:value={passwordConfirm}
							on:input={validatePassword}
							minlength="8"
						/>
						<Button type="submit" variant="primary">Save</Button>
						<Button type="button" on:mouseup={toggleEditPassword}>Cancel</Button>
					{:else}
						<p>********</p>
						<Button
							on:mouseup={toggleEditPassword}
							disabled={$userStore?.app_metadata?.provider !== 'email'}
							title="you can only change your password if you are logged in via email"><IcEdit /></Button
						>
					{/if}
				</form>
			</label>
		{/if}

		<Button on:click={deleteAccount} variant="warn">Delete Account</Button>
	</div>
	<div class="right">
		<div class="image-card">
			<Avatar size="large" profile={$userStore} />
			<label>
				<span class="upload-image">Upload Image <IcUpload /></span>
				<input type="file" accept=".jpg, .jpeg, .png, .webp" bind:files on:change={onFileSelected} />
			</label>
		</div>
	</div>
</div>

<style lang="postcss">
	input {
		border: none;
		padding: 8px;
		background-color: #333333;
		color: white;
		font-size: 16px;
	}

	input:focus {
		outline: none;
	}

	label {
		display: flex;
		flex-direction: column;
		align-items: flex-start;
		justify-content: flex-start;
		margin-block: var(--size-4);
	}

	.group {
		display: flex;
		flex-direction: row;
		align-items: center;
		gap: var(--size-2);
	}

	p {
		text-align: left;
	}

	.sections {
		display: grid;
		grid-template-columns: 1fr 1fr;
	}

	.image-card {
		display: flex;
		align-items: center;
		gap: var(--size-5);
		border-radius: var(--size-2);
		padding: var(--size-5);
		background-color: var(--surface-1);
	}

	input[type='file'] {
		display: none;
	}

	.upload-image {
		border: var(--border-size-2) dashed var(--surface-3);
		border-radius: var(--size-1);
		padding: var(--size-2);
		font-size: var(--font-size-2);
		transition: background-color 0.1s var(--ease-in-out-3);

		&:hover {
			background-color: var(--surface-2);
			cursor: pointer;
		}
	}

	span {
		display: flex;
		gap: var(--size-2);
	}
</style>
