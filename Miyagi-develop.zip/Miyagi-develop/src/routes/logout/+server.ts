import { error, redirect } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { getSupabase } from '@supabase/auth-helpers-sveltekit';

export const POST: RequestHandler = async (event) => {
	const { supabaseClient } = await getSupabase(event);
	const { error: err } = await supabaseClient.auth.signOut();

	if (err) {
		throw error(500, err.message);
	}

	throw redirect(303, '/');
};
