import type { PageServerLoad } from './$types';
import licenses from '$lib/licenses/licenses.json';

export const load: PageServerLoad = async () => {
	const licenseList = Object.entries(licenses).map(([key, license]) => {
		const [name, version] = key.split(/@(?=[^@]*$)/);

		return {
			name,
			version,
			publisher: '',
			...license,
		};
	});

	return {
		status: 200,
		licenseList,
	};
};
