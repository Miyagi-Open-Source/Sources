<script lang="ts">
	import type { PageData } from './$types';
	import { createSearchStore, searchHandler } from '$lib/stores/search';
	import { onDestroy } from 'svelte';
	import { slide } from 'svelte/transition';

	export let data: PageData;

	const searchLicenses = data.licenseList.map((license) => ({
		...license,
		searchTerms: `${license.name} ${license.licenses} ${license.publisher}`,
	}));

	const searchStore = createSearchStore(searchLicenses);

	const unsubscribe = searchStore.subscribe(searchHandler);
	onDestroy(unsubscribe);

	const fixUrl = (url: string) => {
		if (url.startsWith('@')) {
			return 'https://www.twitter.com/' + url.slice(1);
		}
		if (!url.startsWith('http')) {
			return 'https://' + url;
		}
		return url;
	};
</script>

<div class="container">
	<h2>Miyagi is made with ❤️ and {data.licenseList.length} libs</h2>
	<h2>Search:</h2>
	<input type="search" bind:value={$searchStore.search} placeholder="Search..." />
</div>

<div class="wrapper">
	<ul>
		{#each $searchStore.filtered as license (license.name)}
			<li transition:slide|local>
				{#if 'repository' in license}
					<a href={license.repository} title={'version: ' + license.version} target="_blank" rel="noopener noreferrer">
						{license.name} - {license.licenses}
					</a>
				{:else}
					{license.name} - {license.licenses}
				{/if}
				{#if license.publisher}
					by {license.publisher}
				{/if}
				{#if 'url' in license}
					<a href={fixUrl(license.url)} target="_blank" rel="noopener noreferrer">
						{license.url}
					</a>
				{/if}
			</li>
		{/each}
	</ul>
</div>

<style>
	.container {
		display: flex;
		flex-direction: column;
		align-items: center;
		margin-bottom: 1rem;
	}

	li {
		max-inline-size: initial;
	}

	h2 {
		margin-bottom: 0.5rem;
	}
</style>
