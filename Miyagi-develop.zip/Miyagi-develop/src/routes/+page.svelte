<script lang="ts">
	import { goto } from '$app/navigation';
	import Button from '$components/button';
	import IcRoundAdd from '~icons/ic/round-add';
	import IcRoundSettings from '~icons/ic/round-settings';
	import ArrowButton from '$components/arrow-button';
	import { organizations } from '$lib/stores';
	import { userStore } from '$lib/db/auth';
	import { dialog } from '$components/dialog/dialog-function/dialog-function';
	import TextInplaceEdit from '$components/inline-edit';

	$: $organizations.forEach((org) => org.projects.sort((a, b) => Date.parse(a.createdAt) - Date.parse(b.createdAt)));

	const submitOrganizationName = (uuid: string) => {
		return ({ detail: newValue }) => {
			let organization = $organizations.find((org) => org.id === uuid);
			if (organization) {
				organization.update({ name: newValue });
			}
		};
	};
</script>

<div class="wrap">
	<h2>Product Overview</h2>
	{#each $organizations ?? [] as organization}
		{#if organization.owner === $userStore?.id}
			<h4>
				<TextInplaceEdit
					required={true}
					value={organization.name}
					on:submit={submitOrganizationName(organization.id)}
					minLength={1}
				/>
			</h4>
		{:else}
			<h4>{organization.name}</h4>
		{/if}
		<section>
			{#each organization.projects as project}
				<a class="project-card" href={`/${organization.id}/${project.id}/backlog`}>
					<h3>{project.name}</h3>
					<p>{project.vision ?? ''}&nbsp;</p>
					<div class="buttons">
						<ArrowButton forward>Go to Backlog</ArrowButton>

						<Button variant="regular" href={`/${organization.id}/${project.id}/settings`}>
							<svelte:fragment><IcRoundSettings /></svelte:fragment>
						</Button>
					</div>
				</a>
			{/each}

			{#if organization.projects.length < 3 && organization.owner === $userStore?.id}
				<button
					class="project-card new-card"
					on:click={async () => {
						const [name] = await dialog('New Product Name', [
							{
								input: 'string',
							},
						]);
						if (name) {
							const project = await organization.createProject({ name });
							goto(`/${organization.id}/${project.id}/backlog`);
						}
					}}
				>
					<!-- <Button> -->
					<span class="plus"><IcRoundAdd /></span>
					<span class="add">New Product</span>
					<!-- </Button> -->
				</button>
			{/if}
		</section>
		<br />
		<details>
			Hey
			<summary />
		</details>
	{/each}
</div>

<style>
	.wrap {
		padding-block: var(--size-3);
	}

	h4 {
		margin-top: var(--size-4);
	}

	section {
		display: grid;
		grid-template-columns: repeat(1, minmax(0, 1fr));
		gap: var(--size-5);
		margin-top: var(--size-2);
	}

	@media (min-width: 1024px) {
		section {
			grid-template-columns: repeat(2, minmax(0, 1fr));
		}
	}

	@media (min-width: 1280px) {
		section {
			grid-template-columns: repeat(3, minmax(0, 1fr));
		}
	}

	.project-card {
		border-radius: var(--size-1);
		padding: var(--size-3);
		box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1);
		background-color: var(--surface-2);
		box-sizing: border-box;
	}

	.buttons {
		display: flex;
		justify-content: space-between;
		margin-top: var(--size-4);
	}

	.new-card {
		display: flex;
		align-items: center;
		justify-content: center;
		gap: var(--size-4);
		min-height: var(--size-10);
		border: 1px dashed var(--surface-2);
		background-color: transparent;
		font-size: var(--size-4);
	}

	.plus {
		border-radius: 100%;
		padding: var(--size-2);
		background-color: var(--surface-2);
	}

	.add {
		color: var(--text-1);
	}

	a {
		margin: 0;
		text-decoration: inherit;
		cursor: initial;
		-webkit-tap-highlight-color: initial;
		touch-action: initial;
	}
</style>
