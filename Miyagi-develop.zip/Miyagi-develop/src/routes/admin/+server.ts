import { supabaseAdmin } from '$lib/db';
import { sub } from 'date-fns';
import type { RequestHandler } from './$types';
import { getSupabase } from '@supabase/auth-helpers-sveltekit';

const types = [
	'TASK_MOVE',
	'TASK_COUNT',
	'STORY_COUNT',
	'SPRINT_COUNT',
	'PROJECT_COUNT',
	'USER_COUNT',
	'INVITE_COUNT',
	'INVITE_CODE_COUNT',
];

const getGraphs = (from: Date, to: Date) =>
	Promise.all(
		types.map(
			async (type) =>
				[
					type,
					await supabaseAdmin
						.from('event')
						.select('date, count, t')
						.match({ type })
						.gte('date', from.toISOString())
						.lte('date', to.toISOString())
						.select()
						.then(({ data }) => data),
				] as const
		)
	);

const getFeedback = (from: Date, to: Date) =>
	supabaseAdmin
		.from('user-feedback')
		.select('*')
		.gte('created_at', from.toISOString())
		.lte('created_at', to.toISOString())
		.select()
		.then(({ data, error }) => {
			if (error) console.error(error);
			return data!;
		});

const admins = [
	'3c604257-***-4c99-a99a-cfc70f33cb50',
	'17fbc399-***-4c30-8351-d76ce312c645',
	'79f660d6-***-42a1-b947-ba07c1864c77',
	'57b3c13a-***-4245-bb10-71ed1e1a977b', // Tim Dev
	'636b3e74-***-479e-adbd-b2345b862176', // Kosta Dev
	'f30ca189-***-4515-a02f-37fdc3e6c6c9', // Kosta Prod
];

export const GET: RequestHandler = async (event) => {
	const {
		url: { searchParams },
	} = event;
	const { session } = await getSupabase(event);

	if (session?.user?.id && !admins.includes(session?.user?.id))
		return new Response(JSON.stringify({ error: 'Not authorized' }), { status: 401 });

	const to = searchParams.get('to') ? new Date(searchParams.get('to')!) : new Date();
	const from = searchParams.get('from') ? new Date(searchParams.get('from')!) : sub(to, { days: 1 });

	return new Response(
		JSON.stringify({
			graphs: await getGraphs(from, to),
			feedback: await getFeedback(from, to),
		})
	);
};

export type DashboardData = {
	graphs: Awaited<ReturnType<typeof getGraphs>>;
	feedback: Awaited<ReturnType<typeof getFeedback>>;
};
