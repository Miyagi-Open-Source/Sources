<script lang="ts">
	import { onMount } from 'svelte';
	import type { DashboardData } from './+server';
	import { differenceInHours, sub, add } from 'date-fns';
	import Chart from 'svelte-frappe-charts';
	import { browser } from '$app/environment';
	import Button from '$components/button';

	let to: string = new Date().toLocaleString('sv-SE');
	let from: string = sub(new Date(to), { days: 1 }).toLocaleString('sv-SE');

	let updateEvery = 10;
	let autoUpdate = true;
	// eslint-disable-next-line
	let interval: number;

	// eslint-disable-next-line
	const goBack = (duration: Duration) => {
		from = sub(new Date(from), duration).toLocaleString('sv-SE');
		to = sub(new Date(to), duration).toLocaleString('sv-SE');
	};

	// eslint-disable-next-line
	const goForward = (duration: Duration) => {
		from = add(new Date(from), duration).toLocaleString('sv-SE');
		to = add(new Date(to), duration).toLocaleString('sv-SE');
	};

	let entries: {
		type: string;
		data: {
			labels: (string | number)[];
			datasets: {
				name: string;
				values: number[];
			}[];
		};
	}[] = [];

	let feedback: DashboardData['feedback'] = [];

	const updateGraphs = async () => {
		if (!browser || from > to) return;

		const response = await fetch(
			window.location.href +
				'?' +
				new URLSearchParams({
					from: new Date(from).toISOString(),
					to: new Date(to).toISOString(),
				})
		);
		const { graphs, feedback: _feedback } = await (response.json() as Promise<DashboardData>);
		feedback = _feedback;

		const duration = differenceInHours(new Date(to), new Date(from));

		const stepScale = Math.floor(duration / 24);
		const filter = (_: unknown, i: number) => i % stepScale === 0;

		entries = graphs.map(([type, data]) => {
			const hours: number[] = new Array(duration).fill(-1);
			data?.forEach(({ date, count }) => {
				const hoursAfterStart = differenceInHours(new Date(date), new Date(from));
				hours[hoursAfterStart] = count!;
			});

			let curCount = 0;
			hours.forEach((hour, i) => {
				if (hour === -1) {
					hours[i] = curCount;
				} else {
					curCount = hour;
				}
			});

			if (data?.length) hours.push(data.reduce((a, b) => (new Date(a.date) > new Date(b.date) ? a : b)).count!);

			return {
				type,
				data: {
					labels: hours.map((_, hours) => add(new Date(from), { hours }).toLocaleString()).filter(filter),
					datasets: [
						{
							name: type,
							values: hours.filter(filter),
						},
					],
				},
			};
		});
	};

	$: to, from, updateGraphs();

	$: updateEvery, updateUpdateEvery();

	const updateUpdateEvery = () => {
		if (!browser) return;

		updateGraphs();
		clearInterval(interval);
		interval = window.setInterval(
			() => browser && !document.hidden && autoUpdate && updateGraphs(),
			updateEvery * 1000
		);
	};

	onMount(updateUpdateEvery);
</script>

<div class="settings">
	<div class="settings-row">
		<Button on:click={() => goBack({ days: 1 })}>Previous Day</Button>
		<Button on:click={() => goBack({ hours: 1 })}>Previous Hour</Button>

		<input type="datetime-local" bind:value={from} max={to} />
		<input type="datetime-local" bind:value={to} min={from} />

		<Button on:click={() => goForward({ hours: 1 })}>Next Hour</Button>
		<Button on:click={() => goForward({ days: 1 })}>Next Day</Button>
	</div>
	<div class="settings-row">
		<input type="checkbox" id="autoUpdate" bind:checked={autoUpdate} />
		<label for="autoUpdate">Autoupdate </label>
		<label for="updateEvery">every </label><input
			id="updateEvery"
			type="number"
			min="1"
			bind:value={updateEvery}
		/><label for="updateEvery">&nbsp second{updateEvery === 1 ? '' : 's'}</label>
	</div>
</div>
{#each entries as { type, data }}
	<div class="graph-group">
		<h2>{type}</h2>
		<Chart {data} type="line" height="420" colors={['#74BC10']} axisOptions={{ fill: 'red' }} />
	</div>
{/each}

<h2>Feedback</h2>
{#each feedback as { subject, message, email, created_at }}
	<article class="feedback">
		<h3>{subject}</h3>
		<p>{message}</p>
		<address>
			By <a rel="author" href="mailto:{email}">{email}</a> -
			<time datetime={new Date(created_at).toISOString()}>{new Date(created_at).toLocaleTimeString()}</time>
		</address>
	</article>
{/each}

<style>
	input[type='number'] {
		display: inline;
	}

	.settings {
		position: sticky;
		top: 0;
		z-index: 5;
		display: flex;
		flex-direction: column;
		gap: var(--size-2);
		width: fit-content;
		border-radius: 0 0 var(--size-3) var(--size-3);
		margin-right: auto;

		/* left: 50%; */

		/* transform: translate(-50%, 0); */

		margin-left: auto;
		padding: var(--size-2) var(--size-3);
		background: var(--gray-9);
		box-sizing: border-box;
	}

	.settings-row {
		display: flex;
		align-items: center;
		justify-content: center;
		gap: var(--size-1);
	}

	label {
		color: var(--gray-1);
	}

	input {
		background-color: var(--surface-3);
	}

	.graph-group {
		margin-top: var(--size-7);
	}

	article {
		border-radius: var(--size-3);
		margin-block: var(--size-3);
		padding: var(--size-3);
		background-color: var(--surface-1);
	}
</style>
