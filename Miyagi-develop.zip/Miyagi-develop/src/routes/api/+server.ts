import { supabaseAdmin } from '$lib/db';
import { send } from '$lib/email';
import type { RequestHandler } from './$types';
import { getSupabase } from '@supabase/auth-helpers-sveltekit';
import { noop, without } from '$lib/helper';
import type { UserProjectRoles } from '$types/userProjectRoles';
import type { Db_Profiles } from '$types/db-types';
import { getUsersOwnedOrganizations } from '$lib/db/organization';

const getUserByEmail = async ({ email }: Record<string, string>) => {
	const { data, error } = await supabaseAdmin.from('users').select('id').match({ email });
	if (error) throw error;

	return {
		data: data[0]?.id,
	};
};

// const getWorkspaceIdOfUser = async ({ userId }: Record<string, string>) => {
//     const { data, error } = await supabaseAdmin.from('organization').select('id').match({ owner: userId });
//     if (error) throw error;

//     return {
//         data: data[0],
//     };
// };

const getEmailUsername = async (userId: string) => {
	const { data: data1, error: error1 } = await supabaseAdmin.from('users').select('email').match({ id: userId });
	const { data: data2, error: error2 } = await supabaseAdmin.from('profiles').select('username').match({ id: userId });

	if (error1 || error2) throw error1 || error2;

	const email = data1[0]?.email;
	const username = data2[0]?.username;

	if (!email || !username) throw new Error('Could not find email or username');

	return {
		email,
		username,
	};
};

const getProjectName = async (projectId: string | number) => {
	const { data, error } = await supabaseAdmin.from('project').select('name').match({ id: projectId });

	if (error) throw error;

	const projectName = data[0]?.name;

	if (!projectName) throw new Error(`Could not find project name for ${projectId}`);

	return {
		projectName,
	};
};

const getMembersOfProject = async (projectId: string | number) => {
	const { data, error } = await supabaseAdmin
		.from('userProjectRoles')
		.select('userId')
		.match({ projectId: projectId, accepted: true });
	if (error) throw error;

	return {
		members: data,
	};
};

const informUserOfInviteToProject = async ({ userId, projectId }: Record<string, string>) => {
	const recipient = await getEmailUsername(userId);
	const { projectName } = await getProjectName(projectId);

	return send({
		recipient,
		subject: `You have been invited to join the project "${projectName}"`,
		message: `You have been invited to join the project "${projectName}"`,
	});
};

const informUserOfKickFromProject = async ({ userId, projectId }: Record<string, string>) => {
	const recipient = await getEmailUsername(userId);
	const { projectName } = await getProjectName(projectId);

	return send({
		recipient,
		subject: `You have been removed from the project "${projectName}"`,
		message: `You have been removed from the project "${projectName}"`,
	});
};

const informUsersOfProjectEdit = async ({ projectId, newName, oldName }: Record<string, string>) => {
	const { members } = await getMembersOfProject(projectId);

	const recipients = await Promise.all(members.map(({ userId }) => getEmailUsername(userId)));

	return send({
		recipients,
		subject: `The Project "${oldName}" has been renamed to "${newName}"`,
		message: `The Project "${oldName}" has been renamed to "${newName}"`,
	});
};

const informUsersOfProjectDelete = async ({ projectId }: Record<string, string>) => {
	const { projectName } = await getProjectName(projectId);
	const { members } = await getMembersOfProject(projectId);

	const recipients = await Promise.all(members.map(({ userId }) => getEmailUsername(userId)));

	return send({
		recipients,
		subject: `Project "${projectName}" has been deleted`,
		message: `The project "${projectName}" has been deleted, you are therefore no longer a member of this project`,
	});
};

const deleteProject = async ({ projectId }: Record<string, string>) => {
	const { error } = await supabaseAdmin.from('project').delete().match({ id: projectId });
	if (error) throw error;
};

const createInviteCode = async ({ projectId, code, role, maxUses, endDate }: Record<string, string>) => {
	const { data, error } = await supabaseAdmin.from('inviteCode').insert({
		projectId: projectId,
		code,
		role,
		endDate,
		maxUses: +maxUses,
	});
	if (error) throw error;

	return {
		data,
	};
};

const getDataOfInviteCode = async ({ code }: Record<string, string>) => {
	const { data, error } = await supabaseAdmin.from('inviteCode').select('*').match({ code });
	if (error) throw error;

	const inviteCodeData = data[0];
	if (!inviteCodeData) throw new Error('Could not find invite code');
	if (inviteCodeData.maxUses && inviteCodeData.maxUses <= inviteCodeData.useCount)
		throw new Error('Invite code has no more uses left');
	if (inviteCodeData.endDate && inviteCodeData.endDate <= new Date().toISOString())
		throw new Error('Invite code has expired');

	const { projectName } = await getProjectName(data[0].projectId);

	const codeData = data[0] as (typeof data)[0] & { projectName: string };
	codeData.projectName = projectName;

	return {
		data: codeData,
	};
};

const joinProjectUsingInviteCode = async ({ code, userId }: Record<string, string>) => {
	const { data: inviteCodeData } = await getDataOfInviteCode({ code });

	const { data, error } = await supabaseAdmin
		.from('userProjectRoles')
		.select('*')
		.match({ projectId: inviteCodeData.projectId, userId });
	if (error) throw error;

	if (data.length) {
		throw new Error('User is already a member of this project');
	}

	supabaseAdmin
		.from('userProjectRoles')
		.insert({
			userId,
			projectId: inviteCodeData.projectId,
			role: inviteCodeData.role,
			accepted: true,
		})
		.then(noop);

	supabaseAdmin
		.from('inviteCode')
		.update({
			useCount: inviteCodeData.useCount + 1,
		})
		.match({ code })
		.then(noop);

	return {
		data: {
			projectId: inviteCodeData.projectId,
		},
	};
};

const deleteUser = async ({ userId, newOwnerId }: Record<string, string>) => {
	// get data for email
	const ownerEmailUsername = await getEmailUsername(userId);
	const newOwnerEmailUsername = newOwnerId && (await getEmailUsername(newOwnerId));

	const { data: workspaces, error: cantFindOrganizationError } = await supabaseAdmin
		.from('organization')
		.select('*')
		.match({ owner: userId });
	if (cantFindOrganizationError) throw cantFindOrganizationError;

	const { data: products, error: cantFindProductsError } = await supabaseAdmin
		.from('project')
		.select('*')
		.match({ organizationId: workspaces[0].id });
	if (cantFindProductsError) throw cantFindProductsError;

	const members = (await Promise.all(products.map((product) => getMembersOfProject(product.id))))
		.flatMap(({ members }) => members)
		.filter(({ userId }) => userId !== userId && userId !== newOwnerId);
	const recipients = await Promise.all(members.map(({ userId }) => getEmailUsername(userId)));

	if (newOwnerId) {
		const { data: organizationOfCurrentOwner, error: cantFindOrganizationOfCurrentOwnerError } = await supabaseAdmin
			.from('organization')
			.select('*')
			.match({ owner: userId });
		if (cantFindOrganizationOfCurrentOwnerError) throw cantFindOrganizationOfCurrentOwnerError;

		const { data: organizationOfNewOwner, error: cantFindOrganizationOfNewOwnerError } = await supabaseAdmin
			.from('organization')
			.select('*')
			.match({ owner: newOwnerId });
		if (cantFindOrganizationOfNewOwnerError) throw cantFindOrganizationOfNewOwnerError;

		await supabaseAdmin
			.from('project')
			.update({ organizationId: organizationOfNewOwner[0].id })
			.match({ organizationId: organizationOfCurrentOwner[0].id });
	}
	await supabaseAdmin.from('organization').delete().match({ owner: userId });

	// delete
	const { data, error } = await supabaseAdmin
		.from('assigned_tasks_with_enddate')
		.select('*')
		.match({ assigneeId: userId });
	if (error) throw error;

	await Promise.all([
		...data
			.filter((el) => el.endDate)
			.map(({ id }) =>
				supabaseAdmin.from('task').update({ assigneeId: '00000000-0000-0000-0000-000000000000' }).match({ id })
			),
		...data
			.filter((el) => !el.endDate)
			.map(({ id, status }) =>
				supabaseAdmin
					.from('task')
					.update({ assigneeId: null, status: status === 'done' ? 'done' : 'todo' })
					.match({ id })
			),
	]);

	await supabaseAdmin.from('userProjectRoles').delete().match({ userId: userId });
	await supabaseAdmin.from('profiles').delete().match({ id: userId });

	const { error: authError } = await supabaseAdmin.auth.admin.deleteUser(userId, true);

	// Send Emails
	for (const product of products) {
		send({
			recipients,
			subject: `Product "${product.name}" has ${newOwnerId ? 'been deleted' : 'a new owner'}`,
			message: newOwnerId
				? `The product "${product.name}" has been deleted, you are therefore no longer a member of this product`
				: `The product "${product.name}" has a new owner, ${(await getEmailUsername(newOwnerId)).username}}`,
		});
	}

	send({
		recipient: ownerEmailUsername,
		subject: `Your account has been deleted`,
		message: `Your account ${ownerEmailUsername.username} has been deleted`,
	});

	if (newOwnerEmailUsername) {
		send({
			recipient: newOwnerEmailUsername,
			subject: `You are the new owner of "${products.length}" product${products.length === 1 ? '' : 's'}`,
			message: `${
				ownerEmailUsername.username
			} has delete his account and made you the new owner of his products ${products
				.map((product) => product.name)
				.join(', ')}`,
		});
	}

	return {
		error: authError,
	};
};

const inviteUserUsingEmail = async ({ email, projectId }: Record<string, string>) => {
	const { data: userId } = await getUserByEmail({ email });
	if (!userId) throw new Error('No user with that email has been found');

	const { data: dataExists, error: errorExists } = await supabaseAdmin
		.from('userProjectRoles')
		.select('*')
		.match({ projectId, userId });

	if (errorExists) throw errorExists;
	if (dataExists.length)
		throw new Error(
			dataExists[0].accepted
				? 'User is already a member of this project'
				: 'User has already been invited to this project'
		);

	const { data, error } = await supabaseAdmin
		.from('userProjectRoles')
		.insert({ userId, projectId, role: 'guest' })
		.select('*, profiles(*)');

	if (error) throw error;

	informUserOfInviteToProject({ userId, projectId });
	const _data = data[0] as UserProjectRoles & { profiles: Db_Profiles };
	const userData = Object.assign(without(_data, 'profiles'), _data.profiles);
	return {
		data: userData,
	};
};

const transferProject = async ({ projectId, userId }: Record<string, string>) => {
	const [userOrganization] = await getUsersOwnedOrganizations(userId);

	const { error, count } = await supabaseAdmin
		.from('project')
		.select('*', { count: 'exact', head: true })
		.match({ organizationId: userOrganization.id });
	if (error) throw error;

	if (count! >= 3) throw new Error('User already reached the maximum amount of projects');

	const { data: project, error: projectError } = await supabaseAdmin
		.from('project')
		.select('organizationId')
		.match({ id: projectId });
	if (projectError) throw projectError;

	const { data: oldOwnerOrganization, error: oldOwnerError } = await supabaseAdmin
		.from('organization')
		.select('owner')
		.match({ id: project[0].organizationId });
	if (oldOwnerError) throw oldOwnerError;

	const { error: errorUpdate } = await supabaseAdmin
		.from('project')
		.update({ organizationId: userOrganization.id })
		.match({ id: projectId });
	if (errorUpdate) throw errorUpdate;

	const { error: updateOldOwnerError } = await supabaseAdmin
		.from('userProjectRoles')
		.update({ role: 'admin' })
		.match({ projectId, userId: oldOwnerOrganization[0].owner });
	if (updateOldOwnerError) throw updateOldOwnerError;

	const { error: updateNewOwnerError } = await supabaseAdmin
		.from('userProjectRoles')
		.update({ role: 'owner' })
		.match({ projectId, userId });
	if (updateNewOwnerError) throw updateNewOwnerError;

	return {
		data: {
			organizationId: userOrganization.id,
		},
	};
};

export const GET: RequestHandler = async (event) => {
	const { session } = await getSupabase(event);
	if (!session) return new Response('Unauthorized', { status: 401 });

	const {
		url: { searchParams },
	} = event;

	const args: Record<string, string> = {};
	args.userId = session.user.id;
	searchParams.forEach((value, key) => (args[key] = value));

	const { action } = args;

	try {
		if (action === 'informUserOfKickFromProject') {
			await informUserOfKickFromProject(args);
		} else if (action === 'deleteProject') {
			await informUsersOfProjectDelete(args);
			deleteProject(args);
		} else if (action === 'informUsersOfProjectEdit') {
			await informUsersOfProjectEdit(args);
		} else if (action === 'createInviteCode') {
			await createInviteCode(args);
		} else if (action === 'getDataOfInviteCode') {
			return new Response(JSON.stringify(await getDataOfInviteCode(args)));
		} else if (action === 'joinProjectUsingInviteCode') {
			return new Response(JSON.stringify(await joinProjectUsingInviteCode(args)));
		} else if (action === 'inviteUserUsingEmail') {
			return new Response(JSON.stringify(await inviteUserUsingEmail(args)));
		} else if (action === 'deleteUser') {
			return new Response(JSON.stringify(await deleteUser(args)));
		} else if (action === 'transferProject') {
			return new Response(JSON.stringify(await transferProject(args)));
		} else {
			return new Response(
				JSON.stringify({
					error: 'Invalid action',
				})
			);
		}

		return new Response(JSON.stringify({ data: 'ok' }));

		// eslint-disable-next-line @typescript-eslint/no-explicit-any
	} catch (error: any) {
		console.error(error);
		return new Response(JSON.stringify({ error: error.message }));
	}
};
