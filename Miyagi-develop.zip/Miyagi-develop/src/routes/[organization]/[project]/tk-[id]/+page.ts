import { getTaskByDisplayId } from '$lib/loader';
import { getSprint } from '$lib/db/sprint';
import { error } from '@sveltejs/kit';
import type { PageLoad } from './$types';
import { getStory } from '$lib/db/story';

export const load: PageLoad = async ({ params }) => {
	const taskData = await getTaskByDisplayId(+params.id, params.project);

	if (!taskData) {
		throw error(404, 'Task not found');
	}

	const storyData = await getStory(taskData.storyId);
	const sprintData = await getSprint(storyData.sprintId);

	return { taskId: taskData.id, storyId: storyData.id, sprintId: sprintData.id };
};
