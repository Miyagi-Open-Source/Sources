<script lang="ts">
	import Task from '$components/miyagi/task/task.svelte';
	import StoryHead from '$components/miyagi/story/story-head.svelte';
	import SprintHead from '$components/miyagi/sprint/sprint-head.svelte';
	import type { PageData } from './$types';

	import { page } from '$app/stores';
	import { notNull } from '$lib/helper';
	import { openDetails } from '$lib/stores/details';
	import { REV_INDEXER } from '$lib/search';
	import { currentProject } from '$lib/stores/currentProject';
	import { childrenProperties } from '$lib/stores/hierarchy';

	import type { Task as TaskType } from '$types/task';
	import type { Story as StoryType } from '$types/story';
	import type { Sprint as SprintType } from '$types/sprint';

	export let data: PageData;

	let task: TaskType | undefined = undefined;
	let story: StoryType | undefined = undefined;
	let sprint: SprintType | undefined = undefined;

	$: $openDetails.task[data.taskId] = true;

	const setTask = () => {
		if (!$currentProject || !data.storyId || !data.sprintId || !data.taskId) return;

		sprint = Object.keys(childrenProperties.project)
			.flatMap((key) => $currentProject![key] as SprintType[])
			.find((sprint) => sprint.id === data.sprintId);
		if (!sprint) return;

		story = sprint.stories.find((story) => story.id === data.storyId);
		if (!story) return;

		task = story.tasks.find((task) => task.id === data.taskId);
	};

	$: $currentProject, setTask();
</script>

<div class="root">
	{#if sprint}
		<a
			href="/{$page.params.organization}/{$page.params.project}/{REV_INDEXER[notNull(sprint).type]}-{sprint?.displayId}"
		>
			<div class="wrap">
				<SprintHead {sprint} />
			</div>
		</a>
	{/if}

	{#if story}
		<a href="/{$page.params.organization}/{$page.params.project}/{REV_INDEXER[notNull(story).type]}-{story?.displayId}">
			<div class="wrap">
				<StoryHead {story} />
			</div>
		</a>
	{/if}

	{#if task}
		<div class="single-view-task">
			<Task {task} />
		</div>
	{/if}
</div>

<style>
	.root {
		display: flex;
		flex-direction: column;
		gap: var(--size-3);
	}

	.wrap {
		border-radius: var(--size-1);
		padding: var(--size-2);
		background-color: var(--surface-1);
	}

	.single-view-task > :global(details) {
		border: none;
	}
</style>
