<script lang="ts">
	import DimensionSelector from '$components/miyagi/analytics/dimension-selector';
	import SprintSelector from '$components/miyagi/analytics/sprint-selector/sprint-selector.svelte';
	import StatusChart from '$components/miyagi/analytics/status-chart';
	import BurndownChart from '$components/miyagi/analytics/BurndownChart.svelte';

	import { selectedSprint, selectSprint } from '$components/miyagi/analytics/selectedSprint';

	import Sprint from '$components/miyagi/sprint';
	import VelocityChart from '$components/miyagi/analytics/velocity-chart.svelte';
	import { currentProject } from '$lib/stores/currentProject';

	$: sprints = $currentProject
		? [...$currentProject.pastSprints, ...$currentProject.currentSprint.filter((sprint) => sprint.isRunning)]
		: [];
	$: $currentProject, setSelectedSprint();

	const setSelectedSprint = () => {
		if (!$currentProject?.currentSprint[0]) return;
		if ($selectedSprint && sprints.includes($selectedSprint)) return;

		selectSprint($currentProject.currentSprint[0]);
	};
</script>

<DimensionSelector />
<!-- Velocity Chart planned vs real -->
<section>
	{#if $currentProject}
		<h2>Project Analytics</h2>
		<VelocityChart project={$currentProject} />

		<h2>Sprint Analytics</h2>
		<p>Sprint to view analytics for</p>
		<SprintSelector {sprints} value={$selectedSprint} on:change={(sprint) => selectSprint(sprint.detail)} />
		{#if $selectedSprint}
			<StatusChart />
			<BurndownChart />

			{#if $selectedSprint}
				<h3>Sprint Details</h3>
				<Sprint sprint={$selectedSprint} />
			{/if}
		{:else}
			<h3>Loading selected Sprint</h3>
		{/if}
	{:else}
		<h3>Loading project</h3>
	{/if}
</section>

<style>
	section {
		max-width: 120ch;
		margin: auto;
	}

	h2 {
		margin: var(--size-6) 0;
	}

	h3 {
		margin-bottom: var(--size-3);
	}
</style>
