<script lang="ts">
	/* eslint-disable @typescript-eslint/no-non-null-assertion */
	/* eslint-disable @typescript-eslint/no-non-null-asserted-optional-chain */
	import Button from '$components/button';
	import List from '$components/list';
	import MoveMenu from '$components/list/move-menu';
	import MenuItem from '$components/menu/menu-item';
	import Sprint from '$components/miyagi/sprint';
	import NewSprint from '$components/miyagi/sprint/new-sprint';
	import Story from '$components/miyagi/story';
	import { addDays, differenceInDays, format } from 'date-fns';
	import IcSprint from '~icons/ic/round-directions-run';
	import IcRoundExpandMore from '~icons/ic/round-expand-more';
	import IcPlus from '~icons/ic/round-plus';
	import IcStop from '~icons/ic/round-stop';
	import { focus } from '$lib/symbols';

	import { waitForTrue } from '$lib/helper';
	import { currentProject } from '$lib/stores/currentProject';
	import { canEdit } from '$lib/stores/userRole';
	import { dialog } from '$components/dialog/dialog-function/dialog-function';

	$: currentSprint = $currentProject?.currentSprint[0]!;
	$: futureSprints = $currentProject?.futureSprints!;
	$: backlogSprint = $currentProject?.backlogSprint?.[0]!;
	$: backlog = backlogSprint?.stories!;

	let futureSprintsOpen = true;

	$: daysTillEnd = differenceInDays(addDays(new Date(currentSprint?.startDate!), currentSprint?.duration!), new Date());
</script>

{#if !$currentProject || !currentSprint || !backlogSprint}
	<!-- <h1>Loading</h1> -->
{:else}
	<section>
		<div class="section-title">
			{#if currentSprint.isRunning}
				<h2>Current Sprint</h2>
				{#if daysTillEnd > 0}
					<span>Sprint should end in {daysTillEnd} day{daysTillEnd === 1 ? '' : 's'}</span>
				{:else if daysTillEnd === 0}
					Sprint should end today.
				{:else if daysTillEnd < 0}
					<span>Sprint is {-daysTillEnd} day{daysTillEnd === -1 ? '' : 's'} overdue!</span>
				{/if}
				<Button
					variant={daysTillEnd < 0 ? 'warn' : 'regular'}
					data-testid="end-sprint"
					--margin="0 0 0 auto"
					on:click={async () => {
						currentSprint.end();
					}}
					disabled={!$canEdit}
				>
					<slot name="trigger-label">
						<svelte:component this={IcStop} />
						End current Sprint
					</slot>
				</Button>
			{:else}
				<h2>Next Sprint</h2>
				<Button
					variant="primary"
					data-testid="start-sprint"
					--margin="0 0 0 auto"
					on:click={async () => {
						currentSprint.startDate ??= new Date().toISOString();
						currentSprint.duration ??= 7;
						// currentSprint.endDate ??= addDays(new Date(currentSprint.startDate), currentSprint.duration).toISOString();

						const [startNextSprint] = await dialog(
							'Start next Sprint',
							[
								{
									input: 'number',
									value: String(currentSprint.duration),
									min: 1,
									title: 'Days',
								},
							],
							{
								message: `<p>Are you sure you want to start the next Sprint?<br>Start Date: ${format(
									new Date(currentSprint.startDate),
									'PP'
								)}<br>End Date: ${format(
									addDays(new Date(currentSprint.startDate), currentSprint.duration),
									'PP'
								)}<br> You can change the duration here:</p>`,
								rawHtml: true,
							}
						);

						if (startNextSprint != null) {
							currentSprint.duration = +startNextSprint;
							currentSprint.start();
						}
					}}
					disabled={!$canEdit}
				>
					<slot name="trigger-label">
						<svelte:component this={IcSprint} />
						Start next Sprint
					</slot>
				</Button>
			{/if}
		</div>

		{#if currentSprint}
			<Sprint sprint={currentSprint} disabled={!$canEdit} />
		{/if}
	</section>

	<section>
		<details bind:open={futureSprintsOpen}>
			<summary>
				<div class="section-title">
					<h2>Planned Sprints</h2>
					<span class="expand-indicator" class:open={futureSprintsOpen}>
						<IcRoundExpandMore />
					</span>
				</div>
			</summary>

			<ol>
				<!-- {#each futureSprints ?? [] as sprint, i} -->
				<List
					items={futureSprints}
					let:item={sprint}
					let:i
					type="sprint"
					name="futureSprint-sprints"
					disabled={!$canEdit}
				>
					<Sprint {sprint} testId="future-sprint-{i}" disabled={!$canEdit}>
						<svelte:fragment slot="front">
							<MoveMenu items={futureSprints} {i}>
								<svelte:fragment slot="top">
									{#if sprint.project.currentSprint[0].isRunning !== true && sprint.project.currentSprint[0].id !== sprint.id}
										<MenuItem
											on:click={async () => {
												const [confirmed] = await dialog(`Make "${sprint.name}" the new active sprint?`, {
													message: `This will replace the current sprint "${sprint.project.currentSprint[0].name}" and move it to the top of planned sprints`,
													confirmLabel: 'Move',
												});

												if (confirmed !== true) return;

												sprint.project.currentSprint[0].update({
													isActive: false,
													sequence: -1,
												});

												sprint.update({
													isActive: true,
												});
											}}
											data-testid="move-to-current-sprint"
										>
											<IcSprint /> Move to current Sprint
										</MenuItem>
										<hr />
									{/if}
								</svelte:fragment>
							</MoveMenu>
						</svelte:fragment>
					</Sprint>
				</List>
				<!-- {/each} -->
				<li>
					<NewSprint project={$currentProject} disabled={!$canEdit} />
				</li>
			</ol>
		</details>
	</section>

	<section>
		<div class="section-title backlog-title">
			<h2>Product Backlog</h2>
			<Button
				data-testid="create-story"
				on:mouseup={async () => {
					const story = await backlogSprint.createStory({
						title: 'New Story',
						sequence: backlogSprint.stories.reduce((acc, cur) => Math.min(cur.sequence, acc), 0) - 1,
					});
					await waitForTrue(() => story[focus]);

					story[focus]?.();
				}}
				--margin="0 0 0 auto"
				disabled={!$canEdit}
			>
				<IcPlus />
				Add Story
			</Button>
		</div>

		<List
			items={backlog}
			let:item
			let:i
			type="story"
			name="backlog-stories"
			on:droppedIntoZone={({ detail: { items, info } }) =>
				items
					.find((item) => item.localId === info.id)
					?.update({
						sprintId: backlogSprint.id,
					})}
			data-testid="list-product-backlog"
			disabled={!$canEdit}
		>
			<Story story={item} disabled={!$canEdit}>
				<svelte:fragment slot="front">
					<MoveMenu items={backlog ?? []} {i} disabled={!$canEdit}>
						<svelte:fragment slot="top">
							<MenuItem
								disabled={!$canEdit}
								on:click={() =>
									item.update({
										sprintId: currentSprint.id,
										sequence: currentSprint.project.currentSprint[0].stories.length,
									})}
								data-testid="move-to-current-sprint"
							>
								<IcSprint /> Move to current Sprint
							</MenuItem>
							<hr />
						</svelte:fragment>
					</MoveMenu>
				</svelte:fragment>
			</Story>
		</List>
	</section>
{/if}

<style>
	.section-title {
		display: flex;
		align-items: center;
		gap: var(--size-5);
		margin-top: var(--size-5);
		margin-bottom: var(--size-3);
	}

	section {
		max-width: 120ch;
		margin: auto;
	}

	ol,
	li {
		list-style: none;
		margin: 0;
		padding: 0;
	}

	ol {
		display: flex;
		flex-direction: column;
		gap: var(--size-2);
	}

	li {
		max-width: unset;
	}

	.expand-indicator {
		font-size: var(--size-6);
	}
</style>
