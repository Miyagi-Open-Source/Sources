<script lang="ts">
	import Button from '$components/button';
	import IcDelete from '~icons/ic/round-delete-forever';
	import QuestionCircle from '~icons/line-md/question-circle';
	import Menu from '$components/menu';
	import MenuItem from '$components/menu/menu-item';
	import { capitalizeFirstLetter, GET, notNull } from '$lib/helper';
	import IcRoundAdd from '~icons/ic/round-add';
	import { userStore } from '$lib/db/auth';
	import Input from '$components/input';
	import { goto } from '$app/navigation';
	import Dialog from '$components/dialog';
	import CodeGenerator from '$components/code-generator';
	import { currentProject } from '$lib/stores/currentProject';
	import { tooltip } from '@svelte-plugins/tooltips';
	import MembersToolTipContent from './MembersToolTipContent.svelte';
	import { userRole } from '$lib/stores/userRole';
	import type { Role } from '$types/userProjectRoles';
	import { dialog } from '$components/dialog/dialog-function/dialog-function';
	import TextInplaceEdit from '$components/inline-edit/TextInplaceEdit.svelte';
	import { CACHE } from '$lib/stores/cache';

	const roles: Role[] = ['owner', 'admin', 'member', 'guest'];
	$: rolesBelowUser = roles.slice(roles.indexOf($userRole) + 1);

	let projectName = $currentProject?.name;

	const saveOldName = ({ detail: original }) => {
		projectName = original;
	};

	const updateName = ({ detail: newValue }) => {
		const name = newValue.trim();

		GET({
			action: 'informUsersOfProjectEdit',
			projectId: $currentProject!.id,
			oldName: projectName,
			newName: name,
		});

		$currentProject!.update({ name: newValue });
	};

	const updateVision = (e: Event) => {
		const vision = (e.target as HTMLInputElement).value;

		$currentProject!.update({ vision });
	};

	$: otherTags = $currentProject?.organization?.projects
		.filter((project) => project.id !== $currentProject?.id)
		.map((project) => project.tag);

	const tagName = 'ID';

	const checkForDuplicateTag = (e: KeyboardEvent) => {
		const tagInput = e.target as HTMLInputElement;
		const newTag = tagInput.value.toUpperCase();

		if (otherTags?.includes(newTag)) {
			tagInput.setCustomValidity(`${tagName}: "${newTag}" already exists in this workspace`);
			tagInput.reportValidity();
		} else {
			tagInput.setCustomValidity('');
			tagInput.reportValidity();
		}
	};

	const updateTag = (e: Event) => {
		const tagInput = e.target as HTMLInputElement;
		const newTag = tagInput.value.toUpperCase();

		const resetForm = (e: Event, alterMsg: string) => {
			alert(alterMsg);
			tagInput.value = $currentProject!.tag;
			tagInput.setCustomValidity('');
			tagInput.reportValidity();
		};

		if (!/^[A-Z]{1,3}$/.test(newTag)) {
			resetForm(e, `${tagName} must be 1-3 capital letters only (A-Z). ${tagName} will be reset.`);
			return;
		}

		if (otherTags?.includes(newTag)) {
			resetForm(e, `${tagName}: "${newTag}" already exists in this workspace. ${tagName} will be reset.`);
			return;
		}

		$currentProject!.update({ tag: newTag });
	};

	const loadProjectToCache = async () => {
		if (!$currentProject) return;

		await CACHE.loadProject($currentProject);

		dialog('Project loaded to cache', {
			cancel: false,
		});
	};

	let openGenerateCodeDialog = false;
</script>

{#if $currentProject}
	<div class="card">
		<header class="card-header">
			<h2 class="card-title">
				{#if $userRole === 'owner'}
					<TextInplaceEdit
						required={true}
						value={$currentProject.name}
						on:submit={updateName}
						on:edit={saveOldName}
						minLength={1}
					/>
				{:else}
					{$currentProject.name}
				{/if}
			</h2>
		</header>
		<hr class="upper-section-divider" />
		<section>
			<div class="label">
				<p><strong>ID:</strong></p>
			</div>
			<div>
				<p>
					<Input
						style="text-transform: uppercase;"
						disabled={$userRole !== 'owner'}
						id="tag-{$currentProject.id}"
						value={$currentProject.tag}
						required
						hideStar
						pattern="[a-zA-Z]+"
						minLength={1}
						maxLength={3}
						variant="inline"
						on:change={updateTag}
						on:keyup={checkForDuplicateTag}
					/>
				</p>
			</div>
			<div class="label">
				<p><strong>Vision:</strong></p>
			</div>
			<div>
				<p>
					<Input
						id="vision-{$currentProject.id}"
						disabled={$userRole !== 'owner'}
						value={$currentProject.vision}
						variant="inline"
						on:change={updateVision}
					/>
				</p>
			</div>
		</section>
		<hr class="lower-section-divider" />
		<footer class="card-footer">
			<div class="card-footer-item">
				<Button on:click={loadProjectToCache}>Load to cache</Button>
			</div>
		</footer>
	</div>

	<h2 class="members-title">Members</h2>
	<span
		class="info-text-icon"
		use:tooltip={{
			content: {
				component: MembersToolTipContent,
			},
			position: 'right',
			// animation: 'puff',
			arrow: true,
			maxWidth: 400,
		}}><QuestionCircle /></span
	>

	{#each $currentProject.members as member}
		{@const memberStatus =
			notNull($currentProject).organization?.owner === member.id ? 'Owner' : member.accepted ? 'Joined' : 'Joining'}
		{@const canChangeRole = roles.indexOf($userRole) < roles.indexOf(member.role)}
		<div class="member">
			<span>
				<h3>{member.username}</h3>
				<Menu variant="ghost" disabled={!canChangeRole}>
					<svelte:fragment slot="label">
						<h3>{capitalizeFirstLetter(member.role)}</h3>
					</svelte:fragment>
					{#each rolesBelowUser as role}
						<MenuItem
							selected={role === member.role}
							disabled={role === member.role}
							on:click={() => $currentProject?.updateMemberRole(member.id, role)}
						>
							{capitalizeFirstLetter(role)}
						</MenuItem>
					{/each}
				</Menu>
			</span>

			<span>
				<p class="memberstatus" data-status={memberStatus}>{memberStatus}</p>
				<Button
					on:click={async () => {
						const [confirmed] = await dialog('Remove member', {
							message: `Are you sure you want to remove ${member.username} from this project?`,
						});

						if (confirmed) {
							const isMe = member.id === $userStore?.id;
							$currentProject?.removeMember(member.id);
							if (isMe) {
								goto(`/`);
								window.location.reload();
							}
						}
					}}
					disabled={memberStatus === 'Owner'}
					title={memberStatus === 'Owner'
						? 'The Owner of a Project cant leave the project, instead delete the Project'
						: ''}><IcDelete /> {member.id === $userStore?.id ? 'Leave' : 'Remove'}</Button
				>
			</span>
		</div>
	{/each}

	{#if rolesBelowUser.length > 0}
		<Button
			on:click={async () => {
				const [email] = await dialog(
					'Invite Member',
					[
						{
							input: 'email',
						},
					],
					{
						message: 'Enter the email address of the user you want to invite',
						confirmLabel: 'Invite',
					}
				);

				if (!email) return;

				const { data, error } = await notNull($currentProject).inviteMember(email);
				if (data) return;

				const [createInviteCode] = await dialog(error, {
					message: 'do you want to create an invite code instead?',
					confirmLabel: 'Yes',
					cancelLabel: 'Cancel',
				});

				if (createInviteCode) openGenerateCodeDialog = true;
			}}><IcRoundAdd /> Invite new Member</Button
		>
	{/if}

	{#if $userRole === 'owner'}
		{@const members = $currentProject?.members.filter((member) => member.id !== $userStore?.id && member.accepted)}
		<Button
			disabled={members.length === 0}
			on:click={async () => {
				if (!$currentProject) return;

				const [user] = await dialog(
					'Transfer Product',
					[
						{
							label: 'select a new owner',
							input: 'user',
							users: members,
						},
					],
					{
						message:
							'You are about to transfer the product to another user. This action cannot be undone. Please select a new owner. You will remain as an admin in the project.',
						confirmLabel: 'Transfer',
					}
				);

				if (!user) return;

				const { data, error } = await GET({
					action: 'transferProject',
					userId: user.id,
					projectId: $currentProject.id,
				});

				if (error)
					return dialog('Error', {
						message: error,
						confirmLabel: 'Ok',
						cancel: false,
					});

				goto(`/${data.organizationId}/${$currentProject.id}/settings`);
				window.location.reload();
			}}><IcRoundAdd />Transfer Product</Button
		>
	{/if}

	<h2>Invite Codes</h2>

	{#each $currentProject.inviteCodes as inviteCode}
		<div class="invite-code">
			<code>{inviteCode.code}</code>
			<span>{inviteCode.role}</span>
			<Button on:click={() => notNull($currentProject).deleteInviteCode(inviteCode.code)}
				><IcDelete />Delete Code</Button
			>
		</div>
	{/each}

	{#if rolesBelowUser.length > 0}
		<Dialog
			bind:open={openGenerateCodeDialog}
			includedTrigger={true}
			heading="Create Invite Code"
			triggerIcon={IcRoundAdd}
		>
			<CodeGenerator roles={rolesBelowUser} project={$currentProject} />
		</Dialog>
	{/if}

	<div class="danger">
		<Button
			variant="warn"
			disabled={$userRole !== 'owner'}
			on:click={async () => {
				const [confirmed] = await dialog('Delete Project', {
					message: "Are you sure you want to delete this project? This action can't be undone.",
					confirmLabel: 'Delete',
				});

				if (confirmed) {
					GET({
						action: 'deleteProject',
						projectId: $currentProject?.id ?? 0,
					});

					$currentProject?.delete();
					goto(`/`);
				}
			}}><IcDelete /> Delete Project</Button
		>
	</div>
{/if}

<style>
	.member {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		margin-bottom: var(--size-2);
	}

	span {
		display: flex;
		flex-direction: row;
		align-items: center;
	}

	p {
		max-inline-size: unset;
	}

	p.memberstatus {
		padding-inline: var(--size-4);
		color: var(--text-2);
	}

	p[data-status='Joining'] {
		font-style: italic;
	}

	h2 {
		max-inline-size: unset;
		margin-block: var(--size-4);
	}

	.danger {
		margin-top: var(--size-6);
	}

	.invite-code {
		display: flex;

		/* align-items: space-between */
		justify-content: space-between;
	}

	.info-text-icon {
		display: inline-flex;
		margin-top: var(--size-2);
		font-size: xx-large;
		cursor: pointer;
	}

	.members-title {
		display: inline;
	}

	.card {
		border-radius: var(--border-size-3);
		box-shadow: var(--card-box-shadow);
		background-color: var(--app-background);
	}

	.card-header {
		display: flex;
		align-items: center;
		justify-content: space-between;
		width: 100%;
		padding: var(--size-3);
		padding-bottom: 0;
	}

	.card-title {
		width: 100%;
		margin: 0;
		font-size: var(--font-size-4);
		line-height: var(--size-7);
	}

	.upper-section-divider {
		margin-top: var(--size-2);
	}

	.upper-section-divider,
	.lower-section-divider {
		border-radius: --var(--radius-round);
		margin-right: var(--size-3);
		margin-left: var(--size-3);
		color: var(--highlighting-background);
		border-color: var(--highlighting-background);
		opacity: 0.2;
	}

	section {
		display: grid;
		grid-template-columns: repeat(2, minmax(0, 1fr));
		grid-template-columns: auto 1fr;
		column-gap: var(--size-3);
		padding-right: var(--size-3);
		padding-left: var(--size-3);
	}

	section > * {
		padding: var(--size-2);
	}

	.label {
		background-color: var(--highlighting-background);
	}

	.label > p {
		padding: 0;
	}

	.card-footer {
		display: flex;
		justify-content: flex-end;
		padding: var(--size-3);
		padding-top: 0;
	}

	.card-footer-item {
		margin-top: var(--size-3);
	}
</style>
