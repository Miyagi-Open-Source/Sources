<!-- <ul>
	<li>
		Admin - Owner, nur kann nicht löschen Member
	</li>
	<li>Member - Wie admin, nur kann admins nicht machen/kicken, oder project settings ändern</li>
	<li>Guest - kann nur gucken</li>
</ul> -->

<h2>
	Members
	<small><em>Roles & rights</em> </small>
</h2>

<ol>
	<li>
		<strong>Owner :</strong> Can add and remove members, change the name, the vision and the ID of the product. Can also
		change the role of members and can delete the product.
	</li>

	<li>
		<strong>Admin :</strong> Like Owner, but can't set a ID or delete the product.
	</li>
	<li>
		<strong>Member:</strong> Like an Admin, but can't change the role of other members or project settings.
	</li>
	<li>
		<strong>Guest:</strong> Can't edit - just watch.
	</li>
</ol>

<style lang="postcss">
	h2 {
		color: white;
	}
</style>
