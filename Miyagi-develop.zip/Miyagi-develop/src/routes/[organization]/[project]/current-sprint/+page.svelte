<script lang="ts">
	import List from '$components/list';
	import Button from '$components/button';
	import MoveMenu from '$components/list/move-menu';
	import Story from '$components/miyagi/story';
	import columns from '$lib/project-settings';
	import UserSelector from '$components/user-selector/user-selector.svelte';
	import Viewer from '$components/tiptap/viewer';
	import type { JSONContent } from '@tiptap/core';
	import { currentProject } from '$lib/stores/currentProject';
	import type { Member } from '$types/member';
	import { userStore } from '$lib/db/auth';
	import Checkbox from '$components/checkbox/checkbox.svelte';
	import Timer from '$components/timer/timer';

	$: currentSprint = $currentProject?.currentSprint[0];
	$: goal = currentSprint?.goal as unknown as JSONContent | undefined;
	$: stories = currentSprint?.stories ?? [];

	let filterUser: Member | undefined = undefined;
	let showUnassigned = true;
</script>

{#if !$currentProject || !currentSprint}
	<!-- <h1>Loading</h1> -->
{:else}
	{#if !currentSprint.isRunning}
		<div class="card">
			<header class="card-header">
				<h2 class="card-title">Sprint not started</h2>
				<Button variant="regular" href="./backlog">Start</Button>
			</header>
		</div>
	{/if}
	<span class="head">
		<h2>{currentSprint.name}</h2>
		<Timer project={$currentProject} />
	</span>
	<div class="goal-filter">
		<div class="goal">
			<Viewer content={goal} />
		</div>
		<div class="filter">
			<label for={undefined} class="unassigned">
				<span>show unassigned</span>
				<Checkbox bind:value={showUnassigned} />
			</label>
			<label for={undefined}>
				<span>filter</span>
				<UserSelector
					on:contextmenu={(e) => {
						e.preventDefault();

						if (filterUser) {
							filterUser = undefined;
						} else {
							filterUser = $currentProject?.members.find((member) => $userStore?.id === member.id);
						}
					}}
					unassign="clear"
					bind:value={filterUser}
					users={$currentProject.members}
					on:dblClick={() => {
						filterUser = $currentProject?.members.find((member) => $userStore?.id === member.id);
					}}
				/>
			</label>
		</div>
	</div>
	<div class="col-labels">
		{#each Object.entries(columns) as [status, { icon, label }]}
			<div style:color={`var(--${status}-color)`} style:background-color={`var(--${status}-background-color)`}>
				<svelte:component this={icon} />{label}
			</div>
		{/each}
	</div>

	<!-- Sprint Backlog -->
	<section class="content">
		<List
			items={filterUser || !showUnassigned
				? stories.filter((story) =>
						story.tasks.some(({ assigneeId }) =>
							filterUser ? assigneeId === filterUser?.id || (showUnassigned && !assigneeId) : assigneeId
						)
				  )
				: stories}
			let:item
			let:i
			type="story"
		>
			<Story story={item} showStatusColumns filterUser={filterUser?.id} {showUnassigned}>
				<svelte:fragment slot="front">
					<MoveMenu items={stories} {i} />
				</svelte:fragment>
			</Story>
		</List>
	</section>
{/if}

<style lang="postcss">
	.head {
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.goal {
		overflow: hidden;
		display: -webkit-box;
		margin-bottom: var(--size-6);
		color: var(--text-2);
		-webkit-line-clamp: 2;
		line-clamp: 2;
		text-overflow: ellipsis;
		-webkit-box-orient: vertical;
	}

	h2 {
		display: flex;
		margin-right: 0;
		margin-bottom: var(--size-2);
	}

	.col-labels {
		position: sticky;
		top: calc(var(--size-2) * -1);
		z-index: 1;
		display: flex;
		flex-direction: row;
		align-items: center;
		justify-content: space-around;
		gap: var(--size-2);
		border-radius: var(--radius-2);
		margin-bottom: var(--size-2);
		padding-inline: var(--size-2-5);

		& div {
			flex-grow: 1;
			flex-basis: 0;
			display: flex;
			align-items: center;
			justify-content: center;
			gap: var(--size-2);
			border-radius: var(--radius-2);
			padding-block: var(--size-2);
			font-size: var(--font-size-3);
			font-weight: 500;
			text-transform: uppercase;
		}
	}

	.goal-filter {
		display: flex;
		justify-content: space-between;
	}

	label {
		display: flex;
		align-items: center;
	}

	.filter {
		display: flex;
		align-items: center;
		gap: var(--size-3);
	}

	.unassigned {
		gap: var(--size-1);
	}

	.card {
		border-radius: var(--border-size-3);
		box-shadow: var(--card-box-shadow);
		background-color: var(--app-background);
	}

	.card-header {
		display: flex;
		align-items: center;
		justify-content: space-between;
		width: 100%;
		padding: var(--size-3);
	}

	.card-title {
		width: 100%;
		margin: 0;
		color: var(--red-4);
		font-size: var(--font-size-3);
		line-height: var(--size-7);
	}
</style>
