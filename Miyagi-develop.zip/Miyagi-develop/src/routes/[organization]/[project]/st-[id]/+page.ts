import { getStoryByDisplayId } from '$lib/loader';
import { getSprint } from '$lib/db/sprint';
import { error } from '@sveltejs/kit';
import type { PageLoad } from './$types';

export const load: PageLoad = async ({ params }) => {
	const storyData = await getStoryByDisplayId(+params.id, params.project);

	if (!storyData) {
		throw error(404, 'Story not found');
	}

	const sprintData = await getSprint(storyData.sprintId);

	return { storyId: storyData.id, sprintId: sprintData.id };
};
