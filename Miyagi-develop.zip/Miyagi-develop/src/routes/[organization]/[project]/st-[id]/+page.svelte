<script lang="ts">
	import Story from '$components/miyagi/story/story.svelte';
	import SprintHead from '$components/miyagi/sprint/sprint-head.svelte';
	import type { PageData } from './$types';

	import { page } from '$app/stores';
	import { notNull } from '$lib/helper';
	import { openDetails } from '$lib/stores/details';
	import { REV_INDEXER } from '$lib/search';
	import { currentProject } from '$lib/stores/currentProject';
	import { childrenProperties } from '$lib/stores/hierarchy';

	import type { Story as StoryType } from '$types/story';
	import type { Sprint as SprintType } from '$types/sprint';

	export let data: PageData;

	let story: StoryType | undefined = undefined;
	let sprint: SprintType | undefined = undefined;

	$: $openDetails.story[data.storyId] = true;

	const setStory = () => {
		if (!$currentProject || !data.storyId || !data.sprintId) return;

		sprint = Object.keys(childrenProperties.project)
			.flatMap((key) => $currentProject![key] as SprintType[])
			.find((sprint) => sprint.id === data.sprintId);
		if (!sprint) return;

		story = sprint.stories.find((story) => story.id === data.storyId);
	};
	$: $currentProject, setStory();
</script>

<div class="root">
	{#if sprint}
		<a
			href="/{$page.params.organization}/{$page.params.project}/{REV_INDEXER[notNull(sprint).type]}-{sprint?.displayId}"
		>
			<div class="wrap">
				<SprintHead {sprint} />
			</div>
		</a>
	{/if}

	{#if story}
		<Story {story} />
	{/if}
</div>

<style>
	.root {
		display: flex;
		flex-direction: column;
		gap: var(--size-3);
	}

	.wrap {
		border-radius: var(--size-1);
		padding: var(--size-2);
		background-color: var(--surface-1);
	}
</style>
