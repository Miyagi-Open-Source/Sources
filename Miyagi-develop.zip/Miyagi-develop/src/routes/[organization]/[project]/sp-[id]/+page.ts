import { getSprintByDisplayId } from '$lib/loader';
import { error } from '@sveltejs/kit';
import type { PageLoad } from './$types';

export const load: PageLoad = async ({ params }) => {
	const sprintData = await getSprintByDisplayId(+params.id, params.project);

	if (!sprintData) {
		throw error(404, 'Sprint not found');
	}

	return { sprintId: sprintData.id };
};
