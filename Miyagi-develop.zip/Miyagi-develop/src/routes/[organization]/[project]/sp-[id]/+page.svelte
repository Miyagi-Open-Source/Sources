<script lang="ts">
	import Sprint from '$components/miyagi/sprint/sprint.svelte';
	import type { PageData } from './$types';

	import { openDetails } from '$lib/stores/details';
	import { currentProject } from '$lib/stores/currentProject';
	import { childrenProperties } from '$lib/stores/hierarchy';
	import type { Sprint as SprintType } from '$types/sprint';

	export let data: PageData;

	let sprint: SprintType | undefined = undefined;

	$: $openDetails.sprint[data.sprintId] = true;

	const setSprint = () => {
		if (!$currentProject || !data.sprintId) return;

		sprint = Object.keys(childrenProperties.project)
			.flatMap((key) => $currentProject![key] as SprintType[])
			.find((sprint) => sprint.id === data.sprintId);
	};

	$: $currentProject, setSprint();
</script>

{#if sprint}
	<Sprint {sprint} />
{/if}
