<script lang="ts">
	import Nav from '$components/layout/nav';
</script>

<Nav />
<slot />
