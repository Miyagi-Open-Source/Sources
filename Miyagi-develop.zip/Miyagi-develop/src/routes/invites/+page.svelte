<script lang="ts">
	import Button from '$components/button';
	import { userStore } from '$lib/db/auth'; //
	import { acceptInvite, declineInvite } from '$lib/db/project'; //
	import { GET } from '$lib/helper';
	import type { Db_InviteCode, Db_Project } from '$types/db-types';
	import Input from '$components/input';
	import Dialog from '$components/dialog';
	import { onDestroy, onMount } from 'svelte';
	import { goto } from '$app/navigation';
	import { checkForUpdates, invites } from '$lib/stores/invites';

	const removeInvite = (id: Db_Project['id']) => {
		$invites = $invites.filter((invite) => invite.id !== id);
	};

	const accept = (id: Db_Project['id']) => {
		acceptInvite($userStore!.id, id);
		removeInvite(id);
		location.reload();
		// TODO add to projects
	};

	const decline = (id: Db_Project['id']) => {
		declineInvite($userStore!.id, id);
		removeInvite(id);
	};

	let code = '';
	let codeInformation:
		| {
				data: Db_InviteCode & {
					projectName: string;
				};
		  }
		| {
				error: string;
		  }
		| undefined;

	const getDataOfInviteCode = async (code: string) => {
		if (code.includes('inviteCode')) code = new URL(code).searchParams.get('inviteCode')!;

		codeInformation = await GET({
			action: 'getDataOfInviteCode',
			code,
		});
	};

	const joinUsingInviteCode = async (code: string) => {
		await GET({
			action: 'joinProjectUsingInviteCode',
			code,
		});
	};

	let interval: number;
	onMount(() => {
		const inviteCodeInURL = new URLSearchParams(window.location.search).get('inviteCode');
		if (inviteCodeInURL) {
			code = inviteCodeInURL;
			getDataOfInviteCode(code);
		}

		interval = window.setInterval(() => {
			checkForUpdates();
		}, 5000);
	});

	onDestroy(() => {
		clearInterval(interval);
	});
</script>

<h2>Invitations</h2>
{#if $invites.length === 0}
	<p>You have not been invited to any projects yet</p>
{:else}
	<p>You have been invited to the following project{$invites.length === 1 ? '' : 's'}</p>
{/if}
{#each $invites as { id, name, role }}
	<div>
		<b>{name}</b> as <b>{role}</b>
		<Button on:click={() => accept(id)}>Accept</Button>
		<Button on:click={() => decline(id)}>Decline</Button>
	</div>
{/each}

<form
	on:submit|preventDefault={() => {
		getDataOfInviteCode(code);
	}}
>
	<h2>Invite Code</h2>

	<Input bind:value={code} />
	<Button type="submit">Check</Button>
</form>

{#if codeInformation}
	{#if 'data' in codeInformation}
		{@const codeData = codeInformation.data}
		<Dialog open={true} includedTrigger={false}>
			<h2 slot="title">Invite Code for {codeData.projectName}</h2>
			<p>Join the Project {codeData.projectName} as {codeData.role}</p>
			<svelte:fragment slot="dialog-actions">
				<Button
					on:click={async () => {
						joinUsingInviteCode(code);
						codeInformation = undefined;
						code = '';
						// TODO add to projects overview
						await goto('/invites');
						location.reload();
					}}>Join</Button
				>
				<Button
					on:click={() => {
						code = '';
						codeInformation = undefined;
					}}>Decline</Button
				>
			</svelte:fragment>
		</Dialog>
	{:else}
		<Dialog open={true} includedTrigger={false}>
			<h2 slot="title">Invalid Code</h2>
			<p>{codeInformation.error}</p>
			<svelte:fragment slot="dialog-actions">
				<Button
					on:click={() => {
						code = '';
						codeInformation = undefined;
						goto('/invites');
					}}>Close</Button
				>
			</svelte:fragment>
		</Dialog>
	{/if}
{/if}
