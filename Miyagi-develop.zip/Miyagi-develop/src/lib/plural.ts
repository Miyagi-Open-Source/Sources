const plurals = {
	Workspace: 'Workspaces',
	Project: 'Projects',
	Sprint: 'Sprints',
	Story: 'Stories',
	Task: 'Tasks',
} as const;

export const FORMAT = Object.fromEntries(
	Object.entries(plurals).map(([singular, plural]) => [
		singular,
		(count: number) => (Math.abs(count) === 1 ? singular : plural),
	])
) as {
	[K in keyof typeof plurals]: <T extends number | unknown>(count: T) => T extends 1 | -1 ? K : (typeof plurals)[K];
};
