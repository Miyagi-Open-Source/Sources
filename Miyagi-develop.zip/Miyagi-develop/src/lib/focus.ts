const focusableSelectorsQuery = 'a[href], button, input, textarea, select, details, [tabindex]';

/** Returns an array of focusable elements that are descendants of element. */
export function getFocusable(element: HTMLElement): HTMLElement[] {
	return Array.from(element.querySelectorAll<HTMLElement>(focusableSelectorsQuery)).filter(
		(element) => !element.hasAttribute('disabled') || element.tabIndex !== -1
	);
}
