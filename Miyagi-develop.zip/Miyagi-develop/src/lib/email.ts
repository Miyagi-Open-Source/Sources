import type { XOR } from '$types/helper';

type Recipient = {
	email: string;
	username: string;
};
export const send = ({
	subject,
	message,
	recipient,
	recipients,
}: XOR<
	{ subject: string; message: string; recipient: Recipient },
	{ subject: string; message: string; recipients: Recipient[] }
>) => {
	const _recipients = (recipients ?? [recipient]).map(({ email, username }) => ({
		email,
		name: username,
	}));

	return fetch('https://api.sendgrid.com/v3/mail/send', {
		body: JSON.stringify({
			personalizations: [
				{
					to: _recipients,
				},
			],
			from: {
				email: 'noreply@***',
				name: '***',
			},
			subject,
			content: [
				{
					type: 'text/html',
					value: message,
				},
			],
		}),
		headers: {
			Authorization: `Bearer ${import.meta.env.VITE_SENDGRID_KEY}`,
			'Content-Type': 'application/json',
		},
		method: 'POST',
	});
};
