import { supabase } from './db';
import type { Object as ObjectType } from 'ts-toolbelt';
import type { Tables } from '$types/db-types';
import type { TypeString, TypeTable } from '$types/hierarchy';
import { childrenProperties } from './stores/hierarchy';
import { hasChanges } from './helper';

const eventTypes = ['INSERT', 'UPDATE', 'DELETE', '*'] as const;
type EventType = (typeof eventTypes)[number];

type realtimeCallbacks = {
	[Type in TypeString]: {
		[Event in EventType]: ((data: TypeTable['Row']) => void)[];
	};
};
const callbacks: realtimeCallbacks = Object.fromEntries(
	Object.keys(childrenProperties).map((type) => [type, Object.fromEntries(eventTypes.map((event) => [event, []]))])
) as unknown as realtimeCallbacks;

/**
 * @param table Table on which to listen for changes on
 * @param where Object with { key: value } such that the row "key" has the vale ${ value }
 * @param updateFunctions Object with functions that will be called when the row is updated
 */
export const subscribeRealtime = <T extends TypeString>(
	table: T,
	where: Record<string, string | number>,
	updateFunctions: ObjectType.AtLeast<Record<EventType, (data: Tables[T]['Row']) => void>>
) => {
	const condition = (data: Record<string, unknown>) => !hasChanges(where, data);

	for (const [event, callback] of Object.entries(updateFunctions)) {
		callbacks[table][event as EventType].push((data) => {
			if (condition(data)) callback(data);
		});
	}
};

// const init = () => {
// 	try {
// 		supabase
// 			.channel(`*`)
// 			.on(
// 				'postgres_changes',
// 				{
// 					event: '*',
// 					schema: 'public',
// 				},
// 				// @ts-ignore
// 				({
// 					table,
// 					eventType,
// 					new: newData,
// 					old: oldData,
// 				}: {
// 					table: TypeString;
// 					eventType: EventType;
// 					new: TypeTable;
// 					old: TypeTable;
// 					// @ts-ignore
// 				}) => callbacks[table][eventType].forEach((callback) => callback(eventType === 'DELETE' ? oldData : newData))
// 			)
// 			.subscribe();
// 	} catch (error) {
// 		console.error('https://github.com/supabase/realtime-js/issues/165', error);
// 	}
// };
const init = () => {
	try {
		supabase
			.channel(`*`)
			.on(
				'postgres_changes',
				{
					event: '*',
					schema: 'public',
				},
				// @ts-ignore
				({
					table,
					eventType,
					new: newData,
					old: oldData,
				}: {
					table: string;
					eventType: EventType;
					new: Record<string, unknown>;
					old: Record<string, unknown>;
					// @ts-ignore
				}) => callbacks[table][eventType].forEach((callback) => callback(eventType === 'DELETE' ? oldData : newData))
			)
			.subscribe();
	} catch (error) {
		console.error('https://github.com/supabase/realtime-js/issues/165', error);
	}
};
init();
