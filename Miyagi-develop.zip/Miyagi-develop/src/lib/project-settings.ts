import { browser } from '$app/environment';
import type { SvelteComponent } from 'svelte';
import IconProgress from '~icons/ic/round-edit';
import IconBacklog from '~icons/ic/round-menu';
import IconDone from '~icons/ic/round-task';

// temp file
// will be replaced with some kind of "project settings" in the future

type StatusSettings = Record<
	string,
	{
		label: string;
		icon: typeof SvelteComponent;
		backgroundColor: string;
		color: string;
	}
>;

/**
 * Holds the definition of status columns for a project
 */
const statusSettings = {
	backlog: {
		label: 'Todo',
		icon: IconBacklog,
		backgroundColor: '#edf2ff',
		color: '#364fc7',
	},
	inProgress: {
		label: 'In Progress',
		icon: IconProgress,
		backgroundColor: '#f8f0fc',
		color: '#862e9c',
	},
	done: {
		label: 'Done',
		icon: IconDone,
		backgroundColor: '#ebfbee',
		color: '#087f5b',
	},
} as const satisfies StatusSettings;

export default statusSettings;

/**
 * Creates a new style tag with custom properties, that can be used to style the status column
 *
 * Creates the following variables for each {status}:
 *  * --{status}-color
 *  * --{status}-background-color
 *
 * These get swapped for `prefers-color-scheme: dark`
 */
const setColorsAsVars = (statusSettings: StatusSettings) => {
	if (!browser) return;

	const lightModeVars = Object.entries(statusSettings).map(([status, { color, backgroundColor }]) => {
		return `--${status}-color: ${color};--${status}-background-color: ${backgroundColor};`;
	});
	const darkModeVars = Object.entries(statusSettings).map(([status, { color, backgroundColor }]) => {
		return `--${status}-background-color: ${color};--${status}-color: ${backgroundColor};`;
	});

	const style = document.createElement('style');
	style.id = 'status-colors';

	style.textContent = `:root {
	${lightModeVars.join('')}
}

// @media only screen and (prefers-color-scheme: dark) {
// 	:root {${darkModeVars.join('')}}
// }

:where(
    [data-theme="dark"],
    .dark,
    .dark-theme
) {
    ${darkModeVars.join('')}
}`;

	document.head.appendChild(style);
};

setColorsAsVars(statusSettings);
