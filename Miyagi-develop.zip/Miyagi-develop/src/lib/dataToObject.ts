/* eslint-disable @typescript-eslint/no-non-null-assertion */
// @ts-nocheck

import type {
	TypeHierarchy,
	TypeString,
	StringToTable,
	StringToType,
	TypeTable,
	TypeHierarchyParent,
} from '$types/hierarchy';
import { capitalizeFirstLetter, getChanges, hasChanges, inplaceFilter, isEmpty, RecoverableProxy } from './helper';
import { subscribeRealtime } from './realtime';
import { childrenProperties, Db_Functions, parentType, type childrenPropertiesType } from './stores/hierarchy';
import { toSort, updateUi } from './stores/uiUpdate';
import { editingDisabled } from './symbols';
import { getRegistered, isRegistered, setRegistered } from '$lib/stores/register';
import { createHandler } from './handlers';
import { LOCALID } from './stores/localId';
import { CACHE } from './stores/cache';
import { dataTo } from './stores/dataTo';

export const dataToObject = <
	TString extends TypeString,
	TTableType extends StringToTable<TString>,
	TType extends StringToType<TString>,
	TChild extends StringToType<TypeHierarchy[TString]>,
	TParent extends StringToType<TypeHierarchyParent[TString]>,
	TCreateFunction extends TType[`create${Capitalize<TypeHierarchy[TString]>}`]
>(
	type: TString,
	data: TTableType['Row'],
	functions?: {
		create?: (data: TType) => TType;
		update?: TType['update'];
		delete?: (obj: TType) => void;
		onLoad?: (obj: TType) => void;
		// beforeCreate?: (data: Parameters<TCreateFunction>[0]) => void;
		beforeUpdate?: TType['update'];
		// beforeDelete?: (obj: TType) => void;
	},
	realtime = false
) => {
	const hasChildren = !isEmpty(childrenProperties[type]);

	/** Type of the children of obj */
	const childType: TypeString | undefined = Object.values(childrenProperties[type])[0]?.type;
	const curParentType = parentType[type];
	const createFunctionName = hasChildren ? `create${capitalizeFirstLetter(childType!)}` : null;

	const applyUpdate: TType['update'] = async (patch) => {
		patch = getChanges(obj, patch);
		if (functions?.update) {
			patch = await functions.update.call(obj, patch);
			if (!patch) return;
		}

		const idAdded = patch.id != null && obj.id == null;
		if (type !== 'sprint' && 'sequence' in obj && patch.sequence != null && patch.sequence !== obj.sequence)
			Object.keys(childrenProperties[curParentType]).forEach((key) => toSort.add(obj[curParentType][key]));

		Object.assign(obj, patch);
		if (idAdded) idAdd();
		CACHE.set(obj);
		updateUi();
	};

	const applyDelete: TType['delete'] = () => {
		functions?.delete?.(obj);

		if (curParentType) {
			const parent: TParent = obj[curParentType];
			const parentChildrenKeys: (keyof childrenPropertiesType[TString])[] = Object.keys(
				childrenProperties[curParentType]
			);
			for (const key of parentChildrenKeys) {
				inplaceFilter(parent[key], (child: TType) => child.id !== obj.id);
			}

			CACHE.set(parent);
		}

		CACHE.deleteEntry(obj);
		updateUi();
	};

	// Create a Child
	const applyCreate = (newData: TypeTable['Insert'], property: childrenPropertiesType[TString]['key']) => {
		const withType = { type: childType, id: newData.id };
		if (isRegistered(withType)) return getRegistered(withType);

		const child = dataTo[childType!](Object.assign(newData, { [type]: obj }));

		if (!obj[property].includes(child)) {
			if ('sequence' in child) {
				const newIndex = obj[property].findIndex((child: TType) => child.sequence > newData.sequence);
				if (newIndex === -1) obj[property].push(child);
				else obj[property].splice(newIndex, 0, child);
			} else {
				obj[property].push(child);
			}
		}

		CACHE.set(obj); // TODO set cache at end

		updateUi();
		return child;
	};

	const obj = new RecoverableProxy(
		Object.assign(data, {
			type,
			localId: LOCALID.get({
				id: data.id,
				type,
			}),
		}),
		hasChildren
			? createHandler(
					applyCreate,
					Object.fromEntries(
						Object.entries(childrenProperties[type]).map(([key, { function: fn }]) => [key, fn] as const)
					) as unknown as Record<keyof TType, () => Promise<TChild[]>>
			  )
			: {}
	) as TType;

	obj.update = async (patch: Parameters<TType['update']>[0]) => {
		if (functions?.beforeUpdate) {
			patch = await functions.beforeUpdate.call(obj, patch);
			if (!patch) return;
		}
		if (!hasChanges(patch, obj)) return;

		await applyUpdate(patch);
		Db_Functions[type].update(obj.id, patch);

		return obj;
	};

	obj.delete = () => {
		applyDelete();
		Db_Functions[type].delete(obj.id);
	};
	if (hasChildren) {
		obj[createFunctionName!] = async (
			newData: Parameters<TCreateFunction>[0],
			property?: Parameters<TCreateFunction>[1] = Object.keys(childrenProperties[type])[0]
		) =>
			new Promise((resolve) => {
				const id = crypto.randomUUID();
				const newDataWithId = {
					...newData,
					id,
					[type + 'Id']: obj.id,
				};

				Db_Functions[childType!].create(newDataWithId).then((patch) => {
					newChild.update(patch);
					newChild[editingDisabled] = false;
					resolve(newChild);
				});

				const newChild = applyCreate(structuredClone(newDataWithId), property);
				newChild[editingDisabled] = true;
			});
	}

	const addRealtimeSubscriptions = () => {
		setTimeout(() => {
			subscribeRealtime(
				type,
				{ id: obj.id },
				{
					DELETE: applyDelete,
					UPDATE: (patch) => hasChanges(patch, obj) && applyUpdate(patch),
				}
			);
		}, 1000);

		if (childType) {
			subscribeRealtime(
				childType,
				{ [type + 'Id']: obj.id },
				{
					INSERT: (newData) => applyCreate(newData, Object.keys(childrenProperties[type])[0]),
				}
			);
		}
	};

	if (realtime) addRealtimeSubscriptions();
	setRegistered(obj);

	functions?.onLoad?.(obj);
	CACHE.set(obj);
	updateUi();

	return obj;
};
