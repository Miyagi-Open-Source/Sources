import type { Db_Sprint, Db_Story, Db_Task } from '$types/db-types';
import type { Sprint } from '$types/sprint';
import type { Story } from '$types/story';
import type { Task } from '$types/task';
import uFuzzy from '@leeoniya/ufuzzy';
import { get } from 'svelte/store';
import { userStore } from './db/auth';

import group from 'array.prototype.group';
import type { Compute } from '$types/helper';
group.shim();

const uf = new uFuzzy({
	intraMode: 1,
});

type HasProjectTag = { projectTag: string };

type SearchCache = {
	task: Compute<Db_Task & Pick<Task, 'type'> & HasProjectTag>[];
	story: Compute<Db_Story & Pick<Story, 'type'> & { tasks: unknown[] } & HasProjectTag>[];
	sprint: Compute<Db_Sprint & Pick<Sprint, 'type'> & { stories: unknown[] } & HasProjectTag>[];
};

let resultOptionsTypes: SearchCache | null;

export const INDEXER = {
	tk: 'task',
	st: 'story',
	sp: 'sprint',
} as const;

type INDEXER = typeof INDEXER;
type REV_INDEXER = {
	[key in keyof INDEXER]: INDEXER[key];
};

export const REV_INDEXER = Object.fromEntries(
	Object.entries(INDEXER).map(([key, value]) => [value, key])
) as REV_INDEXER;

const generateResultOptionsTypes = () => ({
	task: Object.entries(localStorage)
		.filter(([key]) => key.startsWith('task-'))
		.map(([, value]) => JSON.parse(value)),
	story: Object.entries(localStorage)
		.filter(([key]) => key.startsWith('story-'))
		.map(([, value]) => JSON.parse(value)),
	sprint: Object.entries(localStorage)
		.filter(([key]) => key.startsWith('sprint-'))
		.map(([, value]) => JSON.parse(value)),
});

export const clearResultOptionsTypes = () => (resultOptionsTypes = null);

export const search = (query: string) => {
	if (!resultOptionsTypes) resultOptionsTypes = generateResultOptionsTypes();
	query = query.toLowerCase();

	const _query = query.split(/\S+:\S+/g).join('');
	const options: Record<string, string> = Object.fromEntries(
		query.match(/\S+:\S+/g)?.map((option) => option.toLowerCase().split(':')) ?? []
	);

	let resultOptions =
		resultOptionsTypes[options.type as keyof typeof resultOptionsTypes] ?? Object.values(resultOptionsTypes).flat();

	const assignee = options.assignee ?? options.a;
	if (assignee === 'me') {
		const userId = get(userStore)?.id;
		resultOptions = (resultOptions as (typeof resultOptions)[number][]).filter(
			(result) => result.type === 'task' && result.assigneeId === userId
		) as typeof resultOptions;
	}

	const productTag = options.product ?? options.p;
	if (productTag) {
		resultOptions = (resultOptions as (typeof resultOptions)[number][]).filter(
			(result) => result.projectTag.toLowerCase() === productTag
		) as typeof resultOptions;
	}

	// TODO: tasks with status "todo" are named "backlog"
	const status = options.status ?? options.s;
	if (status) {
		resultOptions = (resultOptions as (typeof resultOptions)[number][]).filter(
			(result) => 'status' in result && result.status.toLowerCase() === status
		) as typeof resultOptions;
	}

	const inTitle = options.intitle ?? options.title ?? options.t;
	if (status) {
		resultOptions = (resultOptions as (typeof resultOptions)[number][]).filter((result) =>
			result['title' in result ? 'title' : 'name'].includes(inTitle)
		) as typeof resultOptions;
	}

	const inDescription = options.indescription ?? options.description ?? options.d;
	if (status) {
		resultOptions = (resultOptions as (typeof resultOptions)[number][]).filter((result) =>
			result['description' in result ? 'description' : 'goal'].includes(inDescription)
		) as typeof resultOptions;
	}

	const resultOptionsSearchText = (resultOptions as (typeof resultOptions)[number][]).map((result) => {
		let searchText = '';

		if ('title' in result) searchText += result.title;
		if ('gaol' in result) searchText += result.gaol;
		if ('name' in result) searchText += result.name;
		if ('description' in result) searchText += JSON.stringify(result.description);
		searchText += result.displayId;

		return searchText;
	});

	const results = uf
		.filter(resultOptionsSearchText, _query)
		.slice(0, 10)
		.map((index) => resultOptions[index])
		.filter((result) => result);

	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	const groupedResults = (results as any).group((el: (typeof results)[number]) => el.displayId) as Record<
		string,
		(typeof results)[number][]
	>;

	const bestResults = Object.values(groupedResults).map((group) =>
		group.reduce((newest, current) => (newest.updated_at > current.updated_at ? newest : current))
	);

	if (/^\w{3}-(?:tk|st|sp)-\d{1,6}$/.test(query)) {
		const [, type, searchId] = query.split('-');
		const searchIdNum = +searchId;

		const result = resultOptionsTypes[INDEXER[type]]?.find(({ displayId }) => displayId === searchIdNum);

		if (result) bestResults.unshift(result);
	}

	return bestResults;
};
