import { supabase } from './';
import { noop, uniqueBy } from '$lib/helper';

import type { UserProfile } from '$types/user';
import type { Db_Organization, Db_Organization_Update } from '$types/db-types';
import { get } from 'svelte/store';
import { userStore } from './auth';
import { getJoinedProjectsOfUser } from './project';

export const getOrganization = async (id: Db_Organization['id']) => {
	const { data, error } = await supabase.from('organization').select('*').match({ id });
	if (error) throw error;

	return data[0];
};

export const updateOrganization = async (id: number, patch: Db_Organization_Update) => {
	const { error } = await supabase.from('organization').update(patch).match({ id });
	if (error) throw error;
};

export const deleteOrganization = async (id: number) => {
	const { error } = await supabase.from('organization').delete().match({ id });
	if (error) throw error;

	supabase.from('userProjectRoles').delete().match({ projectId: id }).then(noop);
};

export const createOrganization = async (name: Db_Organization['name']) => {
	const { id } = get(userStore)!;

	const { data, error } = await supabase.from('organization').insert({ name, owner: id }).select('*');
	if (error) throw error;

	return data[0];
};

export const getUsersMemberOrganizations = async (userId: UserProfile['id']) => {
	const projects = await getJoinedProjectsOfUser(userId);
	const organizations = await Promise.all(
		projects.filter(uniqueBy('organizationId')).map(({ organizationId }) => getOrganization(organizationId))
	);

	return organizations.sort((a, b) => a.name.localeCompare(b.name));
};

export const getUsersOwnedOrganizations = async (userId: UserProfile['id']) => {
	const { data, error } = await supabase.from('organization').select('*').match({ owner: userId });
	if (error) throw error;

	return data;
};

export const getUsersOrganizations = async (userId: UserProfile['id']) => {
	const _organizations = await Promise.all([getUsersOwnedOrganizations(userId), getUsersMemberOrganizations(userId)]);

	const organizations = _organizations.flat().filter(uniqueBy('id'));

	return organizations;
};
