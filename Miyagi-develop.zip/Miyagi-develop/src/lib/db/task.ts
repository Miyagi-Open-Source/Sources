import { supabase } from './';
import { createBatchedUpdateFunction } from './common';

import type { Db_Project, Db_Task, Db_Task_Insert } from '$types/db-types';
import { asNotArray } from '$lib/helper';

// Every Function that gets multiple tasks should sort them.

export const getTasksOfStory = async (storyId: number) => {
	const { data, error } = await supabase.from('task').select('*').match({ storyId }).order('sequence');
	if (error) throw error;

	return data;
};

export const getTask = async (id: Db_Task['id']) => {
	const { data, error } = await supabase.from('task').select('*').match({ id });
	if (error) throw error;

	return data[0];
};

export const updateTask = createBatchedUpdateFunction('task');

export const deleteTask = async (id: Db_Task['id']) => {
	const { error } = await supabase.from('task').delete().match({ id });
	if (error) throw error;
};

export const createTask = async (task: Db_Task_Insert) => {
	const { data, error } = await supabase.from('task').insert(task).select('*');
	if (error) throw error;

	return data[0];
};

export const getTaskByDisplayId = async (
	displayId: Db_Task['displayId'],
	projectId: Db_Project['id']
): Promise<Db_Task> => {
	const { data, error } = await supabase
		.from('task')
		.select('*, story!inner(sprint!inner(isActive, updated_at, project!inner(id)))')
		.match({ displayId })
		.eq('story.sprint.project.id', projectId);
	if (error) throw error;

	return data.sort((taskA, taskB) => {
		const sprintA = asNotArray(asNotArray(taskA!.story!).sprint!);
		const sprintB = asNotArray(asNotArray(taskB!.story!).sprint!);

		return sprintA.isActive ? -1 : sprintB.isActive ? 1 : sprintA.updated_at > sprintB.updated_at ? -1 : 1;
	})[0];
};
