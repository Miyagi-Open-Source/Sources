import { supabase } from './';

import type { Sprint } from '$types/sprint';
import type { Story } from '$types/story';
import type { Task } from '$types/task';

import type { Db_Story_Update, Db_Task_Update, Db_Sprint_Update } from '$types/db-types';

/**
 * Instead of sending an update for everything that changes the moment it changes,
 * remember all changes and send a batched update once the js stack is empty.
 */

export type Entries<T> = {
	[K in keyof T]: [K, T[K]];
}[keyof T][];

type IdentifierToType<TData> = TData extends 'task'
	? Db_Task_Update
	: TData extends 'story'
	? Db_Story_Update
	: TData extends 'sprint'
	? Db_Sprint_Update
	: never;

type IdentifiersToPatches<T extends string> = Record<T, Map<number, Partial<IdentifierToType<T>>>>;

const patches: IdentifiersToPatches<'task' | 'story' | 'sprint'> = {
	task: new Map(),
	story: new Map(),
	sprint: new Map(),
};

/**
 * stores the resolve functions for each update promise in order to inform the source of the completed update.
 */
const resolvers: Record<'task' | 'story' | 'sprint', ((value: unknown) => void)[]> = {
	task: [],
	story: [],
	sprint: [],
};

export const createBatchedUpdateFunction =
	<TIdentifier extends keyof typeof patches, TType extends IdentifierToType<TIdentifier>>(type: TIdentifier) =>
	(id: number, patch: TType) => {
		patches[type].set(id, { ...patches[type].get(id), ...patch });

		queUpdates();

		return new Promise((resolve) => resolvers[type].push(resolve));
	};

let updatesQueued = false;
const queUpdates = () => {
	if (updatesQueued) return;
	updatesQueued = true;

	Promise.resolve().then(() => {
		applyUpdates();
		updatesQueued = false;

		Object.values(patches).forEach((map) => map.clear());
	});
};

const applyUpdates = () => {
	for (const [type, patchesOfType] of Object.entries(patches) as Entries<typeof patches>) {
		for (const [id, patch] of patchesOfType) {
			supabase
				.from(type)
				// @ts-ignore: works, but I don't know how it could be typed
				.update(patch)
				.match({ id })
				.then(({ error }) => {
					error && console.error(error);
					resolvers[type].forEach((resolve) => resolve(null));
				}); // wont work without the then
		}
	}
};

export const sanitize = <T extends Partial<Sprint> | Partial<Story> | Partial<Task>>(data: T): IdentifierToType<T> => {
	const copy = { ...data };

	delete copy.localId;

	if ('sprint' in copy) delete copy.sprint;
	if ('story' in copy) delete copy.story;
	if ('stories' in copy) delete copy.stories;
	if ('tasks' in copy) delete copy.tasks;
	// if ('containingArray' in copy) delete copy.containingArray;

	return copy as unknown as IdentifierToType<T>;
};
