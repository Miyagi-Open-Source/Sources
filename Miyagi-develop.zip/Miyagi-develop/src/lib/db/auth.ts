// import 'lib/db/organization';
import { browser } from '$app/environment';
import type { Db_Profiles } from '$types/db-types';
import type { UserResponse } from '@supabase/supabase-js';
import { get, writable } from 'svelte/store';
import { supabase } from './';
import { getUser } from './user';
// import { CACHE } from '$lib/stores/cache';
import { dialog } from '$components/dialog/dialog-function/dialog-function';

export const userStore = writable<(UserResponse['data']['user'] & Partial<Db_Profiles>) | null>(null);

const init = async () => {
	const userResponse = await supabase.auth.getUser();
	userStore.set(userResponse.data.user);

	if (!userResponse.data.user) return;

	const user = await getUser(userResponse.data.user.id);
	userStore.set(Object.assign(user, get(userStore)));
};
init();

supabase.auth.onAuthStateChange(async (eventType, session) => {
	userStore.set(session?.user ?? null);

	if (!session) return;

	const user = await getUser(session.user.id);
	userStore.set(Object.assign(user, session.user));

	if (eventType === 'PASSWORD_RECOVERY') {
		const [password] = await dialog('Enter a new password', [
			{
				input: 'password',
			},
		]);

		if (!password) return;

		const { error } = await supabase.auth.updateUser({
			password,
		});

		if (error) {
			dialog('Error', {
				message: 'There was an error updating your password: ' + error.message,
			});
		}
	}
});

export const signUpWithEmail = ({ email, password, name }: { email: string; password: string; name: string }) =>
	supabase.auth.signUp({ email, password, options: { data: { name } } });

export const signInWithEmail = ({ email, password }: { email: string; password: string }) =>
	supabase.auth.signInWithPassword({ email, password });

export const signInWithGithub = () =>
	supabase.auth.signInWithOAuth({
		provider: 'github',
		options: {
			redirectTo: browser ? window.location.href : undefined,
		},
	});

export const signOut = () => {
	supabase.auth.signOut();
	localStorage.clear();
};

export const resetPassword = (email: string) =>
	supabase.auth.resetPasswordForEmail(email, {
		redirectTo: browser ? window.location.href : undefined,
	});
