import type { Db_UserFeedback_Insert } from '$types/db-types';
import { supabase } from '.';

export const createUserFeedback = async (feedback: Db_UserFeedback_Insert) => {
	const { error } = await supabase.from('user-feedback').insert(feedback);
	if (error) throw error;
};
