import type { Database } from '$types/db-types';
import { createClient } from '@supabase/auth-helpers-sveltekit';
import { createClient as createServerClient } from '@supabase/supabase-js';
// import { env } from '$env/dynamic/public';

export const supabase = createClient(import.meta.env.VITE_SUPABASE_URL!, import.meta.env.VITE_SUPABASE_KEY!, {
	global: {
		// fetch: browser ? (url, options) => fetch(url, { ...options, keepalive: true }) : undefined,
	},
	realtime: {
		// ?
	},
});

export const supabaseAdmin = createServerClient<Database>(
	import.meta.env.VITE_SUPABASE_URL!,
	import.meta.env.VITE_SUPABASE_SERVICE_ROLE!,
	{
		global: {
			// fetch: browser ? (url, options) => fetch(url, { ...options, keepalive: true }) : undefined,
		},
		realtime: {
			// ?
		},
	}
);
