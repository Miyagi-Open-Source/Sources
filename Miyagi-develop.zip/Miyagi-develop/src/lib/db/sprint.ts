import { supabase } from './';
import { createBatchedUpdateFunction } from './common';

import type { Db_Project, Db_Sprint, Db_Sprint_Insert } from '$types/db-types';
import type { NotNull } from '$types/helper';

export const getActiveSprintsOfProject = async (projectId: number) => {
	const { data, error } = await supabase
		.from('sprint')
		.select(`*`)
		.match({
			isActive: true,
			projectId,
		})
		.limit(1); // once we use rls, we should only get the backlog for the current project by default

	if (error) throw error;

	return data;
};

export const getPastSprintsOfProject = async (projectId: number) => {
	const { data, error } = await supabase
		.from('sprint')
		.select(`*`)
		.match({
			isProjectBacklog: false,
			projectId,
		})
		.not('endDate', 'is', null)
		.order('startDate');

	if (error) throw error;

	return data;
};

export const getFutureSprintsOfProject = async (projectId: number) => {
	const { data, error } = await supabase
		.from('sprint')
		.select(`*`)
		.match({
			isProjectBacklog: false,
			isActive: false,
			projectId,
		})
		.is('endDate', null)
		.order('startDate');

	if (error) throw error;

	return data;
};

export const getBacklogSprintOfProject = async (projectId: number) => {
	const { data, error } = await supabase
		.from('sprint')
		.select(`*`)
		.match({
			isProjectBacklog: true,
			isActive: false,
			projectId,
		})
		.limit(1); // once we use rls, we should only get the backlog for the current project by default

	if (error) throw error;

	return data;
};

export const getSprint = async (id: Db_Sprint['id']) => {
	const { data, error } = await supabase.from('sprint').select('*').match({ id });
	if (error) throw error;

	return data[0];
};

export const updateSprint = createBatchedUpdateFunction('sprint');

export const deleteSprint = async (id: Db_Sprint['id']) => {
	const { error } = await supabase.from('sprint').delete().match({ id });
	if (error) throw error;
};

export const createSprint = async (sprint: Db_Sprint_Insert) => {
	const { data, error } = await supabase.from('sprint').insert(sprint).select('*');
	if (error) throw error;

	return data[0];
};

export const getSprintByDisplayId = async (displayId: NotNull<Db_Sprint['displayId']>, projectId: Db_Project['id']) => {
	const { data, error } = await supabase
		.from('sprint')
		.select('*, project!inner(id)')
		.match({ displayId })
		.eq('project.id', projectId);
	if (error) throw error;

	return (data as Db_Sprint[]).sort((sprintA, sprintB) =>
		sprintA.isActive ? -1 : sprintB.isActive ? 1 : sprintA.updated_at > sprintB.updated_at ? -1 : 1
	)[0];
};
