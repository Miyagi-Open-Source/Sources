import type { Db_Profiles } from '$types/db-types';
import { supabase } from './';

export const getUsers = async () => {
	const { data, error } = await supabase.from('profiles').select('*');
	if (error) throw error;

	return data;
};

export const getUser = async (id: Db_Profiles['id']) => {
	const { data, error } = await supabase.from('profiles').select('*').match({ id });
	if (error) throw error;

	return data[0];
};
