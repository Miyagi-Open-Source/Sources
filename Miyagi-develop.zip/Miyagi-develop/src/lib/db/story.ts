import { supabase } from './';
import { createBatchedUpdateFunction } from './common';

import type { Db_Project, Db_Story, Db_Story_Insert } from '$types/db-types';
import type { NotNull } from '$types/helper';
import { asNotArray } from '$lib/helper';

// Every Function that gets multiple stories should sort them.

export const getStoriesOfSprint = async (sprintId: number) => {
	const { data, error } = await supabase.from('story').select(`*`).match({ sprintId });
	if (error) throw error;

	return data.sort((a, b) => a.sequence - b.sequence);
};

export const updateStory = createBatchedUpdateFunction('story');

export const deleteStory = async (id: Db_Story['id']) => {
	const { error } = await supabase.from('story').delete().match({ id });
	if (error) throw error;
};

export const createStory = async (story: Db_Story_Insert) => {
	const { data, error } = await supabase.from('story').insert(story).select('*'); // TODO sanitize;
	if (error) throw error;

	return data[0];
};

export const getStoryByDisplayId = async (displayId: NotNull<Db_Story['displayId']>, projectId: Db_Project['id']) => {
	const { data, error } = await supabase
		.from('story')
		.select('*, sprint!inner(isActive, updated_at, project!inner(id))')
		.match({ displayId })
		.eq('sprint.project.id', projectId);
	if (error) throw error;

	return data.sort((storyA, storyB) => {
		const sprintA = asNotArray(storyA!.sprint!);
		const sprintB = asNotArray(storyB!.sprint!);

		return sprintA.isActive ? -1 : sprintB.isActive ? 1 : sprintA.updated_at > sprintB.updated_at ? -1 : 1;
	})[0];
};

export const getStory = async (id: Db_Story['id']) => {
	const { data, error } = await supabase.from('story').select('*').match({ id });
	if (error) throw error;

	return data[0];
};
