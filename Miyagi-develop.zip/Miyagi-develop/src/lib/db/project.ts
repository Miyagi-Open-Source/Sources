import { supabase } from './';
import type { Db_InviteCode, Db_Organization, Db_Project, Db_Project_Insert, Db_Project_Update } from '$types/db-types';
import { get } from 'svelte/store';
import { userStore } from './auth';
import { noop, without } from '$lib/helper';
import type { UserProfile } from '$types/user';
import type { UserProjectRoles } from '$types/userProjectRoles';

export const getProject = async (id: number) => {
	const { data, error } = await supabase.from('project').select('*').match({ id });
	if (error) throw error;

	return data[0];
};

export const updateProject = async (id: number, patch: Db_Project_Update) => {
	const { error } = await supabase.from('project').update(patch).match({ id });
	if (error) throw error;
};

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export const deleteProject = async (id: number) => {
	const { error } = await supabase.from('project').delete().match({ id });
	if (error) throw error;
};

export const createProject = async (project: Db_Project_Insert) => {
	const { id } = get(userStore)!;

	const { data, error } = await supabase.from('project').insert(project).select('*');
	if (error) throw error;

	supabase.from('userProjectRoles').insert({ userId: id, projectId: data[0].id, role: 'admin' }).then(noop);

	return data[0];
};

const getProjectsOfUserCache: Map<UserProfile['id'], (Db_Project & UserProjectRoles)[]> = new Map();
export const clearProjectsOfUserCache = () => getProjectsOfUserCache.clear();
export const getProjectsOfUser = async (userId: UserProfile['id']) => {
	if (getProjectsOfUserCache.has(userId)) return getProjectsOfUserCache.get(userId)!;
	const { data, error } = await supabase
		.from('project')
		.select('*, role:userProjectRoles (*)')
		.eq('role.userId', userId);

	if (error) throw error;

	const formatted = (data as (Db_Project & { role: UserProjectRoles[] })[])
		.filter((data) => data.role.length !== 0)
		.map((project) => Object.assign(without(project, 'role'), project.role[0]));

	getProjectsOfUserCache.set(userId, formatted);
	return formatted;
};

export const getJoinedProjectsOfUser = async (userId: UserProfile['id']) =>
	getProjectsOfUser(userId).then((projects) => projects.filter((project) => project.accepted));
export const getInvitedProjectsOfUser = async (userId: UserProfile['id']) =>
	getProjectsOfUser(userId).then((projects) => projects.filter((project) => !project.accepted));

export const getProjectsOfOrganization = async (organizationId: Db_Organization['id']) => {
	const { id } = get(userStore)!;

	const projectsOfUser = await getProjectsOfUser(id);
	const getProjectsOfOrganization = projectsOfUser.filter(({ organizationId: orgId }) => orgId === organizationId);

	return getProjectsOfOrganization;
};

// Members

export const getMembers = async (projectId: Db_Project['id']) => {
	const { data, error } = await supabase.from('userProjectRoles').select('*, profiles(*)').eq('projectId', projectId);
	if (error) throw error;

	return data.map((data) => {
		Object.assign(data, data['profiles']);
		// eslint-disable-next-line @typescript-eslint/no-unused-vars
		const { profiles, ...rest } = data;
		return rest;
	}) as unknown as (UserProfile & UserProjectRoles)[];
};

export const updateMemberRole = async (
	userId: UserProfile['id'],
	projectId: Db_Project['id'],
	role: UserProjectRoles['role']
) => {
	const { error } = await supabase.from('userProjectRoles').update({ role }).match({ userId, projectId });

	if (error) throw error;
};

export const removeMember = async (userId: UserProfile['id'], projectId: Db_Project['id']) => {
	const { error } = await supabase.from('userProjectRoles').delete().match({ userId, projectId });

	if (error) throw error;
};

export const acceptInvite = async (userId: UserProfile['id'], projectId: Db_Project['id']) => {
	const { error } = await supabase.from('userProjectRoles').update({ accepted: true }).match({ userId, projectId });
	if (error) throw error;
};

export const declineInvite = async (userId: UserProfile['id'], projectId: Db_Project['id']) => {
	const { error } = await supabase.from('userProjectRoles').delete().match({ userId, projectId });
	if (error) throw error;
};

// Invite Codes

export const getInviteCodes = async (projectId: Db_Project['id']) => {
	const { data, error } = await supabase.from('inviteCode').select('*').match({ projectId });
	if (error) throw error;

	return data;
};

export const deleteInviteCodes = async (projectId: Db_Project['id'], code: Db_InviteCode['code']) => {
	const { data, error } = await supabase.from('inviteCode').delete().match({ projectId, code });
	if (error) throw error;

	return data;
};
