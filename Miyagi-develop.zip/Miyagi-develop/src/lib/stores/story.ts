import { inplaceFilter } from '$lib/helper';
import { dataToObject } from '$lib/dataToObject';
import type { Db_Story } from '$types/db-types';
import { getRegistered } from './register';
import { CACHE } from './cache';
import { toSort } from './uiUpdate';
import { dialog } from '$components/dialog/dialog-function/dialog-function';

export const dataToStory = (data: Db_Story) =>
	dataToObject(
		'story',
		data,
		{
			// insert: async () => null,
			async update(patch) {
				if (patch.sprintId) {
					if (this.sprint.id === patch.sprintId) return patch;

					const newSprint = getRegistered({ type: 'sprint', id: patch.sprintId });
					const oldSprint = this.sprint;
					if (newSprint.project !== oldSprint.project)
						throw new Error('cannot move story to sprint in different project');

					this.sprint = newSprint;
					inplaceFilter(oldSprint.stories, (story) => story.id !== this.id);
					newSprint.stories.push(this);
					toSort.add(newSprint.stories);

					CACHE.set(newSprint);
					CACHE.set(oldSprint);
				}
				return patch;
			},
			delete: () => null,
			async beforeUpdate(patch) {
				if (!patch.sprintId || patch.sprintId === this.sprint.id) return patch;

				const newSprint = getRegistered({ type: 'sprint', id: patch.sprintId });
				if (!newSprint.isRunning) return patch;

				const startSequence = this.sequence;
				const [confirmMoveToRunningSprint] = await dialog(
					`Are you sure you want to move this story to the running sprint ${newSprint.name}?`
				);

				if (!confirmMoveToRunningSprint) {
					patch.sequence = startSequence - 1; // go back to the original sequence, but other item has moved there, so sub one to move before, sort is stable, so after previous item
					patch.sprintId = undefined;
				}
				return patch;
			},
		},
		true
	);
