import { dataToObject } from '$lib/dataToObject';
import type { Db_Task } from '$types/db-types';

export const dataToTask = (data: Db_Task) =>
	dataToObject(
		'task',
		data,
		{
			// insert: async () => null,
			// update: (patch) => patch,
			delete: () => null,
		},
		true
	);
// dataTo["task"] = dataToTask;

export const fakeStatusSymbol = Symbol('fakeStatus');
