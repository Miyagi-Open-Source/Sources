import { dataToOrganization } from '$lib/stores/organization';
import { dataToProject } from '$lib/stores/project';
import { dataToSprint } from '$lib/stores/sprint';
import { dataToStory } from '$lib/stores/story';
import { dataToTask } from '$lib/stores/task';

import type { StringToTable, StringToType, TypeString } from '$types/hierarchy';

export const dataTo = {} as {
	[K in TypeString]: (data: StringToTable<K>['Row']) => StringToType<K>;
};

/**
 * Prevents circular dependencies
 */
export const initDataTo = () => {
	dataTo.organization = dataToOrganization;
	dataTo.project = dataToProject;
	dataTo.sprint = dataToSprint;
	dataTo.story = dataToStory;
	dataTo.task = dataToTask;
};
setTimeout(initDataTo, 0);
