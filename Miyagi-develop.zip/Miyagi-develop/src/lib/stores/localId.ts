import type { Optional } from '$types/helper';
import type { StringToType, TypeString, TypeType } from '$types/hierarchy';
import { childrenProperties } from './hierarchy';

type ClaimedIds = {
	[K in TypeString]: Map<StringToType<K>['id'] | symbol, number>;
};

/**
 * Make sure Cached and Live objects share the same localId
 */
const claimedLocalIds: ClaimedIds = Object.fromEntries(
	Object.keys(childrenProperties).map((typeString) => [typeString, new Map()] as const)
) as ClaimedIds;

const get = ({ id, type }: Optional<Pick<TypeType, 'id' | 'type'>, 'id'>) => {
	const localIdsOfType = claimedLocalIds[type];

	if (id && localIdsOfType.has(id)) return localIdsOfType.get(id) as number;

	const newLocalId = localIdsOfType.size + 1;
	localIdsOfType.set(id ?? Symbol('unknown id'), newLocalId);

	return newLocalId;
};

export const LOCALID = { get };
