import { inplaceFilter } from '$lib/helper';
import type { Subscriber, Writable } from 'svelte/store';

export const createStore = <T>(value: T) => {
	const subscribers: Subscriber<T>[] = [];

	// eslint-disable-next-line @typescript-eslint/no-unused-vars
	const subscribe: Writable<T>['subscribe'] = (run, _invalidate) => {
		// console.trace("subscribe - run", run);

		subscribers.push(run);
		run(value);

		return () => {
			// console.log("unsubscribe");
			inplaceFilter(subscribers, (s) => s !== run);
		};
	};

	const set: Writable<T>['set'] = (newValue) => {
		// console.log("set - newValue", newValue);
		value = newValue;

		informSubscribers();
	};

	const update: Writable<T>['update'] = (updater) => {
		// console.log("update - updater", updater);
		value = updater(value);

		informSubscribers();
	};

	const informSubscribers = () => subscribers.forEach((subscriber) => subscriber(value));

	const get = () => value;

	return {
		subscribe,
		set,
		update,
		get,
	};
};
