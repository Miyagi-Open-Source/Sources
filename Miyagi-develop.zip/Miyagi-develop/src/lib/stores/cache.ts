import { originalTarget } from '$lib/helper';
import type { StringToType, TypeString, TypeType } from '$types/hierarchy';
import { childrenProperties } from './hierarchy';
import { LOCALID } from './localId';
import { editingDisabled } from '../symbols';
import type { Project } from '$types/project';
import { awaitLoaded } from '$lib/handlers';

type Identifier<TType extends TypeType> = Pick<TType, 'id' | 'type'>;

export const fromCache = Symbol('fromCache');

const handler = <TType extends TypeType>(identifier: Identifier<TType>) => {
	let loaded = false;
	return {
		get: (target: TypeType | Record<string, unknown>, prop: keyof TypeType) => {
			if (!loaded) {
				loaded = true;
				Object.assign(target, get(identifier));
			}

			return (target as TypeType)[prop];
		},
		apply: () => {
			throw new Error('cant await data to be loaded on cached objects');
		},
	};
};

export const lazyLoader = <TString extends TypeString>(
	identifier: { id: TypeType['id']; type: TString },
	obj: Record<string, unknown>
) => new Proxy(obj, handler(identifier)) as unknown as StringToType<TString>;
export const lazyLoaderDefault = <TType extends TypeType>(identifier: Identifier<TType>) => lazyLoader(identifier, {});

const cacheCache = new Map<string, TypeType>();

const get = <TType extends TypeType>({ type, id }: Identifier<TType>) => {
	const key = `${type}-${id}`;

	if (cacheCache.has(key)) return cacheCache.get(key) as TType;

	const value = localStorage.getItem(key);
	if (!value) return null;

	const parsed = JSON.parse(value);
	if (!parsed.id || !parsed.type) return null; // only load valid data

	const childrenKeys = Object.keys(childrenProperties[type]);
	childrenKeys.forEach((key) => {
		if (key in parsed) {
			parsed[key] = parsed[key].filter((obj) => 'type' in obj && 'id' in obj).map(lazyLoaderDefault);
		} else {
			parsed[key] = [];
		}
	});

	parsed[editingDisabled] = true;
	parsed[fromCache] = true;
	parsed.localId = LOCALID.get(parsed);

	cacheCache.set(key, parsed);
	return parsed as TType;
};

const keysToNotStore = ['localId', 'story', 'sprint', 'project', 'organization'];

const set = (obj: TypeType) => {
	obj = (obj as TypeType & { [originalTarget]?: TypeType })[originalTarget] ?? obj;

	const existingData = get(obj);
	if (existingData) obj = Object.assign(existingData, obj);

	if (!('projectTag' in obj)) {
		const objWithProjectTag = obj as TypeType & { projectTag: string };

		if (obj.type === 'task') objWithProjectTag.projectTag = obj.story.sprint.project.tag;
		else if (obj.type === 'story') objWithProjectTag.projectTag = obj.sprint.project.tag;
		else if (obj.type === 'sprint') objWithProjectTag.projectTag = obj.project.tag;
	}

	const { type, id } = obj;
	const key = `${type}-${id}`;
	const childrenTypes = Object.keys(childrenProperties[type]);

	localStorage.setItem(
		key,
		JSON.stringify(obj, (key, value) => {
			if (childrenTypes.includes(key)) return (value as Identifier<TypeType>[]).map(({ type, id }) => ({ type, id }));
			if (keysToNotStore.includes(key)) return undefined;
			return value;
		})
	);
};

const deleteEntry = ({ type, id }: Identifier<TypeType>) => localStorage.removeItem(`${type}-${id}`);

const clear = () => localStorage.clear();

const loadProject = async (project: Project) => {
	if (!project) return;

	const sprints = (
		await Promise.all(
			(Object.keys(childrenProperties.project) as (keyof (typeof childrenProperties)['project'])[]).map((key) =>
				project[awaitLoaded](key)
			)
		)
	).flat();

	const stories = (await Promise.all(sprints.map((sprint) => sprint[awaitLoaded]('stories')))).flat();
	await Promise.all(stories.map((story) => story[awaitLoaded]('tasks')));

	return;
};

export const CACHE = { get, set, deleteEntry, clear, loadProject };
