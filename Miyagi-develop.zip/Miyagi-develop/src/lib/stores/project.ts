import { dataToObject } from '$lib/dataToObject';
import { getMembers, removeMember, updateMemberRole, getInviteCodes, deleteInviteCodes } from '$lib/db/project';
import { GET } from '$lib/helper';
import type { Db_Project } from '$types/db-types';
import type { Project } from '$types/project';
import { CACHE } from './cache';
import { updateUi } from './uiUpdate';

export const dataToProject = (data: Db_Project) => {
	const project = dataToObject(
		'project',
		data,
		{
			// insert: async () => null,
			update: async (patch) => {
				if (patch.tag) {
					CACHE.clear();
					CACHE.loadProject(project);
				}
				return patch;
			},
			delete: () => null,
			onLoad: ({ id }) => {
				getMembers(id).then((members) => {
					project.members = members;
					updateUi();
					CACHE.set(project);
				});

				getInviteCodes(id).then((codes) => {
					project.inviteCodes = codes;
					updateUi();
					CACHE.set(project);
				});
			},
		},
		true
	);

	project.members = project.members ?? (CACHE.get(project) as Project)?.members ?? [];
	project.inviteCodes = project.inviteCodes ?? (CACHE.get(project) as Project)?.inviteCodes ?? [];

	project.inviteMember = async (email) => {
		const { data: member, error } = await GET({
			action: 'inviteUserUsingEmail',
			email,
			projectId: project.id,
		});

		if (error)
			return {
				error,
				data: null,
			};

		project.members.push(member);
		updateUi();

		return {
			data: true,
			error: null,
		};
	};

	project.removeMember = (userId) => {
		removeMember(userId, project.id);
		project.members = project.members.filter((member) => member.userId !== userId);
		updateUi();

		GET({
			action: 'informUserOfKickFromProject',
			userId,
			projectId: project.id,
		});
	};

	project.updateMemberRole = (userId, role) => {
		updateMemberRole(userId, project.id, role);
		project.members.find((member) => member.userId === userId)!.role = role;
		updateUi();
	};

	project.createInviteCode = (code, role, maxUses, endDate) => {
		project.inviteCodes.push({
			code,
			role,
			maxUses,
			endDate: endDate && endDate.toISOString(),
			useCount: 0,
		});
		updateUi();

		GET({
			action: 'createInviteCode',
			code,
			projectId: project.id,
			role,
			maxUses,
			endDate: endDate && endDate.toISOString(),
		});
	};

	project.deleteInviteCode = (code) => {
		project.inviteCodes = project.inviteCodes.filter((inviteCode) => inviteCode.code !== code);
		updateUi();

		deleteInviteCodes(project.id, code);
	};

	return project;
};
