import { writable } from 'svelte/store';
import uFuzzy from '@leeoniya/ufuzzy';

type WithSearchTerms = Record<string, unknown> & {
	searchTerms: string;
};

export interface SearchStoreModel<T extends WithSearchTerms> {
	data: T[];
	filtered: T[];
	search: string;
}

export const createSearchStore = <T extends WithSearchTerms>(data: T[]) =>
	writable<SearchStoreModel<T>>({
		data,
		filtered: data,
		search: '',
	});

const uf = new uFuzzy({
	intraMode: 1,
});

export const searchHandler = <T extends WithSearchTerms>(store: SearchStoreModel<T>) => {
	const searchTerm = store.search.toLowerCase() || '';
	let newFiltered;
	try {
		newFiltered = searchTerm.trim()
			? uf
					.filter(
						store.data.map((item) => item.searchTerms),
						searchTerm
					)
					.map((index) => store.data[index])
			: store.data;
	} catch (error) {
		newFiltered = store.data;
	}
	if (
		newFiltered.length !== store.filtered.length ||
		newFiltered.some((item, index) => item !== store.filtered[index])
	) {
		store.filtered = newFiltered;
	}
};
