import { browser } from '$app/environment';
import { userStore } from '$lib/db/auth';
import { getUsersOrganizations } from '$lib/db/organization';
import { subscriptionWithValue } from '$lib/helper';
import { dataToObject } from '$lib/dataToObject';
import type { Db_Organization } from '$types/db-types';
import { get } from 'svelte/store';

import { createOrganization as Db_CreateOrganization } from '$lib/db/organization';
import { CACHE, lazyLoader } from './cache';
import { updateUi } from './uiUpdate';
import type { Organization } from '$types/organization';
import { organizations } from '.';

export const dataToOrganization = (data: Db_Organization) => {
	const organization = dataToObject('organization', data, {
		// update: (patch) => patch,
		delete: ({ id }) => deleteOrganization(id),
	});

	const originalCreateProject = organization.createProject;

	organization.createProject = async (data) => {
		const project = await originalCreateProject(data);
		project.createSprint(
			{
				name: `First sprint of ${project.name}!`,
				isActive: true,
			},
			'currentSprint'
		);
		project.createSprint(
			{
				name: `backlogSprint of ${project.name}!`,
				isProjectBacklog: true,
			},
			'backlogSprint'
		);

		CACHE.set(project);
		updateUi();

		return project;
	};

	return organization;
};

const loadOrganizationsFromCache = () => {
	if (!browser) return;

	const organizationsData = localStorage.getItem('organizations');
	if (!organizationsData) return;

	const parsed: Pick<Organization, 'type' | 'id'>[] = JSON.parse(organizationsData);
	const newOrganizations = parsed.map((data) => lazyLoader(data, { members: [] }));

	organizations.set(newOrganizations);
};

const saveOrganizationsToCache = () => {
	if (!browser) return;

	const organizationsData = get(organizations);
	const toCache = organizationsData.map(({ id, type }) => ({ id, type }));
	localStorage.setItem('organizations', JSON.stringify(toCache));
};

const init = async () => {
	loadOrganizationsFromCache();

	const userId = (await subscriptionWithValue(userStore)).id;
	const organizationsData = await getUsersOrganizations(userId);

	organizations.set(organizationsData.map(dataToOrganization));
	saveOrganizationsToCache();
};
setTimeout(() => {
	init();
}, 0);

export const createOrganization = async (name: Db_Organization['name']) => {
	const user = get(userStore);
	if (!user) return;

	const newOrganizationData = await Db_CreateOrganization(name);
	const newOrganization = dataToOrganization(newOrganizationData);

	organizations.update((orgs) => [...orgs, newOrganization]);
	saveOrganizationsToCache();
};

export const deleteOrganization = async (id: Db_Organization['id']) => {
	organizations.update((orgs) => orgs.filter((org) => org.id !== id));
};
