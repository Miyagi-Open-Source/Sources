import { browser } from '$app/environment';
import { page } from '$app/stores';
import { derived, get } from 'svelte/store';
import { organizations } from '$lib/stores';

export const currentProject = derived(
	[page, organizations],
	([
		{
			params: { organization, project },
		},
		organizations,
	]) => organizations.find(({ id }) => id === organization)?.projects.find(({ id }) => id === project)
);

// eslint-disable-next-line @typescript-eslint/no-explicit-any
if (browser) (window as any).currentProject = () => get(currentProject);
