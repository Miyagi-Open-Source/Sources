import type { Organization } from '$types/organization';
import { createStore } from './store';
export const organizations = createStore<Organization[]>([]);
