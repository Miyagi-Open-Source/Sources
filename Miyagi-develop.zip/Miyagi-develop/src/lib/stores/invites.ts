import { clearProjectsOfUserCache, getInvitedProjectsOfUser } from '$lib/db/project';
import { subscriptionWithValue } from '$lib/helper';
import { userStore } from '$lib/db/auth';
import { get, writable, type Writable } from 'svelte/store';

export const invites: Writable<Awaited<ReturnType<typeof getInvitedProjectsOfUser>>> = writable([]);
subscriptionWithValue(userStore).then(({ id }) => checkForUpdates(id));

export const checkForUpdates = async (id = get(userStore)?.id) => {
	if (!id) return;

	clearProjectsOfUserCache();
	invites.set(await getInvitedProjectsOfUser(id));
};
