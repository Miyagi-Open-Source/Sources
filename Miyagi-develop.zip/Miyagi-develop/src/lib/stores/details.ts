import type { Sprint } from '$types/sprint';
import type { Story } from '$types/story';
import type { Task } from '$types/task';
import { writable } from 'svelte/store';

type OpenDetails = {
	sprint: Record<Sprint['id'], boolean>;
	story: Record<Story['id'], boolean>;
	task: Record<Task['id'], boolean>;
};

export const openDetails = writable<OpenDetails>({
	sprint: {},
	story: {},
	task: {},
});
