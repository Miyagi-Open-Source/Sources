import { createOrganization, deleteOrganization, updateOrganization } from '$lib/db/organization';
import { createProject, deleteProject, getProjectsOfOrganization, updateProject } from '$lib/db/project';
import {
	createSprint,
	deleteSprint,
	getActiveSprintsOfProject,
	getBacklogSprintOfProject,
	getFutureSprintsOfProject,
	getPastSprintsOfProject,
	updateSprint,
} from '$lib/db/sprint';
import { createStory, deleteStory, getStoriesOfSprint, updateStory } from '$lib/db/story';
import { createTask, deleteTask, getTasksOfStory, updateTask } from '$lib/db/task';
import type { TypeHierarchyParent } from '$types/hierarchy';

export const childrenProperties = {
	organization: {
		projects: {
			type: 'project',
			function: getProjectsOfOrganization,
		},
	},
	project: {
		futureSprints: {
			type: 'sprint',
			function: getFutureSprintsOfProject,
		},
		currentSprint: {
			type: 'sprint',
			function: getActiveSprintsOfProject,
		},
		pastSprints: {
			type: 'sprint',
			function: getPastSprintsOfProject,
		},
		backlogSprint: {
			type: 'sprint',
			function: getBacklogSprintOfProject,
		},
	},
	sprint: {
		stories: {
			type: 'story',
			function: getStoriesOfSprint,
		},
	},
	story: {
		tasks: {
			type: 'task',
			function: getTasksOfStory,
		},
	},
	task: {},
} as const;

export const Db_Functions = {
	organization: {
		create: createOrganization,
		update: updateOrganization,
		delete: deleteOrganization,
	},
	project: {
		create: createProject,
		update: updateProject,
		delete: deleteProject,
	},
	sprint: {
		create: createSprint,
		update: updateSprint,
		delete: deleteSprint,
	},
	story: {
		create: createStory,
		update: updateStory,
		delete: deleteStory,
	},
	task: {
		create: createTask,
		update: updateTask,
		delete: deleteTask,
	},
} as const;

export const parentType = Object.fromEntries(
	Object.keys(childrenProperties).map((childType) => [
		childType,
		Object.entries(childrenProperties).find(([, children]) => Object.values(children)[0]?.type === childType)?.[0],
	])
) as TypeHierarchyParent;

export type childrenPropertiesTypeHelper = {
	[Type in keyof typeof childrenProperties]: {
		[Key in keyof (typeof childrenProperties)[Type]]: (typeof childrenProperties)[Type][Key] & {
			key: Key;
		};
	};
};

export type childrenPropertiesType = {
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	[Type in keyof typeof childrenProperties]: childrenPropertiesTypeHelper[Type][keyof childrenPropertiesTypeHelper[Type]] extends Record<
		string,
		unknown
	>
		? childrenPropertiesTypeHelper[Type][keyof childrenPropertiesTypeHelper[Type]]
		: never;
};
