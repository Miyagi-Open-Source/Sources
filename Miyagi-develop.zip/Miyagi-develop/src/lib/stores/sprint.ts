import { inplaceFilter, pick } from '$lib/helper';
import { dataToObject } from '$lib/dataToObject';
import { awaitLoaded } from '$lib/handlers';
import type { Db_Sprint } from '$types/db-types';
import type { Sprint } from '$types/sprint';
import { toSort, updateUi } from './uiUpdate';
import { dialog } from '$components/dialog/dialog-function/dialog-function';
import { FORMAT } from '$lib/plural';

const handleNewActiveSprint = (newActiveSprint: Sprint) => {
	if (newActiveSprint.project.currentSprint[0]) {
		newActiveSprint.project.pastSprints.push(newActiveSprint.project.currentSprint[0]);
	}
	newActiveSprint.project.currentSprint = [newActiveSprint];
	inplaceFilter(newActiveSprint.project.futureSprints, (s) => s !== newActiveSprint);
};

export const dataToSprint = (data: Db_Sprint) => {
	const sprint = dataToObject(
		'sprint',
		data,
		{
			onLoad: (data) => {
				if (data.isActive != null && data.isActive) {
					handleNewActiveSprint(data);
				}
				return data;
			},
			update: async (patch) => {
				if (patch.isActive != null && sprint.isActive !== patch.isActive) {
					if (patch.isActive) {
						handleNewActiveSprint(sprint);
					} else if (patch.endDate || sprint.endDate) {
						inplaceFilter(sprint.project.currentSprint, (s) => s !== sprint);
						sprint.project.pastSprints.push(sprint);

						console.warn('Removed the currentsprint without a new replacement, this might be an error');
					} else {
						inplaceFilter(sprint.project.currentSprint, (s) => s !== sprint);
						sprint.project.futureSprints.push(sprint);
					}
				}
				if ('sequence' in patch && patch.sequence != null && patch.sequence !== sprint.sequence)
					toSort.add(sprint.project.futureSprints);

				return patch;
			},
			delete: () => null, // move stories to backlog
		},
		true
	);

	sprint.start = () => {
		if (!sprint.isActive) throw new Error('Sprint is not active');
		if (sprint.isRunning) throw new Error('Sprint is already running');

		sprint.update({
			isRunning: true,
			startDate: new Date().toISOString(),
		});
	};

	sprint.end = async () => {
		if (!sprint.isActive) throw new Error('Sprint is not active');
		if (!sprint.isRunning) throw new Error("Sprint hasn't started yet");

		await sprint.project[awaitLoaded]('futureSprints');
		await sprint.project[awaitLoaded]('backlogSprint');

		const { project } = sprint;

		const unfinishedStoriesFromPrevSprint = sprint.stories.filter((sprint) => sprint.status !== 'done');

		const askForMoveToBacklog = unfinishedStoriesFromPrevSprint.length !== 0;
		const askForNewSprint = project.futureSprints.length > 1;

		let newCurrentSprint: Sprint = project.futureSprints[0];
		let moveToBacklog = false;

		if (askForMoveToBacklog && askForNewSprint) {
			const [_newCurrentSprint, moveToNewSprint] = await dialog('End current Sprint', [
				{
					label: 'Select next Sprint:',
					input: 'sprint',
					sprints: project.futureSprints,
				},
				{
					label: `Move ${unfinishedStoriesFromPrevSprint.length} unfinished ${FORMAT.Story(
						unfinishedStoriesFromPrevSprint.length
					)} to backlog?`,
					input: 'boolean',
				},
			] as const);

			if (_newCurrentSprint === null) return;
			newCurrentSprint = _newCurrentSprint;
			moveToBacklog = !moveToNewSprint;
		} else if (askForMoveToBacklog) {
			const [moveToNewSprint] = await dialog('Unfinished Stories', {
				message: `Move ${unfinishedStoriesFromPrevSprint.length} unfinished ${FORMAT.Story(
					unfinishedStoriesFromPrevSprint.length
				)} to ${newCurrentSprint?.name ? `"${newCurrentSprint.name}"` : 'Backlog'} instead of new Sprint?`,
				cancelLabel: 'Move to Backlog',
				confirmLabel: 'Move to New Sprint',
			});

			if (moveToNewSprint === null) return;
			moveToBacklog = !moveToNewSprint;
		} else if (askForNewSprint) {
			const [chosenNewCurrentSprint] = await dialog('Select next Sprint:', [
				{
					input: 'sprint',
					sprints: project.futureSprints,
				},
			]);

			if (chosenNewCurrentSprint === null) return;
			newCurrentSprint = chosenNewCurrentSprint;
		} else {
			const [confirmed] = await dialog('End current Sprint', {
				message: `Are you sure you want to end the current Sprint?`,
			});

			if (!confirmed) return;
		}

		sprint.update({
			isRunning: false,
			isActive: false,
			endDate: new Date().toISOString(),
		});

		if (project.futureSprints.length === 0) {
			newCurrentSprint = await project.createSprint(
				{
					isActive: true,
					name: 'New Sprint',
				},
				'currentSprint'
			);
		} else {
			await Promise.all([
				newCurrentSprint.update({
					isActive: true,
				}),
				...newCurrentSprint.stories.map((story) =>
					story.update({
						sequence: story.sequence + unfinishedStoriesFromPrevSprint.length,
					})
				),
			]);
		}

		const sprintForUnfinishedStories = moveToBacklog ? project.backlogSprint[0] : newCurrentSprint;

		unfinishedStoriesFromPrevSprint.forEach(async (story, sequence) => {
			const newStory = await sprintForUnfinishedStories.createStory(
				Object.assign(pick(story, 'title', 'description', 'points', 'status', 'displayId'), {
					sequence,
				})
			);

			await Promise.all(
				story.tasks.map((task) =>
					newStory.createTask(pick(task, 'title', 'description', 'status', 'assigneeId', 'displayId'))
				)
			);
		});

		if (!moveToBacklog) toSort.add(newCurrentSprint.stories);
		updateUi();
	};

	return sprint;
};
