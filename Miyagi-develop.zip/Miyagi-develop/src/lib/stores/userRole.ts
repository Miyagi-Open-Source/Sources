import { userStore } from '$lib/db/auth';
import type { Role } from '$types/userProjectRoles';
import { derived } from 'svelte/store';
import { currentProject } from './currentProject';

export const userRole = derived([userStore, currentProject], ([userStore, currentProject]): Role => {
	if (!userStore) return 'unknown';

	const org = currentProject?.organization;
	if (!org) return 'unknown';

	if (userStore.id === org.owner) return 'owner';

	return currentProject?.members.find(({ id }) => id === userStore.id)!.role;
});

export const canEdit = derived(userRole, (userRole) => userRole !== 'guest' && userRole !== 'unknown');
