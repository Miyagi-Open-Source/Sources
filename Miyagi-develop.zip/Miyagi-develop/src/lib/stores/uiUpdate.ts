import { onceOnStackEmpty } from '$lib/helper';
import type { TypeType } from '$types/hierarchy';
import { parentType } from './hierarchy';
import { CACHE } from './cache';
import { organizations } from '.';
import { clearResultOptionsTypes } from '$lib/search';

export const toSort = new Set<({ sequence: number } & TypeType)[]>();
export const updateUi = onceOnStackEmpty(() => {
	toSort.forEach((arr) => {
		if (!arr.length) return;

		arr.sort((a, b) => a.sequence - b.sequence);

		const { type } = arr[0];
		const parentProperty = parentType[type];
		CACHE.set(arr[0][parentProperty as keyof (typeof arr)[0]] as unknown as TypeType);
	});

	toSort.clear();
	organizations.update((state) => state);
	clearResultOptionsTypes();
});
