import { childrenProperties } from '$lib/stores/hierarchy';
import type { Db_Project } from '$types/db-types';
import type { WithDisplayId } from '$types/helper';
import type { StringToType, TypeString, TypeToString, TypeType } from '$types/hierarchy';
import type { Sprint } from '$types/sprint';
import type { Story } from '$types/story';
import type { Task } from '$types/task';

export type Register = {
	[K in TypeString]: Record<StringToType<K>['id'], StringToType<K>>;
};

/**
 * lookup table to quickly find an object by it's id.
 * Used when getting server updates which only contain the id.
 */
export const register: Register = Object.fromEntries(
	Object.keys(childrenProperties).map((typeString) => [typeString, {}])
) as Register;

// export const getRegistered = <
// 	T extends { type: keyof Register; id: keyof Register[keyof Register] }
// >({
// 	type,
// 	id,
// }: T) => {
// 	const registered = register[type][id];
// 	if (!registered) throw new Error(`${type} ${id} not registered`);
// 	return registered;
// };

export const getRegistered = <TString extends TypeString>({ type, id }: { type: TString; id: TypeType['id'] }) => {
	const registered = register[type as TypeString][id];
	if (!registered) throw new Error(`${type} ${id} not registered`);
	return registered as StringToType<TString>;
};

export const getRegisteredByDisplayId = <TString extends TypeToString<WithDisplayId<TypeType>>>({
	type,
	displayId,
	projectId,
}: {
	type: TString;
	displayId: WithDisplayId<TypeType>['displayId'];
	projectId: Db_Project['id'];
}): StringToType<TString> | undefined =>
	(Object.values(register[type]) as (typeof register)[TString][string][])
		.sort((a, b) => {
			let sprintA: Sprint;
			let sprintB: Sprint;

			if (type === 'task') {
				sprintA = (a as Task).story.sprint;
				sprintB = (b as Task).story.sprint;
			} else if (type === 'story') {
				sprintA = (a as Story).sprint;
				sprintB = (b as Story).sprint;
			} else if (type === 'sprint') {
				sprintA = a as Sprint;
				sprintB = b as Sprint;
			} else {
				throw new Error('Invalid type');
			}

			return sprintA.isActive ? -1 : sprintB.isActive ? 1 : sprintA.updated_at > sprintB.updated_at ? -1 : 1;
		})
		.find((obj) => {
			if (obj.displayId !== displayId) return false;
			if (type === 'task') return (obj as Task).story.sprint.project.id === projectId;
			if (type === 'story') return (obj as Story).sprint.project.id === projectId;
			if (type === 'sprint') return (obj as Sprint).project.id === projectId;
		});

export const setRegistered = (obj: TypeType) => {
	register[obj.type][obj.id] = obj;
};

// @ts-ignore
export const isRegistered = (obj: Partial<Pick<TypeType, 'type' | 'id'>>): obj is Pick<TypeType, 'type' | 'id'> =>
	obj.type != null && obj.id != null && register[obj.type]?.[obj.id] != null;
