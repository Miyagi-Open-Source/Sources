import { cleanup, render } from '@testing-library/svelte';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest';
import ActionTest from './action-test-helper.svelte';
import shortcut from './shortcut';

beforeEach(cleanup);
afterEach(() => {
	vi.resetAllMocks();
});

describe('Action: Shortcut', () => {
	test('call func when keydown, only with correct key', async () => {
		const user = userEvent.setup();
		const mock = vi.fn();
		render(ActionTest, {
			props: {
				action: shortcut,
				actionParams: {
					key: 'K',
					func: mock,
				},
			},
		});

		await user.keyboard('J');
		expect(mock).not.toHaveBeenCalled();
		await user.keyboard('K');
		expect(mock).toHaveBeenCalledOnce();
	});

	test('call func when keydown, only together with cmd key', async () => {
		const user = userEvent.setup();
		const mock = vi.fn();
		render(ActionTest, {
			props: {
				action: shortcut,
				actionParams: {
					key: 'K',
					func: mock,
					cmd: true,
				},
			},
		});

		await user.keyboard('K');
		expect(mock).not.toHaveBeenCalled();
		await user.keyboard('{Meta>}K{/Meta}'); // key combination
		expect(mock).toHaveBeenCalledOnce();
	});
});
