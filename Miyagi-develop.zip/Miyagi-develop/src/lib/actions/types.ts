export type SvelteActionReturnType<P> = {
	update?: (newParams?: P) => void;
	destroy?: () => void;
} | void;

export type SvelteActionType<P> = <T extends HTMLElement>(node: T, params?: P) => SvelteActionReturnType<P>;

/* eslint-disable-next-line @typescript-eslint/no-explicit-any */
export type ActionEntry<P = any> = SvelteActionType<P> | [SvelteActionType<P>, P];

export type ActionArray = ActionEntry[];
