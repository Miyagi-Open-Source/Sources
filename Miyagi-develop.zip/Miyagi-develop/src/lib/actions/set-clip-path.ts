import { tick } from 'svelte';

export function setClipPath(
	node: HTMLElement,
	{ selector, insetShapeAppendix }: { selector?: string; insetShapeAppendix?: string }
) {
	const update = async ({ selector }: { selector?: string }) => {
		await tick();
		const selectedItem = selector && node.querySelector(selector);
		if (!selectedItem) return (node.style.clipPath = 'circle(0)');
		const itemRect = selectedItem.getBoundingClientRect();
		const barRect = node.getBoundingClientRect();
		const size = {
			top: itemRect.top - barRect.top,
			right: barRect.right - itemRect.right,
			bottom: barRect.bottom - itemRect.bottom,
			left: itemRect.left - barRect.left,
		};
		const sizeString = `${size.top}px ${size.right}px ${size.bottom}px ${size.left}px`;
		node.style.clipPath = `inset(${sizeString} ${insetShapeAppendix ? insetShapeAppendix : ''})`;
	};

	update({ selector });

	return {
		update,
	};
}
