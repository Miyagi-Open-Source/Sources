import type { SvelteActionReturnType } from './types';

interface Options {
	/** when the action should be active */
	enabled: boolean;
	/** callback function */
	func: (node: Node, event: MouseEvent) => void;
	/** CSS Selector to exclude form handling */
	exclude?: string;
}

/**
 * Registers a callback function that is called when the user clicks outside of the given node.
 * @param node Svelte Action Node
 * @param param Options
 */
export default function clickOutside(
	node: HTMLElement,
	{ enabled: initialEnabled, func, exclude }: Options
): SvelteActionReturnType<Partial<Options>> {
	function handleOutsideClick(event: MouseEvent) {
		if (node.contains(event.target as Node)) return;

		if (exclude) {
			const excludedNodes = Array.from(document.querySelectorAll(exclude)) as Array<HTMLElement>;
			for (const excludedNode of excludedNodes) {
				if (excludedNode.contains(event.target as Node)) {
					return;
				}
			}
		}

		event.stopPropagation();
		func(node, event);
	}

	function update({ enabled }: Partial<Options> | undefined = {}) {
		if (enabled) {
			window.addEventListener('click', handleOutsideClick, true);
		} else {
			window.removeEventListener('click', handleOutsideClick, true);
		}
	}

	update({ enabled: initialEnabled });

	return {
		update,
		destroy() {
			window.removeEventListener('click', handleOutsideClick, true);
		},
	};
}
