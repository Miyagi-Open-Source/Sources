import { cleanup, render } from '@testing-library/svelte';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest';
import ActionTest from './action-test-helper.svelte';
import { handleOnFocus } from './handle-on-focus';

beforeEach(cleanup);
afterEach(() => {
	vi.resetAllMocks();
});

describe('Action: handleOnFocus', () => {
	test('call func only when focused', async () => {
		const user = userEvent.setup();
		const mock = vi.fn();
		const { getByTestId } = render(ActionTest, {
			props: {
				thisTag: 'button',
				action: handleOnFocus(mock),
			},
		});

		await user.keyboard('C');
		expect(mock).not.toHaveBeenCalled();
		getByTestId('element').focus();
		await user.keyboard('C');
		expect(mock).toHaveBeenCalledOnce();
	});
});
