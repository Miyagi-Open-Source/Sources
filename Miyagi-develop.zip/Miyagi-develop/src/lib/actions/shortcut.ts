import type { SvelteActionReturnType } from './types';

interface Options {
	key: string;
	func: (node: HTMLElement) => void;
	cmd?: boolean;
}

/**
 * Registers a callback function to a global keyboard shortcut.
 * @param node Svelte Action Node
 * @param options Options: {key: KeyboardEvent.key; func: callback function; cmd: Cmd/Ctrl needs to be pressed?}
 */
export default function shortcut(
	node: HTMLElement,
	{ key, func, cmd = false }: Options
): SvelteActionReturnType<Options> {
	function handleKeydown(e: KeyboardEvent) {
		if (key.toLowerCase() !== e.key.toLowerCase()) return;

		if (cmd && !(e.ctrlKey || e.metaKey)) return;

		func(node);
	}

	document.addEventListener('keydown', handleKeydown);

	return {
		destroy() {
			document.removeEventListener('keydown', handleKeydown);
		},
	};
}
