import { cleanup, render } from '@testing-library/svelte';
import userEvent from '@testing-library/user-event';
import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest';
import ActionTest from './action-test-helper.svelte';
import clickOutside from './click-outside';

beforeEach(cleanup);
afterEach(() => {
	vi.resetAllMocks();
});

describe('Action: clickOutside', () => {
	test('call func only when clicking other element', async () => {
		const user = userEvent.setup();
		const mock = vi.fn();
		const { getByTestId } = render(ActionTest, {
			props: {
				thisTag: 'button',
				action: clickOutside,
				actionParams: {
					enabled: true,
					func: mock,
				},
			},
		});

		await user.click(getByTestId('element'));
		expect(mock).not.toHaveBeenCalled();
		await user.click(getByTestId('other-element'));
		expect(mock).toHaveBeenCalledOnce();
	});
});
