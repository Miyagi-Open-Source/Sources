import { getFocusable } from '$lib/focus';
import type { SvelteActionReturnType } from './types';

export function focusTrap(element: HTMLElement): SvelteActionReturnType<null> {
	let focusable = getFocusable(element);
	focusable[0].focus();

	function handleKeydown(event: KeyboardEvent) {
		focusable = getFocusable(element);
		if (event.key === 'Tab') {
			const currentFocusIndex = focusable.indexOf(document.activeElement as HTMLElement);
			event.preventDefault();

			if (event.shiftKey) {
				currentFocusIndex !== 0 ? focusable[currentFocusIndex - 1].focus() : focusable[focusable.length - 1].focus();
			} else {
				currentFocusIndex !== focusable.length - 1 ? focusable[currentFocusIndex + 1].focus() : focusable[0].focus();
			}
		}
	}

	element.addEventListener('keydown', handleKeydown);

	return {
		destroy() {
			element.removeEventListener('keydown', handleKeydown);
		},
	};
}
