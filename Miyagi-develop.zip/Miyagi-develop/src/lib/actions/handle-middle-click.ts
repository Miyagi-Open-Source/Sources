export const handleMiddleClick = (node: HTMLElement) => {
	const handleClick = (event: MouseEvent) => {
		if (event.button === 1) {
			node.dispatchEvent(new CustomEvent('handleMiddleClick'));
		}
	};

	node.addEventListener('mousedown', handleClick);

	return {
		destroy: () => node.removeEventListener('mousedown', handleClick),
	};
};
