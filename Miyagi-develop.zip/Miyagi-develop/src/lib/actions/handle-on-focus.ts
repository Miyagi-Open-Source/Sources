import type { SvelteActionType } from './types';

type Func = (event: KeyboardEvent) => void;

/**
 * Wraps a KeyboardEvent handler in a Svelte Action that only listens when the element has focus.
 *
 * Useful for Keyboard navigation stuff.
 *
 * @param func callback function
 */
export function handleOnFocus(func: Func): SvelteActionType<Func> {
	return (node: HTMLElement) => {
		function handleFocusin() {
			node.addEventListener<'keydown'>('keydown', func);
		}

		function handleFocusout() {
			node.removeEventListener<'keydown'>('keydown', func);
		}

		node.addEventListener('focusin', handleFocusin);

		node.addEventListener('focusout', handleFocusout);

		return {
			destroy() {
				node.removeEventListener('focusin', handleFocusin);
				node.removeEventListener('focusout', handleFocusout);
			},
		};
	};
}
