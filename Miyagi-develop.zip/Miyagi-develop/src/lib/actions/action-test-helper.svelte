<script lang="ts">
	import type { SvelteActionType } from './types';

	export let thisTag = 'div';
	/* eslint-disable-next-line @typescript-eslint/no-explicit-any */
	export let action: SvelteActionType<any>;
	/* eslint-disable-next-line @typescript-eslint/no-explicit-any */
	export let actionParams: any = {};
</script>

<h1>ONLY TO BE USED IN UNIT TESTS</h1>

<div data-testid="other-element">some other element</div>
<svelte:element this={thisTag} use:action={actionParams} data-testid="element" />
