export const editingDisabled: unique symbol = Symbol('editing disabled');
export const focus: unique symbol = Symbol('focus title');
