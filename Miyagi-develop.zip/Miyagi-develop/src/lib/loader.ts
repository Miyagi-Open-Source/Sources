import { getRegistered, getRegisteredByDisplayId, isRegistered } from '$lib/stores/register';
import { getTaskByDisplayId as Db_getTaskByDisplayId, getTask } from '$lib/db/task';
import { getStoryByDisplayId as Db_getStoryByDisplayId, getStory } from '$lib/db/story';
import { getSprintByDisplayId as Db_getSprintByDisplayId, getSprint } from '$lib/db/sprint';
import type { StringToTable, TypeString, TypeToString, TypeType } from '$types/hierarchy';
import type { WithDisplayId } from '$types/helper';
import type { Db_Project } from '$types/db-types';

const getById =
	<T extends TypeString, TTable extends StringToTable<T>['Row']>(
		type: T,
		getter: (arg: TTable['id']) => Promise<TTable>
	) =>
	async (id: TTable['id']) =>
		isRegistered({
			type,
			id,
		})
			? getRegistered({
					type,
					id,
			  })
			: await getter(id);

export const getTaskById = getById('task', getTask);
export const getStoryById = getById('story', getStory);
export const getSprintById = getById('sprint', getSprint);

const getByDisplayId =
	<T extends TypeToString<WithDisplayId<TypeType>>, TTable extends StringToTable<T>['Row']>(
		type: T,
		getter: (displayId: TTable['displayId'], projectId: Db_Project['id']) => Promise<TTable>
	) =>
	async (displayId: TTable['displayId'], projectId: Db_Project['id']) =>
		getRegisteredByDisplayId({
			type,
			displayId,
			projectId,
		}) || (await getter(displayId, projectId));

export const getTaskByDisplayId = getByDisplayId('task', Db_getTaskByDisplayId);
export const getStoryByDisplayId = getByDisplayId('story', Db_getStoryByDisplayId);
export const getSprintByDisplayId = getByDisplayId('sprint', Db_getSprintByDisplayId);
