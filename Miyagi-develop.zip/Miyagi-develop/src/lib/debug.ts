import { browser } from '$app/environment';

const debugHandler = {
	deleteProperty: <T extends object>(target: T, property: keyof T) => {
		console.info('Deleted %s', property, target);
		return true;
	},
	set: <T extends object>(target: T, property: keyof T, value: T[keyof T]) => {
		target[property] = value;
		console.info('Set %s to %o', property, value, target);
		return true;
	},
};

export const debug = <T extends object>(target: T): T => new Proxy(target, debugHandler) as T;

if (browser) {
	const myWindow = window as unknown as Record<string, unknown>;
	myWindow.debug = debug;
}
