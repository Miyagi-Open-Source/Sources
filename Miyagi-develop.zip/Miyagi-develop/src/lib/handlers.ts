import type { Tables } from '$types/db-types';
import type { StringToTable, StringToType, TypeHierarchy, TypeString } from '$types/hierarchy';
import { childrenProperties, type childrenPropertiesType } from './stores/hierarchy';

import { CACHE, fromCache } from './stores/cache';

export const awaitLoaded = Symbol('awaitLoaded');

export const createHandler = <
	TString extends TypeString,
	TType extends StringToType<TString>,
	TChild extends StringToType<TypeHierarchy[TypeString]>
>(
	createFunction: (
		// @ts-ignore
		data: StringToTable<TypeHierarchy[TString]>['Insert'],
		property: string | number | symbol
	) => Promise<StringToType<TypeHierarchy[TString]>>, // todo use existing type on parent
	properties: Record<keyof TType, () => Promise<TChild[]>> // Todo not all `keyof TType`
) => {
	const loaded = Object.fromEntries(Object.keys(properties).map((prop) => [prop, false])) as Record<
		keyof childrenPropertiesType[TString],
		boolean
	>;

	const loadResolvers: {
		[K in keyof TType]?: ((value: unknown) => void)[];
	} = {};

	const handler = {
		get: (obj: TType, prop: keyof TType | typeof awaitLoaded) => {
			if (prop === awaitLoaded) {
				return (prop: keyof TType) =>
					new Promise((resolve) => {
						if (loadResolvers[prop] && loadResolvers[prop]?.length === 0) return resolve(obj[prop]); // already loaded

						// @ts-ignore
						loadResolvers[prop] = loadResolvers[prop] ? [...loadResolvers[prop], resolve] : [resolve];
						handler.get(obj, prop);
					});
			}
			if (!(prop in loaded)) return obj[prop];
			const lazyLoadProp = prop as keyof typeof loaded & keyof TType; // TS should be able to infer this

			if (loaded[lazyLoadProp] === true) return obj[lazyLoadProp];
			loaded[lazyLoadProp] = true;

			// @ts-ignore
			if (obj.id == null) return (obj[prop] = []);

			// @ts-ignore
			childrenProperties[obj.type][lazyLoadProp].function(obj.id).then((childrenData: Tables[TString]['Row'][]) => {
				// @ts-ignore
				obj[lazyLoadProp] = obj[lazyLoadProp].filter((el) => !el[fromCache]);
				// @ts-ignore
				childrenData.forEach((data) => createFunction(data, prop));
				loadResolvers[lazyLoadProp]?.forEach((resolver) => resolver(obj[lazyLoadProp]));
				loadResolvers[lazyLoadProp] = [];
				// updateUi();
			});

			// @ts-ignore
			obj[lazyLoadProp] = CACHE.get(obj)[lazyLoadProp] ?? [];
			return obj[lazyLoadProp];
		},
	};

	return handler;
};
