/** safely use `crypto.randomUUID()`, or if unavailable fallback to `Math.random()` */
export function randomUUID() {
	if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
		return crypto.randomUUID();
	} else {
		return Math.random().toString();
	}
}
