import { get, type Readable, type Unsubscriber } from 'svelte/store';

export const sleep = (duration: number) => new Promise((resolve) => setTimeout(resolve, duration));

export const waitForTrue = async (fn: () => unknown, waitDuration = 10) => {
	while (!fn()) await sleep(waitDuration);
	return;
};
/**
 * Creates a function that when called, will call the provided callback once (1) per unique arg once the js stack is empty.
 * Reason: Performance
 */
export const onceOnStackEmpty = <T>(callback: (arg?: T) => void, waitDuration = 50, maxWaitDuration = 200) => {
	let resolved = true;
	let reset = false;
	let curWaitDuration = 0;
	return async (arg?: T) => {
		reset = true;

		if (!resolved) return;

		resolved = false;
		reset = false;

		do {
			reset = false;
			await sleep(waitDuration);
			curWaitDuration += waitDuration;
		} while (reset && curWaitDuration < maxWaitDuration);

		curWaitDuration = 0;
		resolved = true;
		callback(arg);
	};
};

/**
 * Like a normal js proxy, but you can recover the original target using the Symbol`originalTarget`.
 */
export class RecoverableProxy<T extends object> {
	constructor(target: T, handler: ProxyHandler<T>) {
		return new Proxy(target, {
			...handler,
			get: (...args) => {
				if (args[1] === originalTarget) return target;
				if (args[1] === originalHandler) return handler;

				return (handler.get ?? Reflect.get)(...args);
			},
		});
	}
}
export const originalTarget: unique symbol = Symbol('target');
export const originalHandler: unique symbol = Symbol('handler');

/**
 * A Cache that can be garbage collected.
 */
export class WeakCache<TKey, TValue extends object> {
	#cache = new Map<TKey, WeakRef<TValue>>();
	#finalizationGroup = new FinalizationRegistry((key: TKey) => {
		const ref = this.#cache.get(key);
		if (ref && !ref.deref()) this.#cache.delete(key);
	});

	get = (key: TKey): TValue | undefined => this.#cache.get(key)?.deref();

	set = (key: TKey, value: TValue) => {
		this.#cache.set(key, new WeakRef(value));
		this.#finalizationGroup.register(value, key);
	};

	has = (key: TKey) => this.#cache.has(key);
}

export const isObject = (maybeObject: unknown): maybeObject is object =>
	maybeObject !== null && typeof maybeObject === 'object' && !Array.isArray(maybeObject);

export const without = <T>(obj: T, ...keys: (keyof T)[]) => {
	const result = { ...obj };
	for (const key of keys) delete result[key];
	return result;
};

export const pick = <T extends object>(obj: T, ...keys: (keyof T)[]) => {
	const result = {} as Pick<T, (typeof keys)[number]>;
	for (const key of keys) result[key] = obj[key];
	return result;
};

/**
 * Checks if any value in a is different compared to the value in b.
 */
export const hasChanges = <T extends Record<string | symbol, unknown>>(a: T, b: T) =>
	Object.entries(a).some(([key, value]) => value !== b[key]);

export const getChanges = <T extends Record<string | symbol, unknown>>(original: T, patch: T) =>
	Object.entries(patch).reduce((acc, [key, value]) => (original[key] === value ? acc : { ...acc, [key]: value }), {});

export const getNewEntries = <T extends Record<string | number | symbol, unknown>>(original: T, patch: T) =>
	Object.entries(patch).reduce((acc, [key, value]) => (key in original ? acc : { ...acc, [key]: value }), {});

/**
 * takes a readable and returns a promise which resolves when the value of the readable passes the condition.
 * @param readable readable to wait for
 * @param condition condition to check value against, by default checks if value is truthy
 */
export const subscriptionWithValue = <T>(
	readable: Readable<T>,
	condition: (value: T) => boolean = (value) => !!value
): Promise<Exclude<T, null | undefined>> =>
	new Promise<Exclude<T, null | undefined>>((resolve) => {
		const curValue = get(readable);
		if (condition(curValue)) return resolve(curValue as Exclude<T, null | undefined>);

		let unsubscribe: Unsubscriber;
		let first = true;
		// eslint-disable-next-line prefer-const
		unsubscribe = readable.subscribe((value) => {
			if (first) return (first = false);
			if (condition(value)) resolve(value as Exclude<T, null | undefined>);
			unsubscribe();
		});
	});

export const isEmpty = <T extends object>(obj: T) => Object.keys(obj).length === 0;

// eslint-disable-next-line @typescript-eslint/no-empty-function
export const noop = () => {};

export const capitalizeFirstLetter = (string: string) => string.charAt(0).toUpperCase() + string.slice(1);

export const inplaceFilter = <T>(arr: T[], filter: (arg: T, index: number, self: T[]) => boolean) =>
	arr.forEach((el, i) => (filter(el, i, arr) ? el : arr.splice(i, 1)));

export const unique = <T>(value: T, index: number, self: T[]) => self.indexOf(value) === index;
export const uniqueBy =
	<T, K extends keyof T>(by: K) =>
	(value: T, index: number, self: T[]) =>
		self.findIndex((cur) => cur[by] === value[by]) === index;

export const GET = (args: Record<string, string | number | null | undefined>, path = '/api') =>
	fetch(window.location.origin + path + '?' + new URLSearchParams(args as Record<string, string>)).then((res) =>
		res.json()
	);

export const resizeImage = async (file: File, width: number, height: number) => {
	const imageBitmap = await createImageBitmap(file, {
		resizeWidth: width,
		resizeHeight: height,
		resizeQuality: 'high',
	});

	return convertImageBitmapToBlob(imageBitmap);
};

async function convertImageBitmapToBlob(imageBitmap: ImageBitmap) {
	const canvas = document.createElement('canvas');
	canvas.width = imageBitmap.width;
	canvas.height = imageBitmap.height;

	const ctx = canvas.getContext('2d')!;
	ctx.drawImage(imageBitmap, 0, 0);

	const blob = await new Promise<Blob>((resolve) => canvas.toBlob((blob) => resolve(blob!), 'image/jpeg', 1));

	return blob;
}

export const notNull = <T>(value: T | null | undefined): T => value as T;
export const isUndefined = (value: unknown) => value as undefined;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const isAny = (value: unknown) => value as any;
export const inputElement = (value: EventTarget | null) => value as HTMLInputElement;
export const accessUndefined = <T>(obj: T) =>
	obj as {
		[key: string]: undefined;
	} & T;

const requestIdleCallbackFallback = (callback: IdleRequestCallback) => {
	const func =
		'requestIdleCallback' in navigator
			? requestIdleCallback
			: (callback: IdleRequestCallback) => setTimeout(callback, 50);
	return func(() =>
		callback({
			didTimeout: false,
			timeRemaining: () => 0,
		})
	);
};

export const requestIdleCallbackAtLeast = (callback: IdleRequestCallback, atLeastTime: number) =>
	requestIdleCallbackFallback((deadline) => {
		if (deadline.timeRemaining() > Math.min(atLeastTime, 45)) {
			callback(deadline); // it seems chrome has a maximum of 49.9ms
		} else {
			requestIdleCallbackAtLeast(callback, atLeastTime);
		}
	});

type NotArray<T> = T extends Array<unknown> ? never : T;
export const asNotArray = <T>(a: T) => a as NotArray<T>;
