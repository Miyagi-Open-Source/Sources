<script>
	import { randomUUID } from '$lib/crypto';
	import Avatar from '.';
	export let Hst;

	let profile = {
		id: randomUUID(),
		// Cspell:disable
		username: 'Harley Edward Streten',
		avatarUrl: 'https://thispersondoesnotexist.com/image',
	};

	const sizes = ['small', 'medium'];

	const getSource = (size) => `<Avatar size="${size}" profile={user} />`;
</script>

<Hst.Story title="Avatar" layout={{ type: 'grid' }}>
	<svelte:fragment slot="controls">
		<Hst.Text bind:value={profile.id} title="profile.id" />
		<Hst.Text bind:value={profile.username} title="profile.username" />
		<Hst.Text bind:value={profile.avatarUrl} title="profile.avatarUrl" />
	</svelte:fragment>
	{#each sizes as size}
		<Hst.Variant title={size} source={getSource(size)}>
			<Avatar {profile} {size} />
		</Hst.Variant>
		<Hst.Variant title="{size} (w/o avatarUrl)" source={getSource(size)}>
			<Avatar profile={{ ...profile, avatarUrl: null }} {size} />
		</Hst.Variant>
	{/each}
</Hst.Story>
