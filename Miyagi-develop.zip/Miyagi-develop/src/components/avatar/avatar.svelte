<script lang="ts">
	import type { UserProfile } from '$types/user';
	import { randomDarkColor, randomLightColor } from 'seed-to-color';
	import IcBaselinePerson from '~icons/ic/baseline-person';
	import IcBaselinePersonOff from '~icons/ic/baseline-person-off';

	export let profile: Partial<UserProfile> | null = null;
	export let size: 'small' | 'medium' | 'large' = 'medium';

	$: name = profile?.username || '';
	$: imgSrc = profile?.avatarUrl || '';
	$: lightColor = '#' + randomLightColor(profile?.id || '');
	$: darkColor = '#' + randomDarkColor(profile?.id || '');
</script>

{#if imgSrc}
	<img class="circle {size}" src={imgSrc} alt={name} title={name} />
{:else}
	<div
		class="circle initial {size}"
		title={name}
		style:--light-color={profile ? lightColor : null}
		style:--dark-color={profile ? darkColor : null}
	>
		{#if !profile}
			<IcBaselinePersonOff />
		{:else if name}
			{name[0]}
		{:else}
			<IcBaselinePerson />
		{/if}
	</div>
{/if}

<style lang="postcss">
	.circle {
		border-radius: var(--radius-round);
	}

	.initial {
		user-select: none;
		display: grid;
		place-items: center;
		background-color: var(--light-color, var(--surface-3));
		color: var(--dark-color, var(--text-2));
		line-height: 0;
	}

	/* @media only screen and (prefers-color-scheme: dark) {
		.initial {
			background-color: var(--dark-color, var(--surface-3));
			color: var(--light-color, var(--text-2));
		}
	} */

	:global(:where([data-theme='dark'], .dark, .dark-theme)) {
		& .initial {
			background-color: var(--dark-color, var(--surface-3));
			color: var(--light-color, var(--text-2));
		}
	}

	.small {
		min-width: var(--size-5);
		width: var(--size-5);
		height: var(--size-5);
		font-size: var(--font-size-0-5);
		font-weight: var(--font-weight-6);
	}

	.medium {
		min-width: var(--size-7);
		width: var(--size-7);
		height: var(--size-7);
		font-size: var(--font-size-2);
		font-weight: var(--font-weight-8);
	}

	.large {
		min-width: var(--size-9);
		width: var(--size-9);
		height: var(--size-9);
		font-size: var(--font-size-3);
		font-weight: var(--font-weight-8);
	}
</style>
