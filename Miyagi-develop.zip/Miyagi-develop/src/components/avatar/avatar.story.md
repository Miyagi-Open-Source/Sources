Avatar component takes a user profile and displays either the avatarUrl or the first and last initials of the username.
