export { default } from './avatar.svelte';
