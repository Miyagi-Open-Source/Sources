import { get, writable } from 'svelte/store';
import { browser } from '$app/environment';

type Themes = 'light' | 'dark';

export const currentTheme = writable<Themes>('dark');
currentTheme.subscribe((theme) => browser && document.body.setAttribute('data-theme', theme));

browser && currentTheme.set((localStorage.getItem('theme') as Themes) || 'dark');

export const setTheme = (theme: Themes) => {
	currentTheme.set(theme);

	localStorage.setItem('theme', theme);
};

export const toggleTheme = () => setTheme(get(currentTheme) === 'light' ? 'dark' : 'light');
