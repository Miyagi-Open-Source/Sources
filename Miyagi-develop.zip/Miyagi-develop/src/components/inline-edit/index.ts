export { default } from './TextInplaceEdit.svelte';
