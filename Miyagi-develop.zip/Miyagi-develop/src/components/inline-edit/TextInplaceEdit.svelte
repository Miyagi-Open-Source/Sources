<script lang="ts">
	/* works fine so far - might need some more css tweaking */
	import { createEventDispatcher, onMount } from 'svelte';
	import Button from '$components/button';
	import IcEdit from '~icons/ic/round-edit';
	import IcCancel from '~icons/ic/round-cancel';
	import IcCheck from '~icons/ic/round-check';

	export let value: string;
	export let required = false;
	export let minLength = 0;

	const dispatch = createEventDispatcher<{ submit: string }>();
	const edispatch = createEventDispatcher<{ edit: string }>();

	let editing = false;
	let original: string;
	let inputElement: HTMLInputElement;

	onMount(() => {
		original = value;
	});

	const edit = () => {
		edispatch('edit', original);
		editing = true;
	};

	const submit = (event: SubmitEvent) => {
		const valid = inputElement.reportValidity();
		if (!valid) {
			cancel(event);
			return;
		}
		if (value != original) {
			dispatch('submit', value);
			original = value;
		}
		editing = false;
	};

	const cancel = (event: KeyboardEvent | MouseEvent | SubmitEvent) => {
		event.preventDefault();
		value = original;
		editing = false;
	};

	const keydown = (event: KeyboardEvent) => {
		if (event.key == 'Escape') {
			cancel(event);
		}
	};

	function focus(element: HTMLInputElement) {
		element.focus();
	}
</script>

{#if editing}
	<form on:submit|preventDefault={submit} on:keydown={keydown}>
		<input bind:value bind:this={inputElement} {required} use:focus minlength={minLength} />
		<span class="buttons">
			<Button type="reset" on:click={cancel} title="Cancel"><IcCancel /></Button>
			<Button type="submit" title="Save"><IcCheck /></Button>
		</span>
	</form>
{:else}
	<div>
		{value}
		<span class="buttons">
			<Button on:click={edit} variant="regular" title="Edit Workspacename">
				<svelte:fragment><IcEdit /></svelte:fragment>
			</Button>
		</span>
	</div>
{/if}

<style lang="postcss">
	div,
	form {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
	}

	input {
		width: 80%;
		border: none;
		outline: var(--blue-5) solid 1px;
		padding: 0;
		box-shadow: none;
		background: none;
		color: inherit;
		font-size: inherit;
		font-weight: inherit;
		text-align: inherit;

		&:invalid {
			outline: var(--red-5) solid 1px;
		}
	}

	input:focus-visible {
		/* outline: none; */
		cursor: text;
	}

	.buttons {
		font-size: var(--size-3);
	}
</style>
