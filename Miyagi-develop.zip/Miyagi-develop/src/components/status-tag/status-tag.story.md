Status Tag component is used to display status of stories and tasks.
