<script lang="ts">
	import statusSettings from '$lib/project-settings';
	import type { Sprint } from '$types/sprint';
	import type { Story } from '$types/story';
	import type { Task } from '$types/task';
	import Tag from '../tag';
	import { currentProject } from '$lib/stores/currentProject';
	import { clipboard } from '../../actions/clipboard';

	type CommonKeys = 'displayId' | 'type' | 'id';
	type RequiredData = (
		| Pick<Sprint, CommonKeys | 'isRunning' | 'endDate'>
		| Pick<Story | Task, CommonKeys | 'status'>
	) & { projectTag?: string };
	type common = {
		typePrefix?: 'SP-' | 'ST-' | 'TK-' | '';
		id?: string;
		status?: keyof typeof statusSettings;
		hidePrefix?: boolean;
	};

	type $$Props = (
		| {
				el: RequiredData | null;
		  }
		| {
				label: string;
				el?: never;
		  }
	) &
		common;

	export let el: RequiredData | null | undefined = undefined;

	export let typePrefix: 'SP-' | 'ST-' | 'TK-' | '' = '';
	export let id = '';
	export let status: keyof typeof statusSettings = 'backlog';
	export let label: string | undefined = undefined;
	export let hidePrefix = false;
	$: projectPrefix = hidePrefix ? '' : el?.projectTag ? el.projectTag + '-' : $currentProject?.tag + '-' ?? '???-';

	$: setData(el);
	const setData = (el: RequiredData | null | undefined) => {
		if (!el) return;

		typePrefix = (
			{
				sprint: 'SP-',
				story: 'ST-',
				task: 'TK-',
			} as const
		)[el.type];

		id = el.displayId ? String(el.displayId) : `#${el.id}`;
		status =
			el.type === 'sprint'
				? el.isRunning
					? 'inProgress'
					: el.endDate
					? 'done'
					: 'backlog'
				: (el.status as keyof typeof statusSettings);
	};

	$: tagId = projectPrefix + typePrefix + (label ?? String(id).padStart(3, '0'));
</script>

<!-- svelte-ignore a11y-click-events-have-key-events -->
<div use:clipboard={tagId}>
	<Tag --background-color={`var(--${status}-background-color)`} --color={`var(--${status}-color)`}>
		<svelte:component this={statusSettings[status]?.icon} />
		{tagId}
	</Tag>
</div>

<style>
	/* .projectPrefix {
        display: none;
    }

    :global(span:hover) > .projectPrefix {
        display: inline;
    } */
</style>
