<script>
	import StatusTag from '.';
	export let Hst;

	let label = 'S-1337';

	const status = ['backlog', 'inProgress', 'done'];
</script>

<Hst.Story title="StatusTag" layout={{ type: 'grid', width: 200 }}>
	<svelte:fragment slot="controls">
		<Hst.Text bind:value={label} title="label" />
	</svelte:fragment>

	{#each status as status}
		<Hst.Variant
			title={status}
			source={`<StatusTag status="${status}">
	${label}
</StatusTag>`}
		>
			<StatusTag {status}>
				{label}
			</StatusTag>
		</Hst.Variant>
	{/each}
</Hst.Story>
