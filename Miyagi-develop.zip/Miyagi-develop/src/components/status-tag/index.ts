export { default } from './status-tag.svelte';
