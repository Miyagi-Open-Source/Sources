import { cleanup, render } from '@testing-library/svelte';
import { beforeEach, describe, test } from 'vitest';
import StatusTag from './status-tag.svelte';

beforeEach(cleanup);

describe('Component: StatusTag', () => {
	test('render', () => {
		render(StatusTag);
	});

	// test('render label', () => {
	// 	const label = 'Hello World';
	// 	const { getByText } = render(StatusTag, { id });
	// 	expect(getByText(label)).toBeDefined();
	// });
});
