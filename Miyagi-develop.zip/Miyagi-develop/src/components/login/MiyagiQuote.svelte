<script lang="ts">
	import quotes from '$lib/quotes/quotes.json';
	let randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
</script>

{randomQuote.quote}
