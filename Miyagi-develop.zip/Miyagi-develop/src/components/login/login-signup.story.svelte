<script>
	import LoginSignup from './login-signup.svelte';
	export let Hst;
</script>

<Hst.Story title="Layout/LoginSignup">
	<LoginSignup />
</Hst.Story>
