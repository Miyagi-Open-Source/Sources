<script lang="ts">
	import { signInWithGithub } from '$lib/db/auth';
</script>

<div class="wrap">
	<button on:click={() => signInWithGithub()}>Login With Github</button>
</div>
