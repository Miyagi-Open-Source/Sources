<script lang="ts">
	import { resetPassword, signInWithEmail } from '$lib/db/auth';
	import IcLogin from '~icons/ic/round-login';
	import Button from '$components/button';
	import Input from '$components/input';
	import type { AuthError } from '@supabase/supabase-js';
	import { dialog } from '$components/dialog/dialog-function/dialog-function';
	let email: string, password: string;

	let loginError: AuthError | null = null;

	let loading = false;
	const signIn = async () => {
		loading = true;
		const { error } = await signInWithEmail({ email, password });
		loading = false;
		if (error) {
			console.error(error);
			loginError = error;
		} else {
			loginError = null;
		}
	};
</script>

<h2>Login</h2>

<form on:submit|preventDefault={signIn} class:loading>
	<Input required name="email" autocomplete="email" bind:value={email} disabled={loading}>Email</Input>
	<div class="password">
		<Input
			required
			type="password"
			name="password"
			autocomplete="current-password"
			bind:value={password}
			disabled={loading}
		>
			Password
		</Input>
		<button
			type="button"
			on:click={async () => {
				const [email] = await dialog('Enter your email address', [
					{
						input: 'email',
					},
				]);

				if (!email) return;
				const { data, error } = await resetPassword(email);

				if (data) {
					dialog('Password reset Email Sent', {
						message:
							'Check your email for a link to reset your password. If it doesn’t appear within a few minutes, check your spam folder.',
						cancel: false,
					});
				} else if (error) {
					dialog('Error', {
						message: 'There was an error sending the password recovery email: ' + error.message,
						cancel: false,
					});
				}
			}}>Reset Password</button
		>
	</div>
	{#if loginError}
		<strong>
			There was an error with the login.<br />
			{#if loginError?.message === 'Invalid login credentials'}
				Please check if your credentials are correct.
			{:else}
				{loginError.message}
			{/if}
		</strong>
	{/if}
	<Button variant="primary" type="submit" disabled={loading}>
		<IcLogin />
		Login with Miyagi Account
	</Button>
</form>

<style>
	strong {
		color: var(--red-8);
	}

	form {
		transition: opacity 0.2s var(--ease-out-1);
	}

	.loading {
		opacity: 0.4;
	}

	button {
		padding: var(--size-1);
		background: none;
		color: var(--text-2);
		float: right;
	}

	button:hover {
		color: var(--text-1);
		text-decoration: underline;
	}
</style>
