<script lang="ts">
	import Button from '$components/button';
	import Input from '$components/input';
	import IcPlus from '~icons/ic/round-plus';

	import { signUpWithEmail } from '$lib/db/auth';
	import type { AuthError } from '@supabase/supabase-js';

	let name: string, email: string, password: string, confirmPassword: string;

	let sentConfirmMail = false;

	let signUpError: AuthError | Error | null = null;

	let loading = false;
	const signup = async () => {
		if (password !== confirmPassword) {
			signUpError = new Error('Passwords do not match');
			return;
		}
		loading = true;
		const { error } = await signUpWithEmail({ email, password, name });
		loading = false;
		if (error) {
			console.error(error);
			signUpError = error;
		} else {
			sentConfirmMail = true;
			signUpError = null;
		}
	};
</script>

<h2>Sign Up</h2>

{#if sentConfirmMail}
	<strong>
		We are sending you a confirmation Email.<br />
		Please check your Inbox in a few minutes.
	</strong>
{:else}
	<form on:submit|preventDefault={signup} class:loading>
		<Input required name="name" bind:value={name} disabled={loading}>Name</Input>
		<Input required name="email" autocomplete="email" bind:value={email} disabled={loading}>Email</Input>
		<Input
			required
			type="password"
			name="password"
			autocomplete="new-password"
			bind:value={password}
			disabled={loading}
		>
			Password
		</Input>
		<Input
			required
			type="password"
			name="confirmPassword"
			autocomplete="new-password"
			bind:value={confirmPassword}
			disabled={loading}
		>
			Confirm Password
		</Input>
		{#if signUpError}
			<strong class="error">
				There was an error with the sign up.<br />
				{#if signUpError?.message === 'Passwords do not match'}
					Passwords do not match.
				{:else}
					{signUpError.message}
				{/if}
			</strong>
		{/if}
		<Button type="submit" variant="primary" disabled={loading}>
			<IcPlus />
			Create Miyagi Account
		</Button>
	</form>
{/if}

<style>
	.error {
		color: var(--red-8);
	}

	form {
		transition: opacity 0.2s var(--ease-out-1);
	}

	.loading {
		opacity: 0.4;
	}
</style>
