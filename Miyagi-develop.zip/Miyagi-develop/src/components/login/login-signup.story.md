LoginSignup component is used to allow the user to login or register for a new a account.
