<script lang="ts">
	import ArrowButton from '$components/arrow-button';
	import Button from '$components/button';
	import { signInWithGithub } from '$lib/db/auth';
	import IcGithub from '~icons/fa-brands/github';
	// import IcBrandsGoogle from '~icons/fa-brands/google';
	import IcMiyagi from '~icons/ic/baseline-sports-martial-arts';
	import IcLogin from '~icons/ic/round-login';
	import IcPlus from '~icons/ic/round-plus';
	import LogoYoutube from '~icons/carbon/logoYoutube';
	import Login from './login.svelte';
	import Signup from './signup.svelte';
	import MiyagiQuote from './MiyagiQuote.svelte';

	// TODO Refactor all this

	enum Mode {
		Initial,
		Login,
		Signup,
	}

	let signInMode = Mode.Initial;
</script>

<header>
	<a href="https://clancy.digital/" target="_blank" rel="noreferrer">
		<img src="/clancy-logo.png" alt="Clancy Digital; We're hiring!" />
	</a>
	<a style="margin-top: 6px;" href="https://youtu.be/-0iwBFR_p-Q" target="_blank" rel="noreferrer">
		What is Miyagi? <span><LogoYoutube /></span></a
	>
</header>

<div class="container">
	<div class="card">
		<div class="headline">
			<h1>
				<IcMiyagi />
				Miyagi
			</h1>
		</div>

		<section>
			{#if signInMode === Mode.Initial}
				<h2><MiyagiQuote /></h2>
				<Button variant="primary" on:click={() => (signInMode = Mode.Login)} data-testid="login">
					<IcLogin />
					Login with Miyagi Account
				</Button>
				<Button on:click={() => (signInMode = Mode.Signup)}>
					<IcPlus />
					Create Miyagi Account
				</Button>
				<hr />
				<Button on:click={signInWithGithub}>
					<IcGithub />
					Login with GitHub
				</Button>
				<!-- <Button disabled>
					<IcBrandsGoogle />
					Login with Google
				</Button> -->
			{:else}
				{#if signInMode === Mode.Login}
					<Login />
				{:else if signInMode === Mode.Signup}
					<Signup />
				{/if}
				<ArrowButton on:click={() => (signInMode = Mode.Initial)} />
			{/if}
		</section>
	</div>
</div>

<style lang="postcss">
	header {
		position: absolute;
		top: 0;
		right: 0;
		left: 0;
		z-index: 1;
		display: flex;
		justify-content: space-between;
		padding-block: var(--size-3);
		padding-inline: var(--size-5);
		box-shadow: var(--shadow-3);
		background-color: white;
	}

	a {
		margin: 0;
		padding: 0;
		color: var(--gray-9);
		text-decoration: none;

		& span {
			display: inline-block;
			height: var(--font-size-4);
			color: red;
			font-size: var(--font-size-5);
		}
	}

	section {
		display: flex;
		flex-direction: column;
		gap: var(--size-5);
		padding: var(--size-7);
		padding-top: var(--size-3);
		background-color: var(--surface-1);
	}

	img {
		width: 180px;
	}

	h2 {
		font-size: var(--font-size-4);
	}

	.container {
		position: absolute;
		inset: 0;
		display: grid;
		margin-top: 80px;
		place-items: center;
		background-image: var(--gradient-25);
	}

	/* @media only screen and (prefers-color-scheme: dark) {
		.container {
			background-image: var(--gradient-1);
		}
	} */

	:global(:where([data-theme='dark'], .dark, .dark-theme)) .container {
		background-image: var(--gradient-1);
	}

	.card {
		overflow: hidden;
		min-width: var(--size-content-2);
		border-radius: var(--size-1);
		box-shadow: var(--shadow-5);
	}

	.headline {
		display: block;
		padding-block: var(--size-3);
		padding-inline: var(--size-7);
		background-color: var(--gray-9);
		color: var(--gray-1);

		& h1 {
			display: flex;
			gap: var(--size-1);
			color: inherit;
			font-size: var(--font-size-5);
		}
	}
</style>
