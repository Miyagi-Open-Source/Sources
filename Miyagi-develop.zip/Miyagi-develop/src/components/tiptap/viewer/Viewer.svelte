<script lang="ts">
	import { Editor, type JSONContent } from '@tiptap/core';
	import { onMount } from 'svelte';

	import TaskItem from '@tiptap/extension-task-item';
	import TaskList from '@tiptap/extension-task-list';
	import Link from '@tiptap/extension-link';
	import Typography from '@tiptap/extension-typography';
	import Underline from '@tiptap/extension-underline';
	import CharacterCount from '@tiptap/extension-character-count';
	import StarterKit from '@tiptap/starter-kit';

	export let content: JSONContent = {
		type: 'doc',
		content: [],
	};

	$: editor?.commands.setContent(content);

	let editor: Editor;
	onMount(() => {
		editor = new Editor({
			extensions: [
				StarterKit,
				Underline,
				Typography,
				TaskList,
				CharacterCount.configure({
					limit: 3500,
				}),
				TaskItem,
				Link.configure({}),
			],
			content,
		});
	});
</script>

{#if content}
	<h3>
		{#if editor}
			{@html editor.getHTML()}
		{:else}
			loading...
		{/if}
	</h3>
{/if}

<style>
	h3 {
		color: inherit;
		font-weight: normal;
	}
</style>
