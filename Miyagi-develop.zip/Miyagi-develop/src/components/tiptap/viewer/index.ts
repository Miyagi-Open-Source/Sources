export { default } from './Viewer.svelte';
