<script>
	import { hstEvent } from 'histoire/client';
	import Editor from '.';
	import content from './editor-test-content';
	export let Hst;

	let label = 'Label';
	let disabled = false;

	const source = `<Editor {content} on:change={handleChange}>Label</Editor>`;
	const handleChange = (e) => hstEvent('change', e);
</script>

<Hst.Story {source} title="Editor">
	<svelte:fragment slot="controls">
		<Hst.Text bind:value={label} title="label" />
		<Hst.Checkbox bind:value={disabled} title="disabled" />
	</svelte:fragment>
	<Editor {content} {disabled} on:change={handleChange}>
		{label}
	</Editor>
</Hst.Story>
