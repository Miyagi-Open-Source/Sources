export { default } from './editor.svelte';
