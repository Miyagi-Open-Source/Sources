Editor component is a WYSIWYG editor that allows for rich editing of sprint, story and task descriptions.

The Editor sends a `change` event on `blur` if the content changed.
