const content = {
	type: 'doc',
	content: [
		{
			type: 'paragraph',
			content: [
				{
					type: 'text',
					// cSPELL:DISABLE
					text: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.',
				},
			],
		},
	],
};

export default content;
