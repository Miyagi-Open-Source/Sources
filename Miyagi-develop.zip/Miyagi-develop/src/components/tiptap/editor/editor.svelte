<script lang="ts">
	import type Children from '$types/children';
	import { Editor, type JSONContent } from '@tiptap/core';
	import TaskItem from '@tiptap/extension-task-item';
	import TaskList from '@tiptap/extension-task-list';
	import Link from '@tiptap/extension-link';
	import Typography from '@tiptap/extension-typography';
	import Underline from '@tiptap/extension-underline';
	import CharacterCount from '@tiptap/extension-character-count';
	import StarterKit from '@tiptap/starter-kit';
	import { createEventDispatcher, onMount } from 'svelte';
	import IcFormatChecklist from '~icons/ic/round-checklist';
	import IcFormatBold from '~icons/ic/round-format-bold';
	import IcFormatItalic from '~icons/ic/round-format-italic';
	import IcFormatListNumbered from '~icons/ic/round-format-list-numbered';
	import IcFormatUnderlined from '~icons/ic/round-format-underlined';
	import IcFormatList from '~icons/ic/round-list';
	import IcFormatStrikethrough from '~icons/ic/round-strikethrough-s';
	const dispatch = createEventDispatcher<{ change: JSONContent }>();

	export let content: JSONContent = {
		type: 'doc',
		content: [],
	};
	export let label: Children = '';
	export let disabled = false;

	$: editor?.setEditable(!disabled);
	$: updateContent(content);

	let element: HTMLElement;
	let editor: Editor;

	onMount(() => {
		editor = new Editor({
			element: element,
			extensions: [
				StarterKit,
				Underline,
				Typography,
				TaskList,
				CharacterCount.configure({
					limit: 3500,
				}),
				TaskItem,
				Link.configure({}),
			],
			content,
			onTransaction: () => {
				// force re-render so `editor.isActive` works as expected
				editor = editor;
			},
			onBlur: () => {
				const editorJSON = editor.getJSON();

				// check if content changed
				const editorString = JSON.stringify(editorJSON);
				const contentString = JSON.stringify(content);
				if (contentString === editorString) return;

				content = editorJSON;
				dispatch('change', editorJSON);
			},
		});

		return () => {
			editor.destroy();
		};
	});

	const updateContent = (newContent: JSONContent) => {
		if (!editor) return;
		if (document.activeElement?.parentNode === element) return;

		const editorJSON = editor.getJSON();
		const editorString = JSON.stringify(editorJSON);
		const contentString = JSON.stringify(newContent);
		if (contentString === editorString) return;

		editor.commands.setContent(newContent);
	};

	const toolbar = [
		{ functionName: 'toggleBold', activeName: 'bold', icon: IcFormatBold },
		{ functionName: 'toggleItalic', activeName: 'italic', icon: IcFormatItalic },
		{ functionName: 'toggleUnderline', activeName: 'underline', icon: IcFormatUnderlined },
		{ functionName: 'toggleStrike', activeName: 'strike', icon: IcFormatStrikethrough },
		{ functionName: 'toggleBulletList', activeName: 'bulletList', icon: IcFormatList },
		{ functionName: 'toggleOrderedList', activeName: 'orderedList', icon: IcFormatListNumbered },
		{ functionName: 'toggleTaskList', activeName: 'taskList', icon: IcFormatChecklist },
	] as const;
</script>

<div class="group">
	<div class="container">
		<div class="row-sb">
			<span class="label">
				<slot>
					{label}
				</slot>
			</span>

			{#if editor}
				<div class="toolbar">
					{#each toolbar as { functionName, activeName, icon }}
						<button
							tabindex="-1"
							type="button"
							on:click={() => {
								editor.chain().focus()[functionName]().run();

								const editorJSON = editor.getJSON();
								content = editorJSON;
								dispatch('change', editorJSON);
							}}
							class:active={editor.isActive(activeName)}
							{disabled}
						>
							<svelte:component this={icon} />
						</button>
						<!-- <button
                            type="button"
                            class:active={editor.isActive(activeName)}
                            {disabled}
                        >
                            <svelte:component this={icon} />
                        </button> -->
					{/each}
				</div>
			{/if}
		</div>
	</div>
	<div bind:this={element} class:disabled on:dblclick|stopPropagation {...$$restProps} />
</div>

<style lang="postcss">
	button {
		border-radius: var(--size-1);
		aspect-ratio: 1/1;
		background-color: transparent;
		color: var(--text-1);
		transition-property: background-color, color;
		transition-duration: 0.2s;
		transition-timing-function: var(--ease-out-1);

		&.active {
			background-color: var(--violet-9);
			color: var(--violet-0);
		}

		&:hover {
			background-color: var(--surface-3);
			color: var(--text-1);
		}

		&:disabled {
			background-color: var(--surface-3);
			color: var(--gray-5);
			cursor: default;
		}
	}

	/* stylelint-disable-next-line selector-pseudo-class-no-unknown */
	:global(p) {
		max-inline-size: unset;
	}

	/* stylelint-disable-next-line selector-pseudo-class-no-unknown, selector-class-pattern */
	:global(.ProseMirror) {
		border: 1px solid var(--gray-6);
		border-radius: var(--size-1);
		padding: var(--size-2) var(--size-3);
		background: var(--app-background);
		resize: vertical;
		outline-offset: 5px;
	}

	/* stylelint-disable-next-line selector-pseudo-class-no-unknown */
	:global(ul[data-type='taskList']) {
		list-style: none;
		padding: 0;

		/* stylelint-disable-next-line selector-pseudo-class-no-unknown */
		& :global(li) {
			display: flex;
			align-items: baseline;

			/* stylelint-disable-next-line selector-pseudo-class-no-unknown */
			& :global(> label) {
				user-select: none;
				flex: 0 0 auto;
				margin-right: 0.5rem;
			}

			/* stylelint-disable-next-line selector-pseudo-class-no-unknown */
			& :global(> div) {
				flex: 1 1 auto;
			}
		}
	}

	.disabled {
		/* stylelint-disable-next-line selector-pseudo-class-no-unknown, selector-class-pattern */
		& :global(.ProseMirror) {
			background-color: var(--surface-2);
			color: var(--gray-5);
			cursor: default;
		}
	}

	/* stylelint-disable-next-line selector-pseudo-class-no-unknown */
	:global(ul[data-type='taskList'] input[type='checkbox']) {
		cursor: pointer;
	}

	.container {
		flex-grow: 1;
		display: flex;
		flex-direction: column;
		gap: var(--size-1);
		margin: var(--margin, 0);
	}

	.row-sb {
		display: flex;
		align-items: flex-end;
		justify-content: space-between;
	}

	.label {
		overflow: hidden;
		flex-shrink: 1;
		display: -webkit-box;
		display: inline-block;
		-webkit-line-clamp: 1;
		-webkit-box-orient: vertical;
		text-overflow: ellipsis;
		white-space: nowrap;
	}

	.toolbar {
		flex: 0 0 auto;
		display: flex;
		gap: var(--size-1);
	}
</style>
