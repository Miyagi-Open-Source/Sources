import { beforeEach, test, expect, describe, afterEach } from 'vitest';
import { cleanup, render } from '@testing-library/svelte';
import { vi } from 'vitest';
import Editor from './editor.svelte';

beforeEach(cleanup);
afterEach(() => {
	vi.resetAllMocks();
});

describe('Component: Editor', () => {
	test('can render', () => {
		render(Editor);
	});

	test('can render label', () => {
		const label = 'Hello World';
		const { getByText } = render(Editor, { label });
		expect(getByText(label)).toBeDefined();
	});

	test('can render content', () => {
		const text = 'Test List Item';
		const content = {
			type: 'doc',
			content: [
				{
					type: 'bulletList',
					content: [
						{
							type: 'listItem',
							content: [{ type: 'paragraph', content: [{ type: 'text', text: text }] }],
						},
					],
				},
			],
		};
		const { getByText } = render(Editor, { content });
		expect(getByText(text)).toBeDefined();
	});
});
