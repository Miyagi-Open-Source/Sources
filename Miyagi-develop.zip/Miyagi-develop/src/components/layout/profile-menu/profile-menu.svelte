<script lang="ts">
	import Avatar from '$components/avatar';
	import Menu from '$components/menu';
	import MenuItem from '$components/menu/menu-item';
	import { userStore } from '$lib/db/auth';
	import IcProfile from '~icons/ic/round-account-circle';
	import IcLogout from '~icons/ic/round-logout';
	import ICTwotoneDarkMode from '~icons/ic/twotone-dark-mode';
	import ICTwotoneLightMode from '~icons/ic/twotone-light-mode';
	import ICPaypal from '~icons/ic/baseline-paypal';
	import IcInvite from '~icons/ic/outline-mail';
	import Badge from '$components/badge/badge.svelte';
	import { goto } from '$app/navigation';
	import { checkForUpdates, invites } from '$lib/stores/invites';
	import { currentTheme, toggleTheme } from '$components/theme';
	import { capitalizeFirstLetter } from '$lib/helper';
</script>

<Menu
	placement="bottom-end"
	variant="ghost"
	--margin="0 0 0 auto"
	forceIconOnly={true}
	on:click={() => {
		checkForUpdates();
	}}
>
	<svelte:fragment slot="label">
		<Avatar profile={$userStore} />
	</svelte:fragment>
	<MenuItem href="/profile">
		<IcProfile />
		<span title={$userStore?.username ? $userStore?.email : null}>
			{$userStore?.username || $userStore?.email}
		</span>
	</MenuItem>
	<MenuItem
		on:click={() => {
			goto('/invites');
		}}
	>
		<Badge count={$invites.length}>
			<IcInvite />
		</Badge> Invites
	</MenuItem>
	<MenuItem>
		<form action="/logout" method="post">
			<button type="submit">
				<IcLogout /> Logout
			</button>
		</form>
	</MenuItem>

	<MenuItem on:click={toggleTheme}>
		<svelte:component this={$currentTheme === 'dark' ? ICTwotoneDarkMode : ICTwotoneLightMode} />{capitalizeFirstLetter(
			$currentTheme
		)}
	</MenuItem>

	<MenuItem href="https://paypal.me/clancydigital">
		<ICPaypal /> Support Us
	</MenuItem>
</Menu>

<style lang="postcss">
	/* margin-left: calc(var(--size-3) * -1); */
	form {
		width: 100%;
	}

	button[type='submit'] {
		display: inline-flex;
		flex-direction: row;
		align-items: center;
		gap: var(--size-2);
		margin: 0;
		padding: 0;
	}
</style>
