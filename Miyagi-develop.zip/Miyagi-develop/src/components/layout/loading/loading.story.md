The initial Server Rendered Loading animation for the app.
