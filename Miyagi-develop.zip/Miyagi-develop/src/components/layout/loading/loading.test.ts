import { cleanup, render } from '@testing-library/svelte';
import { beforeEach, describe, expect, it, test } from 'vitest';
import Loading from './loading.svelte';

beforeEach(() => {
	cleanup();
});

describe('Component: Loading', () => {
	test('render', () => {
		render(Loading);
	});

	it('says loading somewhere', async () => {
		const { getByText } = render(Loading);
		expect(getByText('loading', { exact: false })).toBeDefined();
	});
});
