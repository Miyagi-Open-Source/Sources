<script>
	import Loading from '.';
	export let Hst;
</script>

<Hst.Story title="Layout/Loading">
	<Loading />
</Hst.Story>
