export { default } from './loading.svelte';
