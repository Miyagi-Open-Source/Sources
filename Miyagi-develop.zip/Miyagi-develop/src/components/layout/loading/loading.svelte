<script>
	import IcMiyagi from '~icons/ic/baseline-sports-martial-arts';
</script>

<div class="container">
	<div class="card">
		<div class="headline">
			<h1>
				<IcMiyagi />
				Miyagi
			</h1>
		</div>
		<div class="loading-bar" />

		<section>Loading App...</section>
	</div>
</div>

<style lang="postcss">
	.container {
		position: absolute;
		inset: 0;
		display: grid;
		place-items: center;
		background-image: var(--gradient-25);
	}

	/* @media only screen and (prefers-color-scheme: dark) {
		.container {
			background-image: var(--gradient-1);
		}
	} */

	.card {
		overflow: hidden;
		min-width: var(--size-content-2);
		border-radius: var(--size-1);
		box-shadow: var(--shadow-5);
		background-color: var(--app-background);
	}

	.headline {
		display: block;
		padding-block: var(--size-3);
		padding-inline: var(--size-7);
		background-color: var(--gray-9);
		color: var(--gray-1);

		& h1 {
			display: flex;
			gap: var(--size-1);
			color: inherit;
			font-size: var(--font-size-5);
		}
	}

	section {
		display: flex;
		flex-direction: column;
		gap: var(--size-5);
		padding: var(--size-7);
		background-color: var(--surface-1);
		text-align: center;
		font-size: var(--font-size-4);
		font-weight: var(--font-weight-6);
	}

	.loading-bar,
	.loading-bar::before {
		width: 100%;
		height: var(--size-2);
		margin: 0;
	}

	.loading-bar {
		display: flex;
		background-color: var(--violet-2);
	}

	.loading-bar::before {
		content: '';
		background-color: var(--violet-7);
		animation: loading-progress 3s var(--ease-squish-1) infinite;
	}

	:global(:where([data-theme='dark'], .dark, .dark-theme)) {
		& .loading-bar {
			background-color: var(--violet-7);
		}

		& .loading-bar::before {
			background-color: var(--violet-2);
		}
	}

	@keyframes loading-progress {
		0% {
			margin-right: 100%;
			margin-left: 0;
		}

		50% {
			margin-right: 25%;
			margin-left: 25%;
		}

		100% {
			margin-right: 0;
			margin-left: 100%;
		}
	}
</style>
