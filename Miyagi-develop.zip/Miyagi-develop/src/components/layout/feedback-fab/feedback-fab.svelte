<script lang="ts">
	import Button from '$components/button';
	import Dialog from '$components/dialog';
	import Input from '$components/input';
	import { userStore } from '$lib/db/auth';
	import { createUserFeedback } from '$lib/db/user-feedback';
	import type { Db_UserFeedback_Insert } from '$types/db-types';
	import IcArrowBack from '~icons/ic/round-arrow-back';
	import IcRoundFeedback from '~icons/ic/round-feedback';
	import IcRoundSend from '~icons/ic/round-send';

	let openForm = false;
	let openAffirmation = false;

	let feedback: Db_UserFeedback_Insert = {
		subject: '',
		email: '',
		message: '',
	};
	let dataConsent = false;

	const handleSubmit = async () => {
		if (!dataConsent) return;
		openForm = false;
		await createUserFeedback(feedback);
		feedback = {
			subject: '',
			email: '',
			message: '',
		};
		openAffirmation = true;
	};
</script>

<button
	class="fab"
	aria-label="Share your Feedback!"
	data-testid="open-user-feedback-form"
	on:click={() => {
		if ($userStore?.email) {
			feedback.email = $userStore.email;
		}
		openForm = true;
	}}
>
	<IcRoundFeedback />
</button>

<Dialog includedTrigger={false} bind:open={openForm} heading="Share your Feedback!">
	<form on:submit|preventDefault={handleSubmit} class="max-w-50ch">
		<p>
			We hope you are enjoying using Miyagi! If there is anything that would make your experience better, please let us
			know. Share any bugs you find or features you would like to see. We would love to have your feedback!
		</p>
		<Input bind:value={feedback.subject} name="subject">Subject</Input>
		<Input bind:value={feedback.email} name="email">E-Mail</Input>
		<Input type="textarea" bind:value={feedback.message} name="message" data-testid="feedback-message">Message</Input>

		<div class="data-consent-row">
			<input
				type="checkbox"
				id="data-consent"
				name="data-consent"
				bind:checked={dataConsent}
				data-testid="feedback-data-consent"
			/>
			<label for="data-consent">
				I agree to send my user and system information to Clancy Digital. The data will be used in accordance with our
				Privacy Policy to troubleshoot problems and make our services better.
			</label>
		</div>
		<Button type="submit" disabled={!dataConsent || !feedback.message} data-testid="feedback-submit"
			><IcRoundSend />Submit Feedback</Button
		>
	</form>
</Dialog>

<Dialog includedTrigger={false} bind:open={openAffirmation} heading="Thank you for your feedback!">
	<p class="max-w-50ch" data-testid="feedback-affirmation">
		Your feedback has been submitted. Thank you very much for your feedback.
	</p>
	<p class="max-w-50ch">
		We are always looking to improve the experience of using Miyagi and your feedback is much appreciated.
	</p>
	<svelte:fragment slot="dialog-actions">
		<Button
			on:click={() => {
				openForm = false;
				openAffirmation = false;
			}}
		>
			<IcArrowBack />Back to Miyagi</Button
		>
	</svelte:fragment>
</Dialog>

<style lang="postcss">
	.fab {
		position: fixed;
		right: var(--size-5);
		bottom: calc(var(--size-5) * 2);
		border-radius: var(--radius-round);
		padding: var(--size-3);
		box-shadow: var(--shadow-4);
		background-color: var(--text-1);
		color: var(--surface-1);
		font-size: var(--size-5);
		aspect-ratio: 1/1;
		transition-property: box-shadow, filter, background, color, transform;
		transition-duration: 0.2s;
		transition-timing-function: var(--ease-out-1);

		&:hover:not(:disabled) {
			box-shadow: var(--shadow-6);
			background-color: var(--violet-9);
			color: var(--violet-0);
			transform: scale(1.1);
			filter: brightness(110%);
		}

		&:active:not(:disabled) {
			box-shadow: var(--shadow-1);
			filter: brightness(90%);
		}
	}

	@media all and (display-mode: fullscreen) {
		.fab {
			right: var(--size-7);
			bottom: var(--size-7);
		}
	}

	.max-w-50ch {
		max-width: 50ch;
	}

	form {
		padding: var(--size-2);
	}

	.data-consent-row {
		display: flex;
		align-items: center;
		gap: var(--size-2);
	}
</style>
