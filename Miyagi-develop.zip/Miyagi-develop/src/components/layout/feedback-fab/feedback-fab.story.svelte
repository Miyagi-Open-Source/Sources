<script>
	import FeedbackFab from '.';
	export let Hst;
</script>

<Hst.Story title="Layout/FeedbackFab">
	<FeedbackFab />
</Hst.Story>
