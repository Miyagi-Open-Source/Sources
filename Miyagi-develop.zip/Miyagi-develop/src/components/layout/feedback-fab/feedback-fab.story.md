A floating button that is always visible and can be use by a user to give us feedback on the product.
