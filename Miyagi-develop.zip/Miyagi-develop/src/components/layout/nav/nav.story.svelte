<script>
	import Nav from '.';
	export let Hst;
</script>

<Hst.Story title="Layout/Nav">
	<Nav />
</Hst.Story>
