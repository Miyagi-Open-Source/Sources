export { default } from './nav.svelte';
