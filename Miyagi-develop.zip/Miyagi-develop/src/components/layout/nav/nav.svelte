<script lang="ts">
	import { page } from '$app/stores';
	import { setClipPath } from '$lib/actions/set-clip-path';
	import IcSprint from '~icons/ic/round-directions-run';
	import IcBacklog from '~icons/ic/round-menu';
	import IcAnalytics from '~icons/ic/twotone-area-chart';
	// import IcBaselineSettings from '~icons/ic/baseline-settings';

	$: splitPathname = $page.url.pathname.split('/');

	$: organizationId = splitPathname[1];
	$: projectId = splitPathname[2];
	$: offset = `/${organizationId}/${projectId}`;
	$: navItems = [
		{
			label: 'Backlog',
			href: `${offset}/backlog`,
			icon: IcBacklog,
		},
		{
			label: 'Sprint',
			href: `${offset}/current-sprint`,
			icon: IcSprint,
		},
		{
			label: 'Analytics',
			href: `${offset}/analytics`,
			icon: IcAnalytics,
		},
		// {
		// 	label: 'Settings',
		// 	href: `${offset}/settings`,
		// 	icon: IcBaselineSettings,
		// },
	];

	$: pageBasePath = splitPathname.at(-1);
</script>

<nav>
	<!-- nav bar -->
	<ul>
		{#each navItems as { label, href, icon }}
			<li>
				<a {href}>
					<svelte:component this={icon} />
					{label}
				</a>
			</li>
		{/each}
	</ul>

	<!-- duplicate bar for clip path effect -->
	<div
		class="clip-bar"
		aria-hidden="true"
		use:setClipPath={{
			selector: pageBasePath ? '#' + pageBasePath : undefined,
			insetShapeAppendix: 'round var(--radius-round)',
		}}
	>
		{#each navItems as { label, href, icon }}
			{@const basePath = href.split('/').at(-1)}
			<div class="clip-item" id={basePath}>
				<svelte:component this={icon} />
				{label}
			</div>
		{/each}
	</div>
</nav>

<style lang="postcss">
	nav {
		position: relative;
	}

	ul,
	.clip-bar {
		display: flex;
		align-items: center;
		justify-content: center;
		gap: var(--size-9);
		width: fit-content;
		margin: auto;
		padding-block: var(--size-3);
		padding-inline: 0;
	}

	li {
		list-style: none;
		padding: 0;
	}

	a,
	.clip-item {
		display: inline-flex;
		flex-direction: row;
		align-items: center;
		justify-content: center;
		gap: var(--size-2);
		border-radius: var(--radius-round);
		border-width: 0;
		margin: 0;
		padding-block: var(--size-1);
		padding-inline: var(--size-3);
		color: var(--text-1);
		font-size: var(--font-size-3);
		text-decoration: none;
		cursor: pointer;
		transition-property: box-shadow, background-color, transform;
		transition-duration: 0.2s;
		transition-timing-function: var(--ease-out-1);

		&:hover {
			box-shadow: var(--shadow-3);
			background-color: var(--surface-1);
		}

		&:active {
			box-shadow: var(--shadow-1);
			background-color: var(--surface-2);
		}
	}

	.clip-bar {
		pointer-events: none;
		position: absolute;
		inset: 0;
		background-color: var(--violet-9);
		transition: clip-path 0.2s var(--ease-out-3);
		clip-path: circle(0);

		& .clip-item {
			color: var(--violet-0);
		}
	}
</style>
