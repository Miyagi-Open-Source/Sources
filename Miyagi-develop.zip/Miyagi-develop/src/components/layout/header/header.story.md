The header of the app, containing h1, search box and profile menu.
