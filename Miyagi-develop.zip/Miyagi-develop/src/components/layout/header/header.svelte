<script lang="ts">
	import { page } from '$app/stores';
	import Menu from '$components/menu';
	import MenuItem from '$components/menu/menu-item';
	import IcBaselineArrowDropDown from '~icons/ic/baseline-arrow-drop-down';
	import IcMiyagi from '~icons/ic/baseline-sports-martial-arts';
	import IcRoundAdd from '~icons/ic/round-add';
	import IcRoundArrowForward from '~icons/ic/round-arrow-forward';
	import IcRoundGridView from '~icons/ic/round-grid-view';
	import ProfileMenu from '../profile-menu';
	import clickOutside from '$lib/actions/click-outside';
	import SprintHead from '$components/miyagi/sprint/sprint-head.svelte';
	import StoryHead from '$components/miyagi/story/story-head.svelte';
	import IcRoundSearchOff from '~icons/ic/round-search-off';
	import TaskHead from '$components/miyagi/task/task-head.svelte';
	import { goto } from '$app/navigation';
	import { userStore } from '$lib/db/auth';
	import { currentProject } from '$lib/stores/currentProject';
	import { noop, notNull } from '$lib/helper';
	import { dialog } from '$components/dialog/dialog-function/dialog-function';
	import { REV_INDEXER, search } from '$lib/search';
	import { slide } from 'svelte/transition';
	import type { Project } from '$types/project';
	import { organizations } from '$lib/stores';
	import { browser } from '$app/environment';
	import IcRoundClose from '~icons/ic/round-close';
	import Button from '$components/button/button.svelte';
	import { addDays } from 'date-fns';
	import { supabase } from '$lib/db';

	$: currentPath =
		$page.route?.id?.startsWith('/[organization]/[project]/') &&
		$page.route?.id?.substring('/[organization]/[project]/'.length);

	let searchValue = '';
	let searchResults: ReturnType<typeof search> | null = null;

	let searchInput: HTMLInputElement;

	let isOsMac = false;
	// Set Search Shortkey Keys
	if (browser) {
		let os = navigator.userAgent;
		isOsMac = os.search('Mac') !== -1;
	}

	const searchPlaceholder = 'Search... ' + (isOsMac ? '(⌘' : '(Ctrl') + '+K)';

	const handleKeydown = (event: KeyboardEvent) => {
		if ((event.metaKey || event.ctrlKey) && event.key === 'k') {
			// Prevent default browser behavior of focusing URL bar
			event.preventDefault();
			searchInput.focus();
		}
	};

	const typeToShortcut = {
		sprint: 'sp',
		story: 'st',
		task: 'tk',
	} as const;

	let selectedIndex = 0;

	const reset = () => {
		searchResults = null;
		searchValue = '';
		selectedIndex = 0;
	};

	const productTagToProduct = (tag: Project['tag']) =>
		$organizations.flatMap((org) => org.projects).find((project) => project.tag === tag);

	const displaySearch = () => {
		if (!searchValue.trim()) return (searchResults = null);
		searchResults = search(searchValue);
		selectedIndex = 0;
	};

	const updateSearchDisplay = () => {
		if (!searchValue || !searchResults) return;
		const newSearchResults = search(searchValue);
		selectedIndex = newSearchResults.findIndex(
			(newSearchResult) => newSearchResult.id === searchResults![selectedIndex].id
		);
		searchResults = newSearchResults;
	};

	$: $organizations, updateSearchDisplay();

	$: showDonate =
		$userStore && $userStore.dismissedDonate === false && new Date($userStore.created_at) <= addDays(new Date(), 1);
</script>

<svelte:window on:keydown|stopPropagation={handleKeydown} />

{#if showDonate}
	<div class="donate-banner">
		<!-- svelte-ignore a11y-label-has-associated-control -->
		<label>
			<Button variant="primary" href="https://paypal.me/clancydigital">Support us</Button>
			Do you enjoy using Miyagi? Your support helps us to improve your user experience. Support Miyagi via PayPal
		</label>
		<Button
			variant="ghost"
			on:click={() => {
				showDonate = false;
				supabase
					.from('profiles')
					.update({ dismissedDonate: true })
					.match({ id: notNull($userStore).id })
					.then(noop);
			}}
		>
			<IcRoundClose />
		</Button>
	</div>
{/if}
<header>
	<a href="/">
		<h1>
			<IcMiyagi />
			Miyagi
		</h1>
	</a>

	<form
		class="search"
		on:submit|preventDefault={() => {
			if (!searchResults?.[selectedIndex]) return;

			const { displayId, type, projectTag } = searchResults[selectedIndex];
			const product = productTagToProduct(projectTag);
			if (!product) return;

			goto(`/${product.organization.id}/${product.id}/${REV_INDEXER[type]}-${displayId}`);
			reset();
		}}
		use:clickOutside={{
			enabled: !!searchResults,
			func: reset,
			exclude: '[data-sprint-selector]',
		}}
	>
		<input
			bind:this={searchInput}
			bind:value={searchValue}
			on:input={displaySearch}
			on:keydown={(e) => {
				const max = searchResults ? searchResults.length - 1 : 0;

				if (e.key === 'ArrowDown') {
					selectedIndex = Math.min(selectedIndex + 1, max);
				} else if (e.key === 'ArrowUp') {
					selectedIndex = Math.max(selectedIndex - 1, 0);
				} else if (e.key === 'Tab') {
					e.preventDefault();
					if (e.shiftKey) {
						selectedIndex = Math.max(selectedIndex - 1, 0);
					} else {
						selectedIndex = Math.min(selectedIndex + 1, max);
					}
				}
			}}
			type="search"
			placeholder={searchPlaceholder}
			aria-label="Search"
		/>
		{#if searchResults}
			<ul in:slide={{ duration: 200 }}>
				{#each searchResults as searchResult, i}
					<MenuItem
						selected={i === selectedIndex}
						on:click={() => {
							const product = productTagToProduct(searchResult.projectTag);
							if (!product) return;

							goto(
								`/${product.organization.id}/${product.id}/${typeToShortcut[searchResult.type]}-${
									searchResult.displayId
								}`
							);
							searchValue = '';
							searchResults = null;
						}}
						tabindex={0}
						type="button"
					>
						{#if searchResult.type === 'sprint'}
							<SprintHead sprint={searchResult} hidePoints />
						{:else if searchResult.type === 'story'}
							<StoryHead story={searchResult} />
						{:else}
							<TaskHead task={searchResult} />
						{/if}
					</MenuItem>
				{:else}
					<div class="list-else">
						<IcRoundSearchOff />
						<span> No Matches found. </span>
					</div>
				{/each}
			</ul>
		{/if}
	</form>

	{#if $page?.url.pathname !== '/' && $currentProject}
		<Menu>
			<svelte:fragment slot="label">
				{$currentProject.name}
				<IcBaselineArrowDropDown />
			</svelte:fragment>

			<MenuItem href="/">
				<IcRoundGridView />
				Overview
			</MenuItem>
			<hr />
			{#each $currentProject.organization.projects as otherProject}
				<MenuItem
					on:click={() => {
						goto(`/${otherProject.organization.id}/${otherProject.id}/${currentPath ?? 'backlog'}`);
					}}
					disabled={otherProject === $currentProject}
				>
					<IcRoundArrowForward />
					{otherProject.name}
				</MenuItem>
			{/each}
			<hr />
			{#if $currentProject.organization.projects.length < 3 && $currentProject.organization.owner === $userStore?.id}
				<MenuItem
					on:click={async () => {
						const [name] = await dialog('New Product Name', [
							{
								input: 'string',
							},
						]);
						if (name) notNull($currentProject).organization.createProject({ name });
					}}
				>
					<IcRoundAdd /> New Product
				</MenuItem>
			{/if}
		</Menu>
	{/if}

	<ProfileMenu />
</header>

<style lang="postcss">
	.donate-banner {
		display: flex;
		flex-direction: row;
		align-items: center;
		justify-content: space-between;
		gap: var(--size-2);
		padding: var(--size-2) var(--size-7);
		background-color: var(--purple-8);
	}

	header {
		display: flex;
		flex-direction: row;
		gap: var(--size-5);
		padding-block: var(--size-3);
		padding-inline: var(--size-7);
		background-color: var(--gray-9);
		color: var(--gray-1);
	}

	a {
		margin: 0;
		padding: 0;
		color: inherit;
	}

	h1 {
		display: flex;
		gap: var(--size-1);
		color: inherit;
		font-size: var(--font-size-5);
	}

	.search {
		position: relative;
	}

	input {
		width: var(--size-14);
		border: 1px solid var(--gray-6);
		border-radius: var(--size-1);
		padding: var(--size-2) var(--size-3);
		background: var(--app-background);
		color: var(--text-1);
	}

	input::placeholder {
		color: var(--text-2);
	}

	form {
		position: relative;
		display: block;
	}

	ul {
		position: absolute;
		z-index: 2;
		display: flex;
		flex-direction: column;
		gap: var(--size-1);
		min-width: min-content;
		width: 100%;
		border-radius: var(--size-1);
		padding: 0;
		padding-block: var(--size-1);
		box-shadow: var(--shadow-4);
		background-color: var(--surface-2);
	}

	.list-else {
		display: grid;
		place-items: center;
		padding: var(--size-4);
		color: var(--gray-6);
		font-size: var(--font-size-5);
		font-weight: var(--font-weight-6);

		& span {
			font-size: var(--font-size-3);
		}
	}
</style>
