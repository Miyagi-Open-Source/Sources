<script>
	import Header from '.';
	export let Hst;
</script>

<Hst.Story title="Layout/Header">
	<Header />
</Hst.Story>
