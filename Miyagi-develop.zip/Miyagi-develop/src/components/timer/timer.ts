export { default } from './timer.svelte';
