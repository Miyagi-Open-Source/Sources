<script lang="ts">
	import Button from '$components/button/button.svelte';
	import Dialog from '$components/dialog/dialog.svelte';
	import IcTimer from '~icons/ic/alarm';
	import IcPause from '~icons/material-symbols/pause';
	import IcResume from '~icons/material-symbols/resume';
	import IcCancel from '~icons/ic/baseline-cancel';
	import type { Project } from '$types/project';
	import { addMinutes, addSeconds, differenceInSeconds, intervalToDuration, type Duration } from 'date-fns';
	import { onMount } from 'svelte';
	import { notNull } from '$lib/helper';

	export let project: Project;

	$: endsAt = (project.TimerEndsAt && new Date(project.TimerEndsAt)) as Date | null;
	$: pausedAt = (project.TimerPausedAt && new Date(project.TimerPausedAt)) as Date | null;

	let time = 5;
	let open = false;

	const changeTime = (difference: number) => (time = Math.min(Math.max(time + difference, 1), 60));

	let remainingTime: Duration | null;
	const updateRemainingTime = () => {
		if (!endsAt) throw new Error('No end date set');

		remainingTime =
			endsAt < new Date()
				? null
				: intervalToDuration({
						end: endsAt,
						start: new Date(),
				  });
	};

	onMount(() => {
		const interval = setInterval(() => {
			if (endsAt && !pausedAt) updateRemainingTime();
		}, 1000);

		return () => clearInterval(interval);
	});

	const durationToString = (duration: Duration) => `${duration.minutes}:${String(duration.seconds).padStart(2, '0')}`;
</script>

<div>
	{#if endsAt && (remainingTime || pausedAt)}
		{#if pausedAt}
			{@const remainingTime = intervalToDuration({
				end: endsAt,
				start: pausedAt,
			})}
			{durationToString(remainingTime)}
			<Button
				on:click={() => {
					project.update({
						TimerEndsAt: addSeconds(new Date(), differenceInSeconds(notNull(endsAt), notNull(pausedAt))).toISOString(),
						TimerPausedAt: null,
					});
				}}
			>
				<IcResume />
			</Button>
		{:else}
			{durationToString(notNull(remainingTime))}
			<Button
				on:click={() => {
					project.update({
						TimerPausedAt: new Date().toISOString(),
					});
				}}
			>
				<IcPause />
			</Button>
		{/if}
		<Button
			on:click={() => {
				project.update({
					TimerEndsAt: null,
					TimerPausedAt: null,
				});
			}}
		>
			<IcCancel />
		</Button>
	{:else}
		<Dialog heading="Timer" bind:open>
			<IcTimer slot="trigger-label" />
			<Button on:click={({ ctrlKey }) => changeTime(ctrlKey ? -5 : -1)}>-</Button>
			<span>{time} min</span>
			<Button on:click={({ ctrlKey }) => changeTime(ctrlKey ? 5 : 1)}>+</Button>
			<Button
				slot="dialog-actions"
				on:click={() => {
					open = false;

					project.update({
						TimerEndsAt: addMinutes(new Date(), time).toISOString(),
						TimerPausedAt: null,
					});
				}}>Start</Button
			>
		</Dialog>
	{/if}
</div>

<style>
	div {
		display: flex;
		align-items: center;
		gap: var(--size-1);
	}
</style>
