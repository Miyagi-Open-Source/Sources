<script>
	import { hstEvent } from 'histoire/client';
	import ArrowButton from '.';
	export let Hst;

	let label = 'ArrowButton Label';

	const handleClick = (e) => hstEvent('click', e);
</script>

<Hst.Story title="ArrowButton">
	<svelte:fragment slot="controls">
		<Hst.Text bind:value={label} title="label" />
	</svelte:fragment>
	<Hst.Variant
		title="default (backward)"
		source={`<ArrowButton on:click={handleClick}>
	Back
</ArrowButton>`}
	>
		<ArrowButton on:click={handleClick}>
			{label}
		</ArrowButton>
	</Hst.Variant>

	<Hst.Variant
		title="forward"
		source={`<ArrowButton on:click={handleClick} forward>
	Next
</ArrowButton>`}
	>
		<ArrowButton on:click={handleClick} forward>{label}</ArrowButton>
	</Hst.Variant>
</Hst.Story>
