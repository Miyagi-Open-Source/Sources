<script lang="ts">
	import type Children from '$types/children';
	import IcArrowBack from '~icons/ic/round-arrow-back';
	import IcArrowForward from '~icons/ic/round-arrow-forward';

	export let forward = false;
	export let label: Children = 'Back';
</script>

{#if !forward}
	<span class="arrow">
		<IcArrowBack />
	</span>
{/if}
<slot>{label}</slot>
{#if forward}
	<span class="arrow forward">
		<IcArrowForward />
	</span>
{/if}
