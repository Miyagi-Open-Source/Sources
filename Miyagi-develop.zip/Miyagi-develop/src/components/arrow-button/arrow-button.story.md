ArrowButton component is used to navigate back / forward to a previous / next page or section.

# Props

- `label`: used for testing, since we can't programmatically set slot. prefer using slot
- `forward`: if true the arrow points forward instead of backward.
- `href`: turns component to an anchor tag for links
- `disabled`: disables the button (doesn't work on links)
- `type`: sets type e.g. `button` or `submit` (useful for forms)
- `use`: pass an array of Svelte actions to the rendered element
- `elementRef`: use with `bind:` to get the dom element reference
