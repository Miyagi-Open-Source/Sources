import { cleanup, render } from '@testing-library/svelte';
import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest';
import ArrowButton from './arrow-button.svelte';

beforeEach(cleanup);
afterEach(() => {
	vi.resetAllMocks();
});

describe('Component: ArrowButton', () => {
	test('render', () => {
		render(ArrowButton);
	});

	test('render label', () => {
		const label = 'Hello World';
		const { getByText } = render(ArrowButton, { label });
		expect(getByText(label)).toBeDefined();
	});

	test('forward click event', () => {
		const mock = vi.fn();
		const { getByRole, component } = render(ArrowButton);
		component.$on('click', mock);
		getByRole('button').click();
		expect(mock).toHaveBeenCalledOnce();
	});

	test("don't forward click event when disabled", () => {
		const mock = vi.fn();
		const { getByRole, component } = render(ArrowButton, { disabled: true });
		component.$on('click', mock);
		getByRole('button').click();
		expect(mock).not.toHaveBeenCalled();
	});

	test('render as link', () => {
		const { getByRole } = render(ArrowButton, { href: '#' });
		expect(getByRole('link')).toBeDefined();
	});
});
