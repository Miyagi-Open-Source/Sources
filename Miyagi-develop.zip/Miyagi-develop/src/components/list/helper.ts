import type { ListItem } from '$types/common';

export const updateSequence = <T extends ListItem>(items: T[]) =>
	Object.entries(items)
		.filter(([, item], sequence) => item.sequence !== sequence)
		.forEach(([sequence, item]) => item.update({ sequence: +sequence }));
