<script>
	import MoveMenu from '$components/list/move-menu';
	import List from '.';
	export let Hst;

	let items = [
		{ title: 'Item 1', localId: 0, update: () => null },
		{ title: 'Item 2', localId: 1, update: () => null },
		{ title: 'Item 3', localId: 2, update: () => null },
		{ title: 'Item 4', localId: 3, update: () => null },
	];

	const source = `<List {items} let:item let:i>
	<MoveMenu bind:items {i} />
	{item.title}
</List>`;
</script>

<Hst.Story title="List (w with MoveMenu)" {source}>
	<List {items} let:item let:i>
		<MoveMenu bind:items {i} />
		{item.title}
	</List>
</Hst.Story>
