List Component iterates over an array of items (with id) and passes the current item into the slot.
For each item there is also a menu that allows the user to change the order of the items.

To make the List reorderable via Drop Down, you can use the MoveMenu component like this.
