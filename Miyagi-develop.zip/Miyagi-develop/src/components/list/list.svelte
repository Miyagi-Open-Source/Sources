<script context="module" lang="ts">
	overrideItemIdKeyNameBeforeInitialisingDndZones('localId');

	type DndEventInfoNumberId = Omit<DndEventInfo, 'id'> & {
		id: number;
	};

	type TypedDndEvent<T> = {
		items: T[];
		info: DndEventInfoNumberId;
	};
</script>

<script lang="ts">
	import { createEventDispatcher } from 'svelte';
	import {
		dndzone,
		overrideItemIdKeyNameBeforeInitialisingDndZones,
		SHADOW_ITEM_MARKER_PROPERTY_NAME,
	} from 'svelte-dnd-action';
	import { flip } from 'svelte/animate';
	import { fade } from 'svelte/transition';

	import type { DndEvent, DndEventInfo } from 'svelte-dnd-action';
	import type { ListItem } from '$types/common';
	import { getRegistered } from '$lib/stores/register';
	import { updateSequence } from './helper';
	import { updateUi } from '$lib/stores/uiUpdate';
	import type { TypeType } from '$types/hierarchy';
	import { fakeStatusSymbol } from '$lib/stores/task';

	type _T = $$Generic;
	type T = _T extends ListItem & TypeType ? _T : never;

	const dispatch = createEventDispatcher<{
		droppedIntoZone: TypedDndEvent<T>;
		droppedIntoAnother: TypedDndEvent<T>;
	}>();

	export let type = 'default';
	export let items: T[] = [];
	export let disabled = false;

	// svelte-ignore unused-export-let - useful for debugging in the future
	export let name = 'unnamed';
	let itemsEphemeralCopy: typeof items = [...items];
	let isDragging = false;

	$: items, setItemsEphemeralCopy();

	const setItemsEphemeralCopy = () => {
		if (isDragging || !items) return;
		itemsEphemeralCopy = [...items].filter((value, index, self) => {
			const isUnique = index === self.findIndex((cmp) => cmp.localId === value.localId);
			if (!isUnique) {
				console.warn(`Duplicate item found in list ${name} with localId ${value.localId}`, value, [...items]);
			}
			return isUnique;
		});
	};

	function handleDndConsider(e: CustomEvent<DndEvent> & { target: EventTarget & HTMLOListElement }) {
		isDragging = true;
		itemsEphemeralCopy = e.detail.items as T[];
	}

	function handleDndFinalize(e: CustomEvent<DndEvent> & { target: EventTarget & HTMLOListElement }) {
		isDragging = false;
		itemsEphemeralCopy = e.detail.items as T[];

		const items = itemsEphemeralCopy.map((el) => {
			if (fakeStatusSymbol in el) {
				return el;
			} else {
				return getRegistered(el);
			}
		}) as T[];

		const event = {
			items,
			info: e.detail.info,
		} as unknown as TypedDndEvent<T>;

		if (e.detail.info.trigger === 'droppedIntoZone') {
			dispatch('droppedIntoZone', event);
		}
		if (e.detail.info.trigger === 'droppedIntoAnother') {
			dispatch('droppedIntoAnother', event);
		}
		updateSequence(items);
		updateUi();
	}

	// same as `item as { [SHADOW_ITEM_MARKER_PROPERTY_NAME]: HTMLElement }`
	const hasShadowMarker = (item: unknown) => item as { [SHADOW_ITEM_MARKER_PROPERTY_NAME]: HTMLElement };
</script>

<ol
	use:dndzone={{
		items: itemsEphemeralCopy,
		flipDurationMs: 200,
		type,
		dropTargetStyle: {},
		dropTargetClasses: ['dnd-drop-target'],
		dragDisabled: disabled,
	}}
	on:consider={handleDndConsider}
	on:finalize={handleDndFinalize}
	{...$$restProps}
>
	{#each itemsEphemeralCopy as item, i (item.localId)}
		<li
			data-testid="list-item-{i}"
			animate:flip={{
				duration: (dx) => Math.sqrt(dx) * 30,
			}}
		>
			<slot {item} {i}>
				{item.localId}
			</slot>
			{#if hasShadowMarker(item)[SHADOW_ITEM_MARKER_PROPERTY_NAME]}
				<div in:fade={{ duration: 200 }} class="shadow-item" />
			{/if}
		</li>
	{:else}
		<div on:mousedown|stopPropagation on:touchstart|stopPropagation on:keydown|stopPropagation>
			<slot name="empty" />
		</div>
	{/each}
</ol>

<style>
	ol,
	li {
		list-style: none;
		margin: 0;
		padding: 0;
	}

	ol {
		display: flex;
		flex-direction: column;
		gap: var(--size-2);
		min-height: var(--min-height, var(--size-7));
		height: 100%;
		border-radius: var(--size-1);
		outline: transparent dashed 1px;
		outline-offset: var(--size-3);
		transition-property: outline-color, outline-offset;
		transition-duration: 0.2s;
		transition-timing-function: ease-in-out;
	}

	/* stylelint-disable-next-line selector-pseudo-class-no-unknown */
	:global(.dnd-drop-target) {
		outline-color: var(--gray-6) !important;
		outline-offset: var(--size-2) !important;
	}

	li {
		position: relative;
		max-width: unset;
	}

	.shadow-item {
		position: absolute;
		inset: 0;
		visibility: visible;
		border-radius: var(--size-1);
		margin: 0;
		box-shadow: var(--inner-shadow-3);
	}

	/* HOTFIX for TipTap: https://github.com/isaacHagoel/svelte-dnd-action/issues/388#issue-1302190159 */
	/* stylelint-disable-next-line selector-pseudo-class-no-unknown */
	:global([contenteditable]) {
		user-select: text;
	}
</style>
