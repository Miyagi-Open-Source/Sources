export { default } from './move-menu.svelte';
