<script lang="ts">
	import Menu from '$components/menu';
	import MenuItem from '$components/menu/menu-item';
	import { createEventDispatcher } from 'svelte';
	import IcDown from '~icons/ic/round-arrow-downward';
	import IcUp from '~icons/ic/round-arrow-upward';
	import IcDragIndicator from '~icons/ic/round-drag-indicator';
	import IcBottom from '~icons/ic/round-vertical-align-bottom';
	import IcTop from '~icons/ic/round-vertical-align-top';
	import { updateSequence } from '../helper';

	import type { ListItem } from '$types/common';

	const dispatch = createEventDispatcher();

	type _T = $$Generic;
	type T = _T extends ListItem ? _T : never;

	export let items: T[];
	export let i: number;
	export let disabled = false;

	export const moveArrayItem = (index: number, newIndex: number) => {
		const [element] = items.splice(index, 1);
		items.splice(newIndex, 0, element);
		items = items;

		updateSequence(items);

		dispatch('change', items);
	};
</script>

<Menu variant="ghost" triggerTestId="move-menu">
	<svelte:fragment slot="label"><IcDragIndicator /></svelte:fragment>
	<slot name="top" />
	<MenuItem on:click={() => moveArrayItem(i, 0)} disabled={disabled || i === 0} data-testid="move-to-top">
		<IcTop />Send to top
	</MenuItem>
	<MenuItem on:click={() => moveArrayItem(i, i - 1)} disabled={disabled || i === 0} data-testid="move-up">
		<IcUp />Move up
	</MenuItem>
	<slot />
	<MenuItem
		on:click={() => moveArrayItem(i, i + 1)}
		disabled={disabled || i === items.length - 1}
		data-testid="move-down"
	>
		<IcDown />Move down
	</MenuItem>
	<MenuItem
		on:click={() => moveArrayItem(i, items.length - 1)}
		disabled={disabled || i === items.length - 1}
		data-testid="move-to-bottom"
	>
		<IcBottom />Send to bottom
	</MenuItem>
	<slot name="bottom" />
</Menu>
