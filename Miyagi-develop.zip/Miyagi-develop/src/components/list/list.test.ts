import { cleanup, render } from '@testing-library/svelte';
import { afterEach, beforeEach, describe, test, vi } from 'vitest';
import List from './';

beforeEach(cleanup);
afterEach(() => {
	vi.resetAllMocks();
});

describe('Component: List', () => {
	test('render', () => {
		render(List, { items: [] });
	});
});
