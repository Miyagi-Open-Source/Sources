export { default } from './code-generator.svelte';
