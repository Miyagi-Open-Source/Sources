<script lang="ts">
	import Menu from '$components/menu';
	import MenuItem from '$components/menu/menu-item';
	import { capitalizeFirstLetter } from '$lib/helper';
	import { addDays, addHours, addWeeks, formatDistance } from 'date-fns';
	import Button from '$components/button';
	import type { Project } from '$types/project';
	import { randomUUID } from '$lib/crypto';
	import { dialog } from '$components/dialog/dialog-function/dialog-function';

	export let project: Project;

	export let roles: string[];
	let selectedRole = roles.at(-1)!; // user must be able to give at least one role

	const durations = [
		{
			label: '1 Hour',
			value: addHours(new Date(), 1),
		},
		{
			label: '1 Day',
			value: addDays(new Date(), 1),
		},
		{
			label: '1 Week',
			value: addWeeks(new Date(), 1),
		},
		{
			label: 'Forever',
			value: null,
		},
	];
	let selectedDuration = durations[1];

	const userCounts = [1, 5, 10, 25, 50, 100];
	let selectedUserCount = userCounts[0];

	let code = '';
</script>

<div class="code">
	<div class="group">
		<label for="roleSelector">Role: </label>
		<Menu variant="ghost" id="roleSelector">
			<svelte:fragment slot="label">
				<h3>{capitalizeFirstLetter(selectedRole)}</h3>
			</svelte:fragment>
			{#each roles as role}
				<MenuItem
					selected={role === selectedRole}
					disabled={role === selectedRole}
					on:click={() => (selectedRole = role)}
				>
					{capitalizeFirstLetter(role)}
				</MenuItem>
			{/each}
		</Menu>
	</div>

	<div class="group">
		<label for="durationSelector">Duration: </label>
		<Menu variant="ghost" id="durationSelector">
			<svelte:fragment slot="label">
				<h3>{capitalizeFirstLetter(selectedDuration.label)}</h3>
			</svelte:fragment>
			{#each durations as duration}
				{@const { label, value } = duration}
				<MenuItem
					selected={value === selectedDuration.value}
					disabled={value === selectedDuration.value}
					on:click={() => (selectedDuration = duration)}
				>
					{label}
				</MenuItem>
			{/each}
			<MenuItem
				on:click={async () => {
					const [endDateString] = await dialog(
						'End Date',
						[
							{
								input: 'datetime-local',
							},
						],
						{
							message: 'Enter the date the invite code should expire',
							confirmLabel: 'Select',
							min: new Date().toISOString().substring(0, 16),
						}
					);

					if (!endDateString) return;

					const endDate = new Date(endDateString);
					selectedDuration = {
						label: formatDistance(new Date(), endDate),
						value: endDate,
					};
				}}
			>
				Custom
			</MenuItem>
		</Menu>
	</div>

	<div class="group">
		<label for="countSelector">Max Uses: </label>
		<Menu variant="ghost" id="countSelector">
			<svelte:fragment slot="label">
				<h3>{selectedUserCount}</h3>
			</svelte:fragment>
			{#each userCounts as userCount}
				<MenuItem
					selected={selectedUserCount === userCount}
					disabled={selectedUserCount === userCount}
					on:click={() => (selectedUserCount = userCount)}
				>
					{userCount}
				</MenuItem>
			{/each}
			<MenuItem
				on:click={async () => {
					const [userCountString] = await dialog(
						'User Count',
						[
							{
								input: 'number',
							},
						],
						{
							message: 'Enter the date the invite code should expire',
							confirmVariant: 'primary',
							confirmLabel: 'Select',
							min: 1,
							max: 100,
						}
					);

					if (!userCountString) return;
					selectedUserCount = +userCountString;
				}}
			>
				Custom
			</MenuItem>
		</Menu>
	</div>

	<Button
		on:click={() => {
			code = randomUUID();
			project.createInviteCode(code, selectedRole, selectedUserCount, selectedDuration.value);
		}}>Generate</Button
	>

	{#if code}
		{@const linkBase = document.location.origin + '/invites?inviteCode='}
		{@const inviteLink = linkBase + code}
		<code class="code">
			<span class="base" on:click={() => navigator.clipboard.writeText(inviteLink)} on:keydown>{linkBase}</span><span
				class="code"
				on:click={() => navigator.clipboard.writeText(code)}
				on:keydown>{code}</span
			>
		</code>
	{/if}
</div>

<style>
	code {
		cursor: pointer;
	}

	code > span {
		display: inline-block;
	}

	span.base:hover,
	span.code:hover,
	span.base:hover + span.code {
		color: var(--cyan-4);
	}
</style>
