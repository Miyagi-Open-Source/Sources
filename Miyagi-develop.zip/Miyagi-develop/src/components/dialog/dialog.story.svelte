<script>
	import Button from '$components/button';
	import Dialog from '.';
	export let Hst;

	let triggerLabel = 'Dialog Trigger Label';
	let open = false;
	let includedTrigger = true;
	let mandatory = false;
	let noCloseButton = false;

	// cSPELL:DISABLE
	const source = `<Dialog let:toggle>
	<p>This is a Dialog.</p>
	<p style="max-width: 40ch;">
		Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis ex dolorem et quibusdam qui magnam distinctio
		voluptates quod voluptas. Enim hic, quae voluptatem omnis accusantium facilis magni et amet placeat!
	</p>
	<svelte:fragment slot="dialog-actions">
		<Button class="btn" on:click={toggle}>Action Item 1</Button>
		<Button
			class="btn"
			on:click={() => {
				toggle();
			}}
		>
			Action Item 2
		</Button>
	</svelte:fragment>
</Dialog>
`;
</script>

<Hst.Story {source} title="Dialog">
	<svelte:fragment slot="controls">
		<Hst.Text bind:value={triggerLabel} title="triggerLabel" />
		<Hst.Checkbox bind:value={open} title="open" />
		<Hst.Checkbox bind:value={includedTrigger} title="includedTrigger" />
		<Hst.Checkbox bind:value={mandatory} title="mandatory" />
		<Hst.Checkbox bind:value={noCloseButton} title="noCloseButton" />
	</svelte:fragment>

	<Dialog let:toggle {triggerLabel} {open} {includedTrigger} {mandatory} {noCloseButton}>
		<p>This is a Dialog.</p>
		<p style="max-width: 40ch;">
			Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis ex dolorem et quibusdam qui magnam distinctio
			voluptates quod voluptas. Enim hic, quae voluptatem omnis accusantium facilis magni et amet placeat!
		</p>
		<svelte:fragment slot="dialog-actions">
			<Button class="btn" on:click={toggle}>Action Item 1</Button>
			<Button
				class="btn"
				on:click={() => {
					toggle();
				}}
			>
				Action Item 2
			</Button>
		</svelte:fragment>
	</Dialog>
</Hst.Story>
