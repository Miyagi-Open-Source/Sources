<script lang="ts">
	import Button from '$components/button';
	import type { ButtonVariants } from '$components/button/button.svelte';
	import appendToBody from '$lib/actions/appendToBody';
	import { focusTrap } from '$lib/actions/focus-trap';
	import { onDestroy } from 'svelte';
	import { fade, scale } from 'svelte/transition';
	import IcRoundClose from '~icons/ic/round-close';
	import IcRoundOpenInFull from '~icons/ic/round-open-in-full';
	import { createEventDispatcher } from 'svelte';

	const dispatch = createEventDispatcher();

	export let open = false;
	export let includedTrigger = true;
	export let mandatory = false;
	export let heading = 'Dialog';
	export let triggerIcon = IcRoundOpenInFull;
	export let triggerLabel = heading;
	export let noCloseButton = false;
	export let variant: ButtonVariants = 'regular';
	export let triggerElement: HTMLElement | null = null;
	export let triggerTestId = 'dialog-trigger';
	export let transitionOptions = {};
	export let backdropIn = fade;
	export let backdropInOptions = transitionOptions;
	export let backdropOut = fade;
	export let backdropOutOptions = transitionOptions;
	export let dialogIn = scale;
	export let dialogInOptions = transitionOptions;
	export let dialogOut = fade;
	export let dialogOutOptions = transitionOptions;

	function dismiss() {
		if (!mandatory) toggle();
		dispatch('dismiss');
	}

	function toggle() {
		open = !open;
		if (triggerElement) triggerElement.focus();
	}

	onDestroy(() => {
		open = false;
	});
</script>

<svelte:window
	on:keydown={(evt) => {
		if (open && evt.key === 'Escape') dismiss();
	}}
/>

{#if includedTrigger}
	<Button
		aria-label={triggerLabel}
		--width="var(--trigger-width)"
		--margin="var(--trigger-margin)"
		data-testid={triggerTestId}
		bind:elementRef={triggerElement}
		{variant}
		on:click={() => {
			open = !open;
		}}
	>
		<slot name="trigger-label">
			<svelte:component this={triggerIcon} />
			{triggerLabel}
		</slot>
	</Button>
{/if}

{#if open}
	<dialog open use:appendToBody use:focusTrap class="container">
		<section
			class="dialog"
			aria-labelledby="dialog-content"
			in:dialogIn={dialogInOptions}
			out:dialogOut={dialogOutOptions}
			{...$$restProps}
		>
			<div class="title">
				<h2>
					<slot name="title">
						{heading}
					</slot>
				</h2>
				{#if !(mandatory || noCloseButton)}
					<Button variant="ghost" aria-label="Close Dialog or Dialog" on:click={dismiss}>
						<IcRoundClose />
					</Button>
				{/if}
			</div>
			<slot {toggle} />
			{#if $$slots['dialog-actions']}
				<div class="dialog-actions">
					<slot name="dialog-actions" />
				</div>
			{/if}
		</section>
		<div
			on:click={dismiss}
			on:keydown
			class="backdrop"
			in:backdropIn={backdropInOptions}
			out:backdropOut={backdropOutOptions}
		/>
	</dialog>
{/if}

<style lang="">
	.container {
		isolation: isolate;
		position: absolute;
		z-index: 9;
	}

	.backdrop {
		position: fixed;
		inset: 0;
		z-index: -1;
		background: var(--backdrop-background, var(--gray-9));
		opacity: var(--backdrop-opacity, 0.8);
	}

	.dialog {
		position: fixed;
		inset: var(--top, 50%) var(--right, auto) var(--bottom, auto) var(--left, 50%);
		z-index: 1;

		/* overflow: var(--overflow, auto); */
		width: var(--width, fit-content);
		max-width: var(--max-width, calc(100vw - var(--size-9)));
		height: var(--height, auto);
		max-height: var(--max-height, calc(100vh - var(--size-9)));
		border-radius: var(--border-radius, 0.25em);
		padding: var(--padding, 1em);
		box-shadow: var(--shadow, var(--shadow-6));
		background: var(--background, var(--app-background));
		transform: var(--transform, translate(-50%, -50%));
	}

	.title {
		display: flex;
		align-items: flex-start;
		justify-content: space-between;
		gap: var(--size-3);
		margin-inline: calc(var(--size-3) * -1);
		margin-bottom: var(--size-2);
		padding-inline: var(--size-3);
		padding-bottom: var(--size-2);
		border-bottom: 1px solid var(--surface-4);
	}

	h2 {
		font-size: var(--font-size-4);
	}

	.dialog-actions {
		display: var(--actions-display, flex);
		justify-content: var(--actions-justify-content, space-between);
		gap: var(--actions-gap, var(--size-3));
		margin-top: var(--size-2);
	}

	/* stylelint-disable-next-line selector-pseudo-class-no-unknown */
	:global(.dialog-actions > button) {
		flex-grow: var(--actions-child-button-flex-grow, 1);
	}

	dialog {
		all: unset;
	}
</style>
