import { cleanup, render } from '@testing-library/svelte';
import { afterEach, beforeEach, expect, describe, test, vi } from 'vitest';
import Dialog from './dialog.svelte';

beforeEach(cleanup);
afterEach(() => {
	vi.resetAllMocks();
});

describe('Component: Dialog', () => {
	test('can render', () => {
		render(Dialog);
	});

	test('can render trigger', () => {
		const triggerLabel = 'Trigger';
		const { getByText } = render(Dialog, { triggerLabel });
		expect(getByText(triggerLabel)).toBeDefined();
	});
});
