export { default } from './dialog.svelte';
