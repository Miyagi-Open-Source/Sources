<script lang="ts">
	import Dialog from '$components/dialog';
	import Button from '$components/button';

	import { accessUndefined, isAny, notNull } from '$lib/helper';
	import { doneFunction, InputOptions, types } from './dialog-function';

	const close = () => doneFunction(Array(Math.max($types!.data.length, 1)).fill(null));

	const values = Symbol('DialogValues');
</script>

{#if $types}
	<Dialog open={true} includedTrigger={false} heading={$types.title} on:dismiss={close}>
		{#if $types.options?.message}
			{#if $types.options?.rawHtml}
				<p>{@html $types.options.message}</p>
			{:else}
				<p>{$types.options.message}</p>
			{/if}
		{/if}

		{#each $types.data as dialogDataIn}
			{#if dialogDataIn.label}
				<p>{dialogDataIn.label}</p>
			{/if}
			{@const { component, defaultArgs } = accessUndefined(InputOptions[dialogDataIn.input])}
			{@const { label, input, ...args } = accessUndefined(dialogDataIn)}

			<!-- @ts-ignore -->
			<svelte:component this={isAny(component)} bind:value={dialogDataIn[values]} {...{ ...defaultArgs, ...args }} />
		{/each}

		<div class="buttons">
			{#if $types.options?.cancel}
				<Button on:click={() => doneFunction([false])}>{$types.options?.cancelLabel ?? 'Cancel'}</Button>
			{/if}
			<Button
				variant="primary"
				on:click={() => {
					if (notNull($types).data.length === 0) return doneFunction([true]);

					doneFunction(notNull($types).data.map((dialogDataIn) => dialogDataIn[values]));
				}}>{$types.options?.confirmLabel ?? 'Confirm'}</Button
			>
		</div>
	</Dialog>
{/if}
