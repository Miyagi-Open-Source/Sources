import type { SvelteComponent } from 'svelte';
// import Button from '$components/button';
import Input from '$components/input';
import Checkbox from '$components/checkbox';
import SprintSelector from '$components/miyagi/analytics/sprint-selector/sprint-selector.svelte';
import type { Sprint } from '$types/sprint';
import type { Compute, valueOf } from '$types/helper';
import { writable, type Writable } from 'svelte/store';
import type { Member } from '$types/member';
import UserSelector from '$components/user-selector/user-selector.svelte';

type InputOption = {
	readonly component: typeof SvelteComponent;
	readonly returnType: unknown;
	readonly defaultArgs?: Record<string, string | number>;
	readonly requiredArgs?: Record<string, unknown>;
};

export const InputOptions = {
	string: {
		component: Input,
		returnType: null as unknown as string,
		defaultArgs: {
			type: 'input',
		},
	},
	number: {
		component: Input,
		returnType: null as unknown as number,
		defaultArgs: {
			type: 'number',
			value: 0,
		},
	},
	textarea: {
		component: Input,
		returnType: null as unknown as string,
		defaultArgs: {
			type: 'textarea',
		},
	},
	boolean: {
		component: Checkbox,
		returnType: null as unknown as boolean,
		defaultArgs: {
			type: 'checkbox',
		},
	},
	'datetime-local': {
		component: Input,
		returnType: null as unknown as string,
		defaultArgs: {
			type: 'datetime-local',
		},
	},
	email: {
		component: Input,
		returnType: null as unknown as string,
		defaultArgs: {
			type: 'email',
		},
	},
	password: {
		component: Input,
		returnType: null as unknown as string,
		defaultArgs: {
			type: 'password',
		},
	},
	sprint: {
		component: SprintSelector,
		returnType: null as unknown as Sprint,
		requiredArgs: {
			sprints: null as unknown as readonly Sprint[],
		},
	},
	user: {
		component: UserSelector,
		returnType: null as unknown as Member | null,
		requiredArgs: {
			users: null as unknown as readonly Member[],
		},
	},
} as const satisfies Record<string, InputOption>;

type DialogDataIn = valueOf<{
	[K in keyof typeof InputOptions]: Compute<
		{
			readonly label?: string;
			readonly input: K;
		} & ((typeof InputOptions)[K] extends { requiredArgs: unknown }
			? (typeof InputOptions)[K]['requiredArgs']
			: unknown)
	>;
}>;

type DialogDataOut<T extends DialogDataIn> = {
	readonly output: (typeof InputOptions)[T['input']]['returnType'];
};

type Options =
	| {
			readonly cancel?: boolean;
			readonly message?: string;
			readonly confirmLabel?: string;
			readonly cancelLabel?: string;
			readonly rawHtml?: boolean;
	  }
	| Record<string, string | number | boolean>;

export const types: Writable<{
	readonly data: readonly DialogDataIn[];
	readonly title: string;
	readonly options?: Options;
} | null> = writable(null);
export let doneFunction: (data: DialogDataOut<DialogDataIn>[] | null[] | [boolean]) => void;

/* TODO use const T if const is supported*/
export function dialog(title: string, options?: Options): Promise<readonly [boolean | null]>;

export function dialog<T extends readonly DialogDataIn[]>(
	title: string,
	_types: T,
	options?: Options
): Promise<
	| (T extends infer A
			? {
					// @ts-ignore This code is correct, ts just doesn't know it
					[K in keyof A]: Compute<DialogDataOut<A[K]>>['output'];
			  }
			: never)
	| {
			[K in keyof T]: null;
	  }
>;

export function dialog<T extends readonly DialogDataIn[]>(
	title: string,
	_types?: T | Options,
	options?: Options
):
	| Promise<
			| (T extends infer A
					? {
							// @ts-ignore This code is correct, ts just doesn't know it
							[K in keyof A]: Compute<DialogDataOut<A[K]>>['output'];
					  }
					: never)
			| {
					[K in keyof T]: null;
			  }
	  >
	| Promise<readonly unknown[]> {
	const isConfirm = !Array.isArray(_types);

	types.set({
		title,
		data: isConfirm ? [] : (_types as T),
		options: isConfirm ? { cancel: true, ..._types } : options,
	});

	return new Promise((resolve) => {
		doneFunction = (data) => {
			types.set(null);
			resolve(data);
		};
	});
}

// Example usage:
// export const test = await dialog('', [

//     {
//         label: 'nope',
//         input: 'user',
//         users: []
//     },
//     {
//         label: 'nope',
//         input: 'string',
//     },
// ] as const, {
//     message: `user.`,
//     cancel: true,
//     confirmLabel: 'Delete Account',
// });

// const test = await dialog('');

// if (browser) window.dialog = dialog
