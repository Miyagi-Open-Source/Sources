<script lang="ts">
	export let value = false;
	export let disabled = false;
	export let required = false;
</script>

<input
	type="checkbox"
	bind:checked={value}
	{disabled}
	{required}
	{...$$restProps}
	on:click
	on:focus
	on:blur
	on:change
	on:dblclick
/>
