Task component is a that describes a task.
