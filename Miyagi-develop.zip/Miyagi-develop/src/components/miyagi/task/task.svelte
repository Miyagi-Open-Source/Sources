<script lang="ts">
	import Avatar from '$components/avatar';
	import Menu from '$components/menu';
	import MenuItem from '$components/menu/menu-item';
	import { userStore } from '$lib/db/auth';
	import { openDetails } from '$lib/stores/details';
	import type { Task } from '$types/task';
	import IcRoundExpandMore from '~icons/ic/round-expand-more';
	import TaskForm from './task-form';
	import { editingDisabled } from '$lib/symbols';
	import { handleMiddleClick } from '$lib/actions/handle-middle-click';
	import TaskHead from './task-head.svelte';

	export let task: Task;
	export let disabled = false;

	$: members = task.story?.sprint.project.members;
	$: _disabled = task[editingDisabled] || disabled;

	let reviewed = false;

	const toggleReviewed = () => {
		reviewed = !reviewed;
	};
</script>

<details
	bind:open={$openDetails.task[task.id]}
	data-testid="task-card"
	use:handleMiddleClick
	on:handleMiddleClick={toggleReviewed}
	on:dblclick={toggleReviewed}
	class:reviewed
	{...$$restProps}
>
	<summary>
		<TaskHead {task}>
			<slot name="front" slot="front" />
			<Menu
				placement="bottom-end"
				slot="user-select"
				variant="ghost"
				forceIconOnly={true}
				disabled={_disabled}
				on:contextmenu={(e) => {
					e.preventDefault();

					task.update({ assigneeId: task.assigneeId === $userStore?.id ? null : $userStore?.id });
				}}
			>
				<svelte:fragment slot="label">
					<Avatar
						size="small"
						profile={task.assigneeId != null
							? task.assigneeId === '00000000-0000-0000-0000-000000000000'
								? { username: 'deleted' }
								: members?.find(({ id }) => id === task.assigneeId)
							: undefined}
					/>
				</svelte:fragment>
				{#if !['inProgress', 'done'].includes(task.status)}
					<MenuItem on:click={() => task.update({ assigneeId: null })}>
						<Avatar size="small" />
						Unassign
					</MenuItem>
					<hr />
				{/if}
				{#each members.sort((a) => (a.id === $userStore?.id ? -1 : 0)) as user}
					<MenuItem selected={user.id === task.assigneeId} on:click={() => task.update({ assigneeId: user.id })}>
						<Avatar size="small" profile={user} />
						{user.username}
					</MenuItem>
				{/each}
			</Menu>
			<span slot="end" class="expand-indicator" class:open={$openDetails.task[task.id]}>
				<IcRoundExpandMore />
			</span>
		</TaskHead>
	</summary>
	{#if members}
		<TaskForm {task} on:change={({ detail: patch }) => task.update(patch)} disabled={_disabled} />
	{/if}
</details>

<style lang="postcss">
	details {
		border: 1px solid var(--surface-4);
		padding: var(--size-2);
		background-color: var(--surface-1);
		box-sizing: border-box;
	}

	summary {
		display: flex;
		list-style: none;
		border-radius: var(--radius-1);
		margin: 0;
		padding-block: 0;
		padding-inline: var(--size-2);
	}

	details.reviewed::before {
		content: '';
		position: absolute;
		top: 0;
		bottom: 0;
		left: 0;
		display: block;
		width: var(--size-2);
		border-radius: var(--radius-2) 0 0 var(--radius-2);
		background-color: var(--lime-6);
	}
</style>
