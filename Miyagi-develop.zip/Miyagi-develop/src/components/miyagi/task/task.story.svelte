<script>
	import sampleTask from './sample-task';
	import Task from './task.svelte';
	export let Hst;
</script>

<Hst.Story title="Miyagi/Task/Task (Card)">
	<Task task={sampleTask} />
</Hst.Story>
