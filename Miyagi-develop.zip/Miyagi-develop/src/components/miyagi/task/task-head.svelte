<script lang="ts">
	import StatusTag from '$components/status-tag';
	import type { Task } from '$types/task';

	export let task: Pick<Task, 'title' | 'displayId' | 'type' | 'id' | 'status'>;
</script>

<div class="title" on:click on:keypress>
	<slot name="front" />
	<StatusTag el={task} />
	<h5 data-testid="task-title">
		{task.title}
	</h5>
	<span class="end">
		<slot name="user-select" />
		<slot name="end" />
	</span>
</div>

<style>
	.title,
	.end {
		display: inline-flex;
		align-items: center;
		gap: var(--size-3);
	}

	.title {
		width: 100%;
	}

	.end {
		margin-left: auto;
	}

	h5 {
		overflow: hidden;
		flex: 1;
		font-size: var(--font-size-2);
		font-weight: var(--font-weight-5);
		text-overflow: ellipsis;
		white-space: nowrap;
	}
</style>
