<script>
	import sampleTask from '../sample-task';
	import TaskForm from './task-form.svelte';
	export let Hst;
</script>

<Hst.Story title="Miyagi/Task/TaskForm">
	<TaskForm task={sampleTask} />
</Hst.Story>
