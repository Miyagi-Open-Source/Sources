<script lang="ts">
	import Button from '$components/button';
	import Editor from '$components/tiptap/editor';
	import Input from '$components/input';
	import type { Task } from '$types/task';
	import type { JSONContent } from '@tiptap/core';
	import { createEventDispatcher, onMount } from 'svelte';
	import IcDelete from '~icons/ic/round-delete-forever';
	const dispatch = createEventDispatcher<{ change: Partial<Task> }>();
	import { editingDisabled, focus } from '$lib/symbols';
	import { openDetails } from '$lib/stores/details';
	import { dialog } from '$components/dialog/dialog-function/dialog-function';

	export let task: Task;
	export let disabled = false;

	const handleChange = (key: string) => (event: Event) => {
		dispatch('change', {
			[key]: (event.target as HTMLInputElement).value,
		});
	};

	$: content = task.description as JSONContent;

	let titleEl: HTMLInputElement;
	onMount(() => {
		task[focus] = () => {
			task[editingDisabled] = false;
			$openDetails.task[task.id] = true;
			setTimeout(() => {
				titleEl.focus();
				titleEl.scrollIntoView({ block: 'center', behavior: 'smooth' });
				titleEl.select();
			}, 0);
		};
	});
</script>

<form on:submit|preventDefault>
	<Input
		value={task.title}
		on:change={handleChange('title')}
		on:dblclick={(event) => {
			event.stopPropagation();
		}}
		data-testid="task-title-form"
		{disabled}
		bind:elementRef={titleEl}>Title</Input
	>
	<Editor
		{content}
		on:change={({ detail: value }) => dispatch('change', { description: value })}
		{disabled}
		title="Description / Acceptance"><span title="Description / Acceptance">Description / Acceptance</span></Editor
	>
	<Button
		aria-label="Delete Task"
		variant="hover-warn"
		--width="fit-content"
		--margin="0 0 0 auto"
		on:click={async (e) => {
			if (e.ctrlKey) return task.delete();

			const [deleteConfirmed] = await dialog('Delete Task', {
				message: 'Are you sure you want to delete this task?',
			});
			if (deleteConfirmed) task.delete();
		}}
		{disabled}
	>
		<IcDelete />
	</Button>
</form>

<style>
	form {
		padding: var(--size-2);
	}
</style>
