import { cleanup, render } from '@testing-library/svelte';
import { beforeEach, describe, test } from 'vitest';
import sampleTask from '../sample-task';
import TaskForm from './task-form.svelte';

beforeEach(() => {
	cleanup();
});

describe('Component: TaskForm', () => {
	test('can render', () => {
		render(TaskForm, { task: sampleTask });
	});
});
