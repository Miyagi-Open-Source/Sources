The TaskForm component displays the data of a Task in a form and allows edits to be made to it.
