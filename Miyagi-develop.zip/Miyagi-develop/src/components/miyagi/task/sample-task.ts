import content from '$components/tiptap/editor/editor-test-content';
import { awaitLoaded } from '$lib/handlers';
import type { Story } from '$types/story';
import type { Task } from '$types/task';

const sampleTask: Task = {
	id: '0',
	localId: 0,
	storyId: '0',
	sequence: 0,
	displayId: 1337,
	type: 'task',
	story: null as unknown as Story,
	title: 'Example Task Title',
	status: 'backlog',
	description: { ...content },
	createdAt: '',
	assigneeId: '',
	async update() {
		return this;
	},
	delete: () => null,
	// [fromCache]: false,
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	[awaitLoaded]: async () => 0 as any,
	completedAt: '',
} as unknown as Task;

export default sampleTask;
