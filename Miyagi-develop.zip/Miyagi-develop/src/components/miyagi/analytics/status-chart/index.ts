export { default } from './status-chart.svelte';
import statusSettings from '$lib/project-settings';
import type { Sprint } from '$types/sprint';
import { derived } from 'svelte/store';
import { dimension, type Dimension } from '../dimension-selector';
import { selectedSprint } from '../selectedSprint';

export const statusChartData = derived([selectedSprint, dimension], ([$sprint, $dimension]) => {
	if (!$sprint) return null;
	return calcStatusChartData($sprint, $dimension);
});

function calcStatusChartData(sprint: Sprint, dimension: Dimension) {
	const statusKeys = Object.keys(statusSettings);
	const labels = Object.values(statusSettings).map((s) => s.label.toUpperCase());
	const values: number[] = new Array(statusKeys.length).fill(0);
	const statusKeyLookup = Object.fromEntries(statusKeys.map((s, i) => [s, i]));

	sprint.stories.forEach((story) => {
		if (dimension === 'TASK_COUNT') {
			story.tasks.forEach((task) => {
				values[statusKeyLookup[task.status]] += 1;
			});
		} else {
			values[statusKeyLookup[story.status]] += story.points;
		}
	});

	// todo: put each status in own series to support different colors
	return { labels, datasets: [{ values }] };
}
