<script lang="ts">
	import Chart from 'svelte-frappe-charts';
	import { statusChartData } from '.';
</script>

<Chart data={$statusChartData} type="bar" height="420" />
