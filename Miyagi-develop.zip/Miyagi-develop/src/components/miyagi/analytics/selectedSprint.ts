import { editingDisabled } from '$lib/symbols';
import type { Sprint } from '$types/sprint';
import { writable, type Writable } from 'svelte/store';

export const selectedSprint: Writable<Sprint | null> = writable(null);

export const selectSprint = (sprint: Sprint) => {
	if (sprint.endDate != null) sprint[editingDisabled] = true;
	selectedSprint.set(sprint);
};
