<script lang="ts">
	import Chart from 'svelte-frappe-charts';
	import { dimension, type Dimension } from './dimension-selector';
	import type { Project } from '$types/project';
	import Input from '$components/input';

	export let project: Project;
	let sprintCount = 5;

	$: ({ labels, datasets } = generateVelocityData(project, $dimension, sprintCount));

	$: data = {
		labels,
		datasets,
		yRegions: [{ label: '', start: 0, end: 0 }], // go down to zero
	};

	const generateVelocityData = (project: Project, dimension: Dimension, sprintCount: number) => {
		if (!project || !project.pastSprints) return {};

		const sprints = project.pastSprints.slice(-sprintCount);
		const labels = sprints.map((sprint) => `SP-${sprint.displayId ?? sprint.id}`);

		const targetSelector = dimension === 'TASK_COUNT' ? 'taskCount' : 'points';

		const planned = sprints.map((sprint) =>
			sprint.stories
				.filter((story) => +new Date(story.addedToSprintAt) < +new Date(sprint.startDate!))
				.reduce((acc, story) => acc + story[targetSelector], 0)
		);

		const completed = sprints.map((sprint) =>
			sprint.stories.filter((story) => story.status === 'done').reduce((acc, story) => acc + story[targetSelector], 0)
		);

		const datasets = [
			{
				name: `Planned (${planned.length ? Math.round(planned.reduce((a, b) => a + b, 0) / planned.length) : 0})`,
				values: planned,
			},
			{
				name: `Completed (${
					completed.length ? Math.round(completed.reduce((a, b) => a + b, 0) / completed.length) : 0
				})`,
				values: completed,
			},
		];

		return {
			labels,
			datasets,
		};
	};
</script>

<h3>
	<span
		>Velocity Sprint of last <Input type="number" bind:value={sprintCount} min="1" max="25" /> Sprint{sprintCount === 1
			? ''
			: 's'}</span
	>
</h3>
<Chart {data} type="bar" height="420" colors={['#ced4da', '#5f3dc4']} />

<style>
	h3 {
		/* display: flex; */
		width: 5ch;
		white-space: nowrap;
	}
</style>
