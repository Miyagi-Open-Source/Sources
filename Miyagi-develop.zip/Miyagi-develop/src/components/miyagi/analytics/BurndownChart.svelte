<script lang="ts">
	import { differenceInDays } from 'date-fns';
	import { selectedSprint } from './selectedSprint';
	import Chart from 'svelte-frappe-charts';
	import type { Sprint } from '$types/sprint';
	import { dimension, type Dimension } from './dimension-selector';

	$: ({ labels, datasets } = generateBurndownData($selectedSprint, $dimension));

	const generateBurndownData = (sprint: Sprint | null, dimension: Dimension) => {
		if (!sprint || sprint?.duration == null || !sprint?.startDate) {
			return {};
		}

		const targetSelector = dimension === 'TASK_COUNT' ? 'taskCount' : 'points';

		const stories = sprint?.stories;
		if (!stories) return {};

		const totalPointsTasks = stories
			.filter((story) => +new Date(story.addedToSprintAt) < +new Date(sprint.startDate!))
			.reduce((acc, story) => acc + story[targetSelector], 0);

		const startDate = sprint.startDate;
		const endDate = sprint.endDate;
		const duration = endDate ? differenceInDays(new Date(endDate), new Date(startDate)) : sprint.duration!;
		const plannedDuration = sprint.duration ?? duration;
		const days = new Array(duration + 2).fill(0).map((_, i) => i);

		const burnDown = [...days].fill(0);

		if (targetSelector === 'points') {
			stories
				.filter((story) => story.status === 'done')
				.map(
					(story) =>
						[
							story,
							story.tasks.sort((taskA, taskB) => +new Date(taskA.completedAt!) - +new Date(taskB.completedAt!))[0]
								?.completedAt,
						] as const
				)
				.forEach(([story, completedAt]) => {
					if (!completedAt) return;
					const daysAfterStart = differenceInDays(new Date(completedAt), new Date(startDate));
					burnDown[Math.max(daysAfterStart + 1, 0)] += story[targetSelector];
				});
		} else {
			stories
				.flatMap((story) => story.tasks)
				.filter((task) => task.completedAt)
				.forEach((task) => {
					const daysAfterStart = differenceInDays(new Date(task.completedAt!), new Date(startDate));
					burnDown[Math.max(daysAfterStart + 1, 0)] += 1;
				});
		}

		const datasets = [
			{
				name: 'Burn Down',
				values: burnDown.map(
					(
						(sum) => (value) =>
							(sum -= value)
					)(totalPointsTasks)
				),
			},
		];

		if (plannedDuration)
			datasets.push({
				name: 'Planned',
				values: days.map((day) =>
					Math.max(0, Math.round(totalPointsTasks - (totalPointsTasks / plannedDuration) * day))
				),
			});

		return {
			labels: days.map((day) => `Day ${day}`),
			datasets,
		};
	};
</script>

{#if labels && datasets}
	<h3>Burndown Chart</h3>
	<Chart
		data={{
			labels,
			datasets,
			yRegions: [{ label: '', start: 0, end: 0 }], // go down to zero
		}}
		type="line"
		height="420"
		colors={['#5c940d']}
	/>
{/if}
