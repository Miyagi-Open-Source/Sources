export { default } from './dimension-selector.svelte';
import { writable } from 'svelte/store';

export type Dimension = 'TASK_COUNT' | 'STORY_POINTS';

export const dimension = writable<Dimension>('STORY_POINTS');
