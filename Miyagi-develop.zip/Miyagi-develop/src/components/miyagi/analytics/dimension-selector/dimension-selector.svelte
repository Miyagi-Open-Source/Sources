<script lang="ts">
	import { setClipPath } from '$lib/actions/set-clip-path';
	import { onMount, type SvelteComponent } from 'svelte';
	import IcOutlineAnimation from '~icons/ic/outline-animation';
	import IcRoundTask from '~icons/ic/round-task';
	import { dimension, type Dimension } from '.';

	const options: { value: Dimension; label: string; icon: typeof SvelteComponent }[] = [
		{ value: 'STORY_POINTS', label: 'Story Points', icon: IcOutlineAnimation },
		{ value: 'TASK_COUNT', label: 'Task Count', icon: IcRoundTask },
	];

	onMount(() => {
		$dimension = $dimension;
	});
</script>

<div class="sticky-side-menu">
	<h2>Dimension</h2>
	{#each options as { value, label, icon }}
		<button class:selected={$dimension === value} on:click={() => dimension.set(value)}>
			<svelte:component this={icon} />
			{label}</button
		>
	{/each}
</div>

<!-- duplicate menu for clip path effect -->
<div
	class="sticky-side-menu clip-container"
	aria-hidden="true"
	use:setClipPath={{
		selector: $dimension ? '#' + $dimension : undefined,
		insetShapeAppendix: 'round 0 var(--radius-round) var(--radius-round) 0',
	}}
>
	<h2>Dimension</h2>
	{#each options as { value, label, icon }}
		<div class="clip-button" id={value}>
			<svelte:component this={icon} />
			{label}
		</div>
	{/each}
</div>

<style lang="postcss">
	.sticky-side-menu {
		position: fixed;
		top: 20%;
		left: 0;
		z-index: 2;
		display: flex;
		flex-direction: column;
		align-items: flex-start;
		gap: var(--size-1);
		width: fit-content;
	}

	h2 {
		padding-inline-start: var(--size-2);
		font-size: var(--font-size-3);
		font-weight: var(--font-weight-6);
	}

	button,
	.clip-button {
		--right-radius: var(--radius-round);

		display: flex;
		align-items: center;
		gap: var(--size-1);
		text-align: left;
		padding-block: var(--size-1);
		padding-inline-start: var(--size-2);
		padding-inline-end: var(--size-3);
		background-color: transparent;
		border-top-right-radius: var(--right-radius);
		border-bottom-right-radius: var(--right-radius);
		transition-property: box-shadow, background-color, color;
		transition-duration: 0.2s;
		transition-timing-function: var(--ease-out-1);

		&:hover {
			box-shadow: var(--shadow-3);
		}

		&:active {
			box-shadow: var(--shadow-1);
			background-color: var(--surface-2);
		}
	}

	.clip-container {
		pointer-events: none;
		background-color: var(--violet-9);
		color: var(--gray-1);
		transition: clip-path 0.2s var(--ease-out-3);
	}
</style>
