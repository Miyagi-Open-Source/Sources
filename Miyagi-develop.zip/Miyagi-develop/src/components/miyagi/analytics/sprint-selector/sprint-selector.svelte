<script lang="ts">
	import MenuItem from '$components/menu/menu-item';
	import SprintHead from '$components/miyagi/sprint/sprint-head.svelte';
	import clickOutside from '$lib/actions/click-outside';
	import type { Sprint } from '$types/sprint';
	import { createEventDispatcher, tick } from 'svelte';
	import { slide } from 'svelte/transition';
	import IcBaselineArrowDropDown from '~icons/ic/baseline-arrow-drop-down';
	import IcRoundSearchOff from '~icons/ic/round-search-off';

	const dispatch = createEventDispatcher<{ change: Sprint }>();
	export let sprints: Sprint[];
	export let value: Sprint | null = sprints[0];

	let open = false;
	let inputElement: HTMLInputElement;

	const handleClick = async () => {
		open = true;
		await tick();
		inputElement.focus();
	};
	const dismiss = () => {
		open = false;
		search = '';
	};
	const handleSprint = (sprint: Sprint) => {
		value = sprint;
		dispatch('change', sprint);
		dismiss();
	};

	const sprintSearch = (sprint: Sprint) => {
		const nameIncludesSearch = sprint.name.toLowerCase().includes(search.toLowerCase());
		const displayIdString = 'SP-' + sprint.displayId?.toString();
		const displayIdIncludesSearch = displayIdString.toLowerCase().includes(search.toLowerCase());

		return nameIncludesSearch || displayIdIncludesSearch;
	};

	let search = '';

	$: filteredSprints = search ? sprints.filter(sprintSearch) : sprints;
</script>

{#if !open}
	<button class="selected-sprint" on:click={handleClick}>
		<SprintHead titleTag="span" sprint={value} />
		<IcBaselineArrowDropDown />
	</button>
{:else}
	<div class="autocomplete">
		<input
			bind:this={inputElement}
			bind:value={search}
			class="sprint-search"
			use:clickOutside={{
				enabled: open,
				func: dismiss,
				exclude: '[data-sprint-selector]',
			}}
		/>
		<ul in:slide={{ duration: 200 }}>
			{#each filteredSprints as sprint}
				<MenuItem on:click={() => handleSprint(sprint)} tabindex={0} selected={sprint === value} data-sprint-selector>
					<SprintHead {sprint} />
				</MenuItem>
			{:else}
				<div class="list-else">
					<IcRoundSearchOff />
					<span> No Sprint found. </span>
				</div>
			{/each}
		</ul>
	</div>
{/if}

<style lang="postcss">
	button,
	.autocomplete {
		min-width: var(--size-15);
	}

	.selected-sprint,
	.sprint-search {
		display: flex;
		align-items: center;
		justify-content: space-between;
		width: 100%;
		height: var(--size-8);
		border: 1px solid var(--gray-6);
		border-radius: var(--size-1);
		margin-bottom: var(--size-3);
		padding: var(--size-2) var(--size-3);
		background: var(--app-background);
	}

	.autocomplete {
		position: relative;
	}

	ul {
		position: absolute;
		z-index: 2;
		display: flex;
		flex-direction: column;
		gap: var(--size-1);
		min-width: min-content;
		width: 100%;
		border-radius: var(--size-1);
		padding: 0;
		padding-block: var(--size-1);
		box-shadow: var(--shadow-4);
		background-color: var(--surface-2);
	}

	.list-else {
		display: grid;
		place-items: center;
		padding: var(--size-4);
		color: var(--gray-6);
		font-size: var(--font-size-5);
		font-weight: var(--font-weight-6);

		& span {
			font-size: var(--font-size-3);
		}
	}
</style>
