<script lang="ts">
	import List from '$components/list';
	import MoveMenu from '$components/list/move-menu';
	import MenuItem from '$components/menu/menu-item';
	import StatusTag from '$components/status-tag';
	import { userStore } from '$lib/db/auth';
	import statusSettings from '$lib/project-settings';
	import { openDetails } from '$lib/stores/details';
	import type { Story } from '$types/story';
	import type { Task as TaskType } from '$types/task';
	import { get } from 'svelte/store';
	import IcRoundArrowBack from '~icons/ic/round-arrow-back';
	import IcRoundArrowForward from '~icons/ic/round-arrow-forward';
	import IcRoundExpandMore from '~icons/ic/round-expand-more';
	import Task from '../task';
	import StoryForm from './story-form';
	import { editingDisabled } from '$lib/symbols';
	import { LOCALID } from '$lib/stores/localId';
	import type { AtLeast } from '$types/helper';
	import { onMount } from 'svelte';
	import { requestIdleCallbackAtLeast } from '$lib/helper';
	import { fakeStatusSymbol } from '$lib/stores/task';
	import StoryHead from './story-head.svelte';

	export let story: Story;
	export let showStatusColumns = false;
	export let filterUser: string | undefined = undefined;
	export let showUnassigned = true;

	const allStatus = Object.keys(statusSettings) as (keyof typeof statusSettings)[];
	export let disabled = false;

	$: status = story.status;
	$: tasks = story.tasks;

	const statusTask = {
		sequence: 0,
		type: 'story',
		status: story.status,
		localId: LOCALID.get({ type: 'task' }),
		displayId: story.displayId,
		update({ status }: AtLeast<TaskType, 'status'>) {
			story.update({ status });
			statusTask.status = status;
			// statusTask = statusTask; // trigger svelte update;
		},
		[fakeStatusSymbol]: true,
		[editingDisabled]: true,
		title: `Status of ${story.title}`,
	} as unknown as TaskType;

	const updateStatusTask = () => {
		statusTask.status = story.status;
		statusTask.title = `Status of ${story.title}`;
	};
	$: story, updateStatusTask();

	const reassign = (status: string, assigneeId: string | null) => {
		if (status === 'backlog') {
			return null;
		} else if (status !== 'done') {
			// eslint-disable-next-line @typescript-eslint/no-non-null-assertion
			return get(userStore)!.id;
		} else if (assigneeId) {
			return assigneeId;
		} else {
			// eslint-disable-next-line @typescript-eslint/no-non-null-assertion
			return get(userStore)!.id;
		}
	};

	/** Controls if the story shows tasks in columns */
	$: _disabled = story[editingDisabled] || disabled;
	$: progressDisabled = story.sprint?.isRunning !== true;
	$: tasksWithStatusHandle = tasks.length === 0 ? [statusTask] : tasks;

	let wasOpen = false;
	$: $openDetails.story[story.id] && (wasOpen = true);

	let isIdle = false;
	onMount(() =>
		requestIdleCallbackAtLeast(() => {
			isIdle = true;
		}, story.taskCount)
	);
</script>

<div class="container" data-testid="story-card">
	<details bind:open={$openDetails.story[story.id]}>
		<summary>
			<StoryHead {story}>
				<slot name="front" slot="front" />
				<span slot="end" class="expand-indicator" class:open={$openDetails.story[story.id]}>
					<IcRoundExpandMore />
				</span>
			</StoryHead>
		</summary>
		<div class="not-draggable" on:mousedown|stopPropagation on:touchstart|stopPropagation on:keydown|stopPropagation>
			<StoryForm bind:story on:change={({ detail: patch }) => story.update(patch)} disabled={_disabled} />

			{#if $openDetails.story[story.id] || wasOpen || isIdle}
				<section class="tasks">
					{#if !showStatusColumns}
						<List
							items={filterUser || !showUnassigned
								? tasks.filter(({ assigneeId }) =>
										filterUser ? assigneeId === filterUser || (showUnassigned && !assigneeId) : assigneeId
								  )
								: tasks}
							let:item
							let:i
							type="task_{story.id}"
							data-testid="list-story-tasks"
							disabled={_disabled}
						>
							<Task task={item}>
								<svelte:fragment slot="front">
									<MoveMenu bind:items={tasks} {i} disabled={disabled || progressDisabled} />
								</svelte:fragment>
							</Task>
						</List>
					{/if}
				</section>
			{/if}
		</div>
	</details>
	{#if showStatusColumns}
		<div
			class="task-cols not-draggable"
			on:mousedown|stopPropagation
			on:touchstart|stopPropagation
			on:keydown|stopPropagation
		>
			{#each allStatus as status}
				{@const tasksOfStatus = tasksWithStatusHandle.filter((task) => task.status === status)}

				<section class="task-col" style:background-color="var(--{status}-background-color">
					<List
						items={filterUser || !showUnassigned
							? tasksOfStatus.filter(({ assigneeId }) =>
									filterUser ? assigneeId === filterUser || (showUnassigned && !assigneeId) : assigneeId
							  )
							: tasksOfStatus}
						let:item={task}
						let:i
						type="task_{story.id}"
						on:droppedIntoZone={({ detail: { items: tasks } }) =>
							tasks
								.filter((task) => task.status !== status)
								.forEach((task) => {
									task.update({
										status,
										assigneeId: reassign(status, task.assigneeId),
									});
								})}
						data-testid="list-status-{status}"
						disabled={disabled || progressDisabled}
					>
						<Task {task} disabled={_disabled} title={task.assigneeId}>
							<svelte:fragment slot="front">
								<MoveMenu items={tasksOfStatus} {i} disabled={disabled || progressDisabled}>
									<svelte:fragment slot="top">
										{#each allStatus.filter((a) => a !== status) as otherStatus}
											<MenuItem
												on:click={() =>
													task.update({
														status: otherStatus,
														sequence: story.tasks.length - 1,
														assigneeId: reassign(status, task.assigneeId),
													})}
												data-testid="move-to-status-{otherStatus}"
												disabled={disabled || progressDisabled}
											>
												{#if allStatus.indexOf(otherStatus) <= allStatus.indexOf(status)}
													<IcRoundArrowBack />
												{:else}
													<IcRoundArrowForward />
												{/if}
												Move to
												<StatusTag status={otherStatus} label={statusSettings[otherStatus].label} />
											</MenuItem>
										{/each}
										<hr />
									</svelte:fragment>
								</MoveMenu>
							</svelte:fragment>
						</Task>
					</List>
				</section>
			{/each}
		</div>
	{/if}
</div>

<style lang="postcss">
	.container {
		border-radius: var(--radius-2);
		padding: var(--size-2);
		box-shadow: var(--shadow-3);
		background-color: var(--surface-1);
	}

	summary {
		padding: var(--size-1);
	}

	.task-cols,
	.tasks {
		padding-top: var(--size-2);
	}

	.task-col {
		min-width: 0;
		min-height: var(--size-3);
		border-radius: var(--radius-2);
	}

	.task-cols {
		display: grid;
		grid-template-columns: 1fr 1fr 1fr;
		gap: var(--size-2);

		& .task-col {
			padding: var(--size-2);
		}
	}

	.not-draggable {
		cursor: default;
	}
</style>
