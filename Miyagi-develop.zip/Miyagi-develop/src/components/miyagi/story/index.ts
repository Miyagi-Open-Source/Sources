export { default } from './story.svelte';
