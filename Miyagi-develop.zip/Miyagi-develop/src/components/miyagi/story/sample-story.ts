import content from '$components/tiptap/editor/editor-test-content';
import { awaitLoaded } from '$lib/handlers';
import type { Sprint } from '$types/sprint';
import type { Story } from '$types/story';
import type { Task } from '$types/task';
import sampleTask from '../task/sample-task';

const sampleStory: Story = {
	sprintId: '0',
	id: '0',
	localId: 0,
	sequence: 0,
	displayId: 1337,
	type: 'story',
	sprint: null as unknown as Sprint,
	status: 'backlog',
	title: 'Example Story Title',
	description: { ...content },
	// epic: 'Example Epic Title',
	points: 13,
	createdAt: '',
	createTask: async () => null as unknown as Task,
	async update() {
		return this;
	},
	delete: () => null,
	taskCount: 4,
	tasks: [
		{ ...sampleTask, localId: 0, id: '0', sequence: 0 },
		{ ...sampleTask, localId: 1, id: '1', sequence: 1 },
		{ ...sampleTask, localId: 2, id: '2', sequence: 2 },
		{ ...sampleTask, localId: 3, id: '3', sequence: 3 },
	],
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	[awaitLoaded]: () => null as any,
	addedToSprintAt: '',
} as unknown as Story;

export default sampleStory;
