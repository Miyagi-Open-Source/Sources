<script>
	import sampleStory from './sample-story';
	import Story from './story.svelte';
	export let Hst;
</script>

<Hst.Story title="Miyagi/Story/Story (Card)">
	<Story story={sampleStory} />
</Hst.Story>
