<script lang="ts">
	import StatusTag from '$components/status-tag';
	import Tag from '$components/tag';
	import { FORMAT } from '$lib/plural';
	import type { Story } from '$types/story';

	export let story: Pick<Story, 'points' | 'title' | 'displayId' | 'type' | 'id' | 'status'> & {
		tasks: unknown[];
	};
</script>

<div class="title" on:click on:keypress>
	<slot name="front" />
	<StatusTag el={story} />
	<h4 data-testid="story-title">
		{story.title}
	</h4>
	{#if story?.tasks?.length}
		<span class="num-tasks">
			{story?.tasks.length}
			{FORMAT.Task(story?.tasks.length)}
		</span>
	{/if}
	<span class="end">
		<Tag>{story.points}pts</Tag>
		<slot name="end" />
	</span>
</div>

<style>
	.num-tasks {
		color: var(--text-2);
		font-size: var(--font-size-0);
	}

	h4 {
		overflow: hidden;
		flex: 1;
		font-size: var(--font-size-2);
		font-weight: var(--font-weight-6);
		text-overflow: ellipsis;
		white-space: nowrap;
	}

	.title,
	.end {
		display: inline-flex;
		align-items: center;
		gap: var(--size-3);
	}

	.title {
		width: 100%;
	}

	.end {
		margin-left: auto;
	}
</style>
