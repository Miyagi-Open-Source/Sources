<script>
	import sampleStory from '../sample-story';
	import StoryForm from './story-form.svelte';
	export let Hst;
</script>

<Hst.Story title="Miyagi/Story/StoryForm">
	<StoryForm story={sampleStory} />
</Hst.Story>
