<script lang="ts">
	import Button from '$components/button';
	import IcDelete from '~icons/ic/round-delete-forever';
	import Editor from '$components/tiptap/editor';
	import Input from '$components/input';
	import type { Story } from '$types/story';
	import { createEventDispatcher, onMount } from 'svelte';
	import type { JSONContent } from '@tiptap/core';
	import IcRoundAdd from '~icons/ic/round-add';
	import { openDetails } from '$lib/stores/details';
	import { editingDisabled, focus } from '$lib/symbols';
	import { waitForTrue } from '$lib/helper';
	import { dialog } from '$components/dialog/dialog-function/dialog-function';

	const dispatch = createEventDispatcher<{ change: Partial<Story> }>();

	export let story: Story;
	export let disabled = false;

	const handleChange = (key: string) => (event: Event) => {
		let value: string | number = (event.target as HTMLInputElement).value;
		if ((event.target as HTMLInputElement).type === 'number') value = +value;

		dispatch('change', {
			[key]: value,
		});
	};

	$: content = story.description as JSONContent;

	let titleEl: HTMLInputElement;

	onMount(() => {
		story[focus] = () => {
			story[editingDisabled] = false;
			$openDetails.story[story.id] = true;
			setTimeout(() => {
				titleEl.focus();
				titleEl.scrollIntoView({ block: 'center', behavior: 'smooth' });
				titleEl.select();
			}, 0);
		};
	});
</script>

<form on:submit|preventDefault>
	<Input
		value={story.title}
		on:change={handleChange('title')}
		data-testid="story-title-form"
		{disabled}
		bind:elementRef={titleEl}>Title</Input
	>
	<Editor
		{content}
		on:change={({ detail: value }) => dispatch('change', { description: value })}
		data-testid="story-description-form"
		{disabled}
		title="Description / Acceptance (Criteria)"
	>
		Description
	</Editor>
	<div class="row">
		<!-- <Input value={story.epic}>Epic</Input> -->
		<Input type="number" value={story.points} on:change={handleChange('points')} {disabled} min="0" max="1000"
			>Estimation</Input
		>
	</div>
	<Button
		aria-label="Delete Story"
		variant="hover-warn"
		--width="fit-content"
		--margin="0 0 0 auto"
		on:click={async (e) => {
			if (e.ctrlKey) return story.delete();

			const [deleteConfirmed] = await dialog('Delete Story', {
				message: 'Are you sure you want to delete this story?',
			});
			if (deleteConfirmed) story.delete();
		}}
		{disabled}
	>
		<IcDelete />
	</Button>
	<div class="add-task-container">
		<Button
			on:click={async () => {
				const task = await story.createTask({
					title: 'New Task',
					sequence: story.tasks.reduce((acc, cur) => Math.min(cur.sequence, acc), 0) - 1,
				});
				await waitForTrue(() => task[focus]);

				task[focus]?.();
			}}
			data-testid="create-task"
			{disabled}
		>
			<IcRoundAdd /> Add Task
		</Button>
	</div>
</form>

<style lang="postcss">
	form {
		padding: var(--size-2);
	}

	.row {
		display: flex;
		gap: var(--size-4);
	}

	.add-task-container {
		display: flex;
		justify-content: flex-end;
		margin-block: var(--size-2);
	}
</style>
