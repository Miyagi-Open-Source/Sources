import { cleanup, render } from '@testing-library/svelte';
import { beforeEach, describe, test } from 'vitest';
import sampleStory from '../sample-story';
import StoryForm from './story-form.svelte';

beforeEach(() => {
	cleanup();
});

describe('Component: StoryForm', () => {
	test('can render', () => {
		render(StoryForm, { story: sampleStory });
	});
});
