The StoryForm component displays the data of a Story in a form and allows edits to be made to it.
