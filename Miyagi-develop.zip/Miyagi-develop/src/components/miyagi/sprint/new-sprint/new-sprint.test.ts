import { cleanup, render } from '@testing-library/svelte';
import { beforeEach, describe, test } from 'vitest';
import NewSprint from './new-sprint.svelte';

beforeEach(() => {
	cleanup();
});

describe('Component: NewSprint', () => {
	test('can render', () => {
		render(NewSprint);
	});
});
