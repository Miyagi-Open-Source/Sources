<script lang="ts">
	import List from '$components/list';
	import Story from '$components/miyagi/story';
	import Tag from '$components/tag';
	import type { Project } from '$types/project';
	import type { Story as StoryType } from '$types/story';
	import IcSprint from '~icons/ic/round-directions-run';
	import IcPlus from '~icons/ic/round-plus';
	import IcBacklog from '~icons/ic/round-menu';
	import Button from '$components/button/button.svelte';
	import { focus } from '$lib/symbols';
	import { waitForTrue } from '$lib/helper';

	export let project: Project;
	export let disabled = false;
	let empty = [] as StoryType[];
</script>

<div class="container">
	<div class="head">
		<div class="front">
			<slot name="front" />
			<Tag>
				<IcBacklog />
				SP-NEW</Tag
			>
			<h3 data-testid="title">New Sprint</h3>
		</div>
		<Button
			{disabled}
			class="add-sprint"
			on:click={async () => {
				const sprint = await project.createSprint({ name: 'New Sprint' });
				await waitForTrue(() => sprint[focus]);
				sprint[focus]?.();
			}}><IcPlus /> Add Empty Sprint</Button
		>
	</div>
	<div class="story-list">
		<List
			{disabled}
			--min-height="122px"
			items={empty}
			type="story"
			name={'new-sprint'}
			on:droppedIntoZone={async ({ detail: { items } }) => {
				const sprint = await project.createSprint({ name: 'New Sprint' });
				items[0].update({ sprintId: sprint.id }); // Todo combine to one?
				empty = [];
			}}
			data-testid="list-new-sprint"
			let:item
		>
			<div
				slot="empty"
				class="empty"
				on:mousedown|stopPropagation
				on:touchstart|stopPropagation
				on:keydown|stopPropagation
			>
				<span><IcSprint /></span>
				<p>Create a new Sprint by dropping a story here.</p>
			</div>
			<Story story={item} />
		</List>
	</div>
</div>

<style lang="postcss">
	.container {
		border-radius: var(--radius-2);
		padding: var(--size-2);
		background-color: var(--surface-2);
	}

	.head {
		display: flex;
		justify-content: space-between;
	}

	.front {
		display: flex;
		align-items: center;
		gap: var(--size-3);
	}

	h3 {
		font-size: var(--font-size-3);
		font-weight: var(--font-weight-6);
	}

	.story-list {
		padding-top: var(--size-2);
	}

	.empty {
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: var(--size-3);
		border: var(--surface-4) dashed 1px;
		border-radius: var(--radius-2);
		padding: var(--size-4);
		color: var(--text-2);
		cursor: default;

		& span {
			font-size: var(--font-size-5);
		}
	}
</style>
