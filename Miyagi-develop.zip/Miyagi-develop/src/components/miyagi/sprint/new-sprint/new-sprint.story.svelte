<script>
	import NewSprint from './new-sprint.svelte';
	export let Hst;
</script>

<Hst.Story title="Miyagi/Sprint/NewSprint">
	<NewSprint />
</Hst.Story>
