NewSprint component is a template for a new sprint that stores can be dragged into to create a new sprint.
