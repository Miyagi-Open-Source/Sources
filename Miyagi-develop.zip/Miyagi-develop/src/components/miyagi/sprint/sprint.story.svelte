<script>
	import sampleSprint from './sample-sprint';
	import Sprint from './sprint.svelte';
	export let Hst;
</script>

<Hst.Story title="Miyagi/Sprint/Sprint (Card)">
	<Sprint sprint={sampleSprint} />
</Hst.Story>
