import content from '$components/tiptap/editor/editor-test-content';
import { awaitLoaded } from '$lib/handlers';
import type { Sprint } from '$types/sprint';
import type { Story } from '$types/story';
import sampleStory from '../story/sample-story';

const sampleSprint: Sprint = {
	isActive: false,
	id: 0,
	localId: 0,
	displayId: 1337,
	type: 'sprint',
	createdAt: '2022-05-06T00:41:26+00:00',
	endDate: '',
	goal: { ...content },
	isProjectBacklog: false,
	isRunning: false,
	name: 'Erster Sprint :)',
	projectId: 1,
	startDate: '2022-05-06T00:41:26+00:00',
	duration: 7,
	createStory: async () => null as unknown as Story,
	update() {
		return this;
	},
	delete: () => null,
	end: () => null,
	project: null as unknown as Sprint['project'],
	stories: [
		{ ...sampleStory, localId: 0, id: 0, sequence: 0 },
		{ ...sampleStory, localId: 1, id: 1, sequence: 1 },
		{ ...sampleStory, localId: 2, id: 2, sequence: 2 },
		{ ...sampleStory, localId: 3, id: 3, sequence: 3 },
	],
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	[awaitLoaded]: () => null as any,
	start: () => null,
} as unknown as Sprint;

export default sampleSprint;
