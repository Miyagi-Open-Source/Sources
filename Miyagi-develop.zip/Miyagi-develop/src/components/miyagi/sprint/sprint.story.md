Sprint component is a card that displays a story.
