<script>
	import { hstEvent } from 'histoire/client';

	import sampleSprint from '../sample-sprint';
	import SprintForm from './sprint-form.svelte';
	export let Hst;

	const handleChange = (e) => hstEvent('change', e);
</script>

<Hst.Story
	title="Miyagi/Sprint/SprintForm"
	argTypes={{
		'on:change': { action: 'on:change' },
	}}
>
	<SprintForm sprint={sampleSprint} on:change={handleChange} />
</Hst.Story>
