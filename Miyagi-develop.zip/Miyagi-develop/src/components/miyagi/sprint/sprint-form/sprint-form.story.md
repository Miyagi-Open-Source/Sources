The SprintForm component displays the data of a Sprint in a form and allows edits to be made to it.
