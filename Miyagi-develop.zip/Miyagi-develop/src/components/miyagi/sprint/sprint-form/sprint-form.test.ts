import { cleanup, render } from '@testing-library/svelte';
import { beforeEach, describe, test } from 'vitest';
import sampleSprint from '../sample-sprint';
import SprintForm from './sprint-form.svelte';

beforeEach(() => {
	cleanup();
});

describe('Component: SprintForm', () => {
	test('can render', () => {
		render(SprintForm, { sprint: sampleSprint });
	});
});
