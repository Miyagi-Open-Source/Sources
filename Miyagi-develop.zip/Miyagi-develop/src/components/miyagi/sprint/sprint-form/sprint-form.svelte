<script lang="ts">
	import Button from '$components/button';
	import IcDelete from '~icons/ic/round-delete-forever';
	import Editor from '$components/tiptap/editor';
	import Input from '$components/input';
	import type { Sprint } from '$types/sprint';
	import { addDays } from 'date-fns';
	import { createEventDispatcher, onMount } from 'svelte';
	import { editingDisabled, focus } from '$lib/symbols';
	import { openDetails } from '$lib/stores/details';
	import type { JSONContent } from '@tiptap/core';
	import { dialog } from '$components/dialog/dialog-function/dialog-function';
	import { FORMAT } from '$lib/plural';

	const dispatch = createEventDispatcher<{ change: Partial<Sprint> }>();

	export let sprint: Sprint;
	export let disabled = false;

	const handleChange = (key: string) => (event: Event) => {
		dispatch('change', {
			[key]: (event.target as HTMLInputElement).value,
		});
	};

	const handleDateChange = (key: string) => (event: Event) => {
		const newDate = (event.target as HTMLInputElement).value;
		dispatch('change', {
			[key]: new Date(newDate).toISOString(),
		});
	};

	$: content = sprint.goal as JSONContent;

	let titleEl: HTMLInputElement;
	onMount(() => {
		sprint[focus] = () => {
			sprint[editingDisabled] = false;
			$openDetails.sprint[sprint.id] = true;
			setTimeout(() => {
				titleEl.focus();
				titleEl.scrollIntoView({ block: 'center', behavior: 'smooth' });
				titleEl.select();
			}, 0);
		};
	});

	const deleteActiveSprint = async () => {
		const hasStories = sprint.stories.length > 0;
		const hasFutureSprints = sprint.project.futureSprints.length > 0;

		if (!hasStories) {
			const [confirmed] = await dialog('Delete Current Sprint', {
				message: 'Are you sure you want to delete this sprint, it has no stories?',
				confirmLabel: 'Delete',
				cancelLabel: 'Cancel',
			});
			if (!confirmed) return;
		} else {
			const [selectedSprint, deleteStories] = await dialog(
				'Delete Current Sprint',
				[
					{
						label: 'Select next Sprint:',
						input: 'sprint',
						sprints: [...sprint.project.futureSprints, ...sprint.project.backlogSprint],
						value: sprint.project.backlogSprint[0],
					},
					{
						label: 'Delete Stories',
						input: 'boolean',
						value: false,
					},
				] as const,
				{
					message: `This Sprint has ${sprint.stories.length} ${FORMAT.Story(
						sprint.stories.length
					)}, what should happen to ${sprint.stories.length === 1 ? 'it' : 'them'}?`,
					confirmLabel: 'Delete',
				}
			);
			if (deleteStories === null) return;
			if (!deleteStories) sprint.stories.forEach((story) => story.update({ sprintId: selectedSprint.id }));
		}

		sprint.delete();
		if (hasFutureSprints) {
			sprint.project.futureSprints[0].update({ isActive: true });
		} else {
			sprint.project.createSprint({
				name: 'new Sprint',
				isActive: true,
			});
		}
	};
</script>

<form on:submit|preventDefault>
	<Input
		value={sprint.name}
		on:change={handleChange('name')}
		data-testid="sprint-title-form"
		{disabled}
		bind:elementRef={titleEl}>Title</Input
	>
	<Editor {content} on:change={({ detail: value }) => dispatch('change', { goal: value })} {disabled}>Goal</Editor>
	<div class="row">
		<Input {disabled} type="number" min={1} value={sprint.duration} on:change={handleChange('duration')}>
			Planned duration in days
		</Input>
		<Input
			disabled={sprint.isRunning || disabled}
			type="date"
			value={sprint.startDate ? new Date(sprint.startDate).toISOString().substring(0, 10) : ''}
			on:change={handleDateChange('startDate')}
		>
			Start Date
		</Input>
		{#if sprint.endDate}
			<!-- using toLocaleString('sv-SE') to convert to type="datetime-local" format -->
			<!-- Sweden (sv-SE) uses ISO Date Time format -->
			<Input type="datetime-local" value={new Date(sprint.endDate).toLocaleString('sv-SE')} disabled>End Date</Input>
		{:else if sprint.startDate && sprint.duration}
			<Input
				type="date"
				value={addDays(new Date(sprint.startDate), sprint.duration).toISOString().substring(0, 10)}
				disabled
			>
				End Date
			</Input>
		{:else}
			<Input type="date" disabled>End Date</Input>
		{/if}
	</div>
	{#if !(sprint.isRunning || sprint.isActive)}
		<Button
			variant="hover-warn"
			--width="fit-content"
			--margin="0 0 0 auto"
			on:click={async () => {
				if (sprint.stories.length === 0) {
					const [confirmed] = await dialog('Delete Sprint', {
						message: 'Are you sure you want to delete this sprint, it has no stories?',
						confirmLabel: 'Delete',
						cancelLabel: 'Cancel',
					});
					if (confirmed) sprint.delete();
					return;
				}

				const [moveToBacklog] = await dialog('Delete Sprint', {
					message: 'This Sprint has Stories, what should happen to them?',
					confirmLabel: 'Move Stories to Backlog',
					cancelLabel: 'Delete Stories',
				});

				const sprintId = sprint.project.backlogSprint[0].id;
				if (moveToBacklog === null) return;
				if (moveToBacklog === true) sprint.stories.forEach((story) => story.update({ sprintId }));
				sprint.delete();
			}}
			{disabled}
		>
			<svelte:fragment><IcDelete /></svelte:fragment>
		</Button>
	{:else if !sprint.isRunning && sprint.isActive}
		<Button variant="hover-warn" --width="fit-content" --margin="0 0 0 auto" on:click={deleteActiveSprint} {disabled}>
			<svelte:fragment><IcDelete /></svelte:fragment>
		</Button>
	{/if}
</form>

<style lang="postcss">
	form {
		padding: var(--size-2);
	}

	.row {
		display: flex;
		gap: var(--size-4);
	}
</style>
