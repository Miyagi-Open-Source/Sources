<script lang="ts">
	import StatusTag from '$components/status-tag';
	import Tag from '$components/tag';
	import { FORMAT } from '$lib/plural';
	import type { Sprint } from '$types/sprint';

	export let hidePoints = false;
	export let titleTag = 'h3';
	// @ts-ignore
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	export let sprint: any;

	type $$Props =
		| {
				sprint: Pick<Sprint, 'name' | 'isRunning' | 'endDate' | 'displayId' | 'type' | 'id' | 'stories'> | null;
				hidePoints?: false;
				titleTag?: string;
		  }
		| {
				sprint:
					| (Pick<Sprint, 'name' | 'isRunning' | 'endDate' | 'displayId' | 'type' | 'id'> & {
							stories: { length: number };
					  })
					| null;
				hidePoints: true;
				titleTag?: string;
		  };
</script>

<div class="title" on:click on:keypress>
	<div class="front">
		<slot name="front" />
		<StatusTag el={sprint} />
		<svelte:element this={titleTag} class="title" data-testid="sprint?-title">
			{sprint?.name}
		</svelte:element>
	</div>
	<span class="end">
		<span class="num-tasks">
			{sprint?.stories?.length}
			{FORMAT.Story(sprint?.stories?.length)}
		</span>
		{#if !hidePoints}
			<Tag>{sprint?.stories?.reduce((acc, p) => p.points + acc, 0)}pts</Tag>
		{/if}
		<slot name="end" />
	</span>
</div>

<style>
	div {
		overflow: hidden;
		display: flex;
		align-items: center;
		gap: var(--size-3);
		min-width: min-content;
	}

	.title {
		overflow: hidden;
		flex: 1;
		width: 100%;
		font-size: var(--font-size-3);
		font-weight: var(--font-weight-6);
		text-overflow: ellipsis;
		white-space: nowrap;
	}

	.num-tasks {
		white-space: nowrap;
		font-size: var(--font-size-1);
	}

	.title,
	.end {
		display: inline-flex;
		align-items: center;
		gap: var(--size-3);
	}

	.end {
		margin-left: auto;
	}
</style>
