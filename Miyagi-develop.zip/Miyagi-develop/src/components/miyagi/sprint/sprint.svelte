<script lang="ts">
	import List from '$components/list';
	import MoveMenu from '$components/list/move-menu';
	import MenuItem from '$components/menu/menu-item';
	import { openDetails } from '$lib/stores/details';
	import type { Sprint } from '$types/sprint';
	import IcRoundExpandMore from '~icons/ic/round-expand-more';
	import Story from '../story';
	import SprintForm from './sprint-form';
	import IcBacklog from '~icons/ic/round-menu';
	import IcSprint from '~icons/ic/round-directions-run';
	import SprintHead from './sprint-head.svelte';
	import { editingDisabled } from '$lib/symbols';

	export let sprint: Sprint;
	$: project = sprint.project;

	export let testId = 'current-sprint';
	export let disabled = false;
	$: _disabled = sprint[editingDisabled] || disabled;
</script>

<div class="container" data-testid={testId}>
	<details bind:open={$openDetails.sprint[sprint.id]}>
		<summary>
			<SprintHead {sprint}>
				<slot name="front" slot="front" />
				<span slot="end" class="expand-indicator" class:open={$openDetails.sprint[sprint.id]}>
					<IcRoundExpandMore />
				</span>
			</SprintHead>
		</summary>
		<SprintForm bind:sprint on:change={({ detail: patch }) => sprint.update(patch)} disabled={_disabled} />
	</details>
	<div class="story-list">
		<List
			items={sprint.stories}
			let:item
			let:i
			type="story"
			name="sprint-stories"
			on:droppedIntoZone={({ detail: { items, info } }) =>
				items
					.find((item) => item.localId === info.id)
					?.update({
						sprintId: sprint.id,
					})}
			data-testid="list-{testId}"
			disabled={_disabled}
		>
			<Story story={item} disabled={_disabled}>
				<svelte:fragment slot="front">
					<MoveMenu items={sprint.stories} {i} disabled={_disabled}>
						<svelte:fragment slot="top">
							{#if project.currentSprint[0].id !== sprint.id}
								<MenuItem
									disabled={_disabled}
									on:click={() =>
										item.update({
											sprintId: project.currentSprint[0].id,
											sequence: project.currentSprint[0].stories.length,
										})}
									data-testid="move-to-current-sprint"
								>
									<IcSprint /> Move to current Sprint
								</MenuItem>
								<hr />
							{/if}
						</svelte:fragment>
						<svelte:fragment slot="bottom">
							<hr />
							<MenuItem
								disabled={_disabled}
								on:click={() =>
									item.update({
										sprintId: project.backlogSprint[0].id,
										sequence: project.backlogSprint[0].stories.length,
									})}
							>
								<IcBacklog /> Move to Product Backlog
							</MenuItem>
						</svelte:fragment>
					</MoveMenu>
				</svelte:fragment>
			</Story>
		</List>
	</div>
</div>

<style lang="postcss">
	.container {
		border-radius: var(--radius-2);
		padding: var(--size-3);
		background-color: var(--surface-2);
	}

	summary {
		padding-bottom: var(--size-2);
	}

	.story-list {
		padding-top: var(--size-2);
	}
</style>
