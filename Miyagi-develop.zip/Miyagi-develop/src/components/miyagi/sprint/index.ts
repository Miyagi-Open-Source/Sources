export { default } from './sprint.svelte';
