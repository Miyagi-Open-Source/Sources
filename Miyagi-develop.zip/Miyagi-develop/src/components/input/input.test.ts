import { cleanup, render } from '@testing-library/svelte';
import { beforeEach, describe, expect, test } from 'vitest';

import Input from './input.svelte';

beforeEach(() => {
	cleanup();
});

describe('Component: Input', () => {
	test('can render', () => {
		render(Input);
	});

	test('can render label', () => {
		const label = 'Hello World';
		const { getByText } = render(Input, { label });
		expect(getByText(label)).toBeDefined();
	});
});
