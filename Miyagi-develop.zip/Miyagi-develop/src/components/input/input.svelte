<script context="module" lang="ts">
	export type InputVariants = 'regular' | 'inline';
</script>

<script lang="ts">
	import type { ActionArray } from '$lib/actions/types';
	import { useActions } from '$lib/actions/use-actions';
	import { randomUUID } from '$lib/crypto';
	import type Children from '$types/children';
	import { createEventDispatcher } from 'svelte';
	const dispatch = createEventDispatcher();

	export let label: Children = '';
	export let value: string | number | null = null;
	export let variant: InputVariants = 'regular';
	export let type = 'text';
	export let minLength = 0;
	export let maxLength = type === 'text' ? 100 : 10_000;
	export let rows = 4;
	export let disabled = false;
	export let required = false;
	export let pattern = '';
	export let hideStar = false;
	export let placeholder = '';
	export let name = '';
	export let autocomplete = '';
	export let use: ActionArray = [];
	export let elementRef: HTMLInputElement | HTMLTextAreaElement | undefined = undefined;

	let inputId = randomUUID();

	/**
	 * Handle Input Binding
	 * Based on https://stackoverflow.com/a/57393751/8081154
	 */
	const handleInput = (e: Event) => {
		// handle types
		value = ['number'].includes(type) ? +(e.target as HTMLInputElement).value : (e.target as HTMLInputElement).value;
		(e.target as HTMLInputElement).value = value + '';
		dispatch('input', e);
	};
</script>

<div class={variant}>
	{#if $$slots.default || label || (required && !hideStar)}
		<label for={inputId}>
			<slot>{label}</slot>
			{#if required && !hideStar}
				*
			{/if}
		</label>
	{/if}
	<svelte:element
		this={type === 'textarea' ? 'textarea' : 'input'}
		class="input {variant}"
		{type}
		bind:this={elementRef}
		id={inputId}
		{value}
		on:input={handleInput}
		rows={type === 'textarea' ? rows : null}
		disabled={disabled || null}
		required={required || null}
		placeholder={placeholder || null}
		name={name || null}
		pattern={pattern || null}
		autocomplete={autocomplete || null}
		{...$$restProps}
		minlength={minLength || null}
		maxlength={maxLength}
		on:click
		on:focus
		on:blur
		on:change
		on:dblclick
		on:keyup
		use:useActions={use}
	/>
</div>

<style lang="postcss">
	div.regular {
		display: inline-block;

		/* flex: auto; */
		gap: var(--size-1);
		margin: var(--margin, 0);
	}

	.input {
		width: 100%;
		border: 1px solid var(--gray-6);
		border-radius: var(--size-1);
		padding: var(--size-2) var(--size-3);
		background: var(--app-background);
		resize: vertical;

		&:disabled {
			background-color: var(--surface-2);
			color: var(--gray-5);
			cursor: default;
		}

		&:invalid {
			border-color: var(--red-5) solid 1px;
		}

		&.inline {
			border: none;
			padding: 0;
			box-shadow: none;
			background: none;
			color: inherit;
			font-size: inherit;
			font-weight: inherit;
			text-align: inherit;
			max-inline-size: unset;
		}

		&.inline:focus {
			outline: var(--blue-5) solid 1px;
			cursor: text;
		}
	}
</style>
