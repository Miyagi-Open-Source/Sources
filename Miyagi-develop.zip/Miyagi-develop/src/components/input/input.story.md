Input component is used to let the user input information.
