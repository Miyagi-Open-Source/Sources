<script>
	import Input from '.';
	export let Hst;

	let label = 'Label';
	let disabled = false;
	let required = false;
	let type = 'text';
	let placeholder = 'Placeholder';

	const typeOptions = ['text', 'textarea', 'password', 'email', 'number', 'tel'];
	const source = `<Input
	required
	name="email"
	autocomplete="email"
	bind:value={email}
	disabled={loading}
	placeholder="lenze@clancy.digital"
>
	Email
</Input>`;
</script>

<Hst.Story title="Input" {source}>
	<svelte:fragment slot="controls">
		<Hst.Text bind:value={label} title="label" />
		<Hst.Checkbox bind:value={disabled} title="disabled" />
		<Hst.Checkbox bind:value={required} title="required" />
		<Hst.Select bind:value={type} title="'My really long label'" options={typeOptions} />
		<Hst.Text bind:value={placeholder} title="placeholder" />
	</svelte:fragment>
	<Input {disabled} {required} {type} {placeholder}>
		{label}
	</Input>
</Hst.Story>
