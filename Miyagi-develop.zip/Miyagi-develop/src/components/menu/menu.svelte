<script context="module" lang="ts">
	export const key: unique symbol = Symbol('menuContext');
</script>

<script lang="ts">
	import Button from '$components/button';
	import type { ButtonVariants } from '$components/button/button.svelte';
	import clickOutside from '$lib/actions/click-outside';
	import { handleOnFocus } from '$lib/actions/handle-on-focus';
	import { randomUUID } from '$lib/crypto';
	import { getFocusable } from '$lib/focus';
	import type Children from '$types/children';
	import { flip, type Placement } from '@floating-ui/dom';
	import { createEventDispatcher, setContext, tick } from 'svelte';
	import { createFloatingActions } from 'svelte-floating-ui';
	import { fade, slide } from 'svelte/transition';
	const dispatch = createEventDispatcher();

	export let label: Children = '';
	export let content: Children = '';
	export let disabled = false;
	export let open = false;
	export let variant: ButtonVariants = 'regular';
	export let triggerTestId = '';
	export let placement: Placement = 'bottom-start';

	export let triggerId = randomUUID();
	const menuId = randomUUID();
	let menuElement: HTMLElement;
	let triggerElement: HTMLElement;

	const [floatingRef, floatingContent] = createFloatingActions({
		placement,
		middleware: [flip()],
	});

	function toggleMenu() {
		open = !open;
	}

	setContext(key, {
		toggleMenu,
	});

	const firstItemKeys = ['ArrowDown', ' ' /* Space */, 'Enter'];
	const lastItemKeys = ['ArrowUp'];
	async function openWithKbd(event: KeyboardEvent): Promise<void> {
		if (event.key === 'Tab') return;
		event.preventDefault();
		if ([...firstItemKeys, ...lastItemKeys].includes(event.key)) {
			open = true;
			await tick(); /* Wait for Svelte to Render Menu... */
			const focusable = getFocusable(menuElement);
			const index = firstItemKeys.includes(event.key) ? 0 : focusable.length - 1;
			focusable[index].focus();
		}
	}

	const moveKeys = ['ArrowDown', 'ArrowUp'];
	function handleNavigationWithKbd(event: KeyboardEvent) {
		const focusable = getFocusable(menuElement);
		if (moveKeys.includes(event.key)) {
			const currentFocusIndex = focusable.indexOf(document.activeElement as HTMLElement);
			// If moving up or down
			const direction = event.key === moveKeys[0] ? 1 : -1;
			const index = (currentFocusIndex + direction + focusable.length) % focusable.length;
			focusable[index].focus();
		} else if (event.key === 'End') {
			focusable[focusable.length - 1].focus();
		} else if (event.key === 'Home') {
			focusable[0].focus();
		} else if (['Tab', 'Escape'].includes(event.key)) {
			open = false;
			triggerElement.focus();
		}
	}

	// Workaround for 'handleOnFocus(handleNavigationWithKbd)' is not defined
	const focusWithKbd = handleOnFocus(handleNavigationWithKbd);
</script>

<Button
	bind:elementRef={triggerElement}
	on:click={(e) => {
		dispatch('click', e);
		toggleMenu();
	}}
	on:dblClick
	on:contextmenu
	{variant}
	id={triggerId}
	{disabled}
	aria-haspopup="menu"
	aria-expanded={open}
	aria-controls={menuId}
	use={[floatingRef, handleOnFocus(openWithKbd)]}
	data-testid={triggerTestId}
	bind:forceActive={open}
	{...$$restProps}
>
	<slot name="label">{label}</slot>
</Button>

{#if open}
	<ul
		in:slide={{ duration: 200 }}
		out:fade={{ duration: 200 }}
		use:floatingContent
		bind:this={menuElement}
		id={menuId}
		aria-labelledby={triggerId}
		{...$$restProps}
		use:focusWithKbd
		use:clickOutside={{
			enabled: open,
			func: () => {
				open = false;
			},
		}}
	>
		<slot>{content}</slot>
	</ul>
{/if}

<style lang="postcss">
	ul {
		position: absolute;
		z-index: 2;
		display: flex;
		flex-direction: column;
		gap: var(--size-1);
		width: fit-content;
		height: fit-content;
		border-radius: var(--size-1);
		padding: 0;
		padding-block: var(--size-1);
		box-shadow: var(--shadow-4);
		background-color: var(--surface-2);
	}
</style>
