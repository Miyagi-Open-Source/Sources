<script>
	import MenuItem from './menu-item';
	import Menu from './menu.svelte';
</script>

<h1>ONLY TO BE USED IN UNIT TESTS</h1>

<Menu label="Open Menu">
	<MenuItem data-testid="option1">Option 1</MenuItem>
	<MenuItem data-testid="option2">Option 2</MenuItem>
</Menu>
