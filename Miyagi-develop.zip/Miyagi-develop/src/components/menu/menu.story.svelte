<script>
	import { hstEvent } from 'histoire/client';
	import IcDown from '~icons/ic/round-arrow-downward';
	import IcUp from '~icons/ic/round-arrow-upward';
	import IcMore from '~icons/ic/round-more-vert';
	import IcRocketLaunch from '~icons/ic/round-rocket-launch';
	import IcBottom from '~icons/ic/round-vertical-align-bottom';
	import IcTop from '~icons/ic/round-vertical-align-top';
	import MenuItem from './menu-item';
	import Menu from './menu.svelte';

	export let Hst;

	let label = 'More Options';

	const source = `<Menu>
	<svelte:fragment slot="label">
		<IcMore /> More Options
	</svelte:fragment>
	<MenuItem on:click={sendToTop}><IcTop />Send to top</MenuItem>
	<MenuItem stayOnSelect on:click={moveUp}><IcUp />Move up</MenuItem>
	<MenuItem disabled on:click={launchRockets}><IcRocketLaunch />Launch rockets</MenuItem>
	<MenuItem stayOnSelect on:click={moveDown}><IcDown />Move down</MenuItem>
	<MenuItem on:click={sendToBottom}><IcBottom />Send to bottom</MenuItem>
</Menu>`;
	const handleClick = (e) => hstEvent('click', e);
</script>

<Hst.Story title="Menu" {source}>
	<svelte:fragment slot="controls">
		<Hst.Text bind:value={label} title="label" />
	</svelte:fragment>
	<Menu on:click={handleClick}>
		<svelte:fragment slot="label">
			<IcMore />
			{label}
		</svelte:fragment>
		<MenuItem on:click={handleClick}><IcTop />Send to top</MenuItem>
		<MenuItem stayOnSelect on:click={handleClick}><IcUp />Move up</MenuItem>
		<MenuItem on:click={handleClick} disabled><IcRocketLaunch />Launch rockets</MenuItem>
		<MenuItem stayOnSelect on:click={handleClick}><IcDown />Move down</MenuItem>
		<MenuItem on:click={handleClick}><IcBottom />Send to bottom</MenuItem>
	</Menu>
</Hst.Story>
