export { default } from './menu.svelte';
