<script lang="ts">
	import type Children from '$types/children';
	import { createEventDispatcher, getContext } from 'svelte';
	import { key } from '../menu.svelte';
	const dispatch = createEventDispatcher();

	const { toggleMenu } = getContext<{ toggleMenu: () => void }>(key) || {
		toggleMenu: () => console.warn('toggleMenu called w/o parent context (ok for MenuItem test)'),
	};

	export let stayOnSelect = false;
	export let label: Children = '';
	export let href = '';
	export let disabled = false;
	export let external = false;
	export let selected = false;
	export let tabindex = -1;

	function handleClick(e: MouseEvent) {
		dispatch('click', e);
		if (!stayOnSelect) toggleMenu();
	}
</script>

<li role="presentation">
	<svelte:element
		this={href ? 'a' : 'button'}
		role="menuitem"
		{tabindex}
		disabled={disabled || null}
		href={href || null}
		rel={external ? 'nofollow noopener noreferrer' : null}
		target={external ? '_blank' : null}
		{...$$restProps}
		class="btn"
		class:selected
		on:click={handleClick}
		><slot>{label}</slot>
	</svelte:element>
</li>

<style lang="postcss">
	li {
		display: contents;
	}

	.btn {
		display: inline-flex;
		flex-direction: row;
		align-items: center;
		gap: var(--size-2);
		margin: 0;
		padding-block: var(--size-1);
		padding-inline: var(--size-3);
		background-color: transparent;
		color: var(--text-1);
		text-decoration: none;
		cursor: pointer;
		text-align: start;
		transition-property: box-shadow, filter;
		transition-duration: 0.2s;
		transition-timing-function: var(--ease-out-1);

		&:disabled {
			color: var(--gray-5);
			cursor: default;
		}

		&:hover:not(:disabled),
		&:active:not(:disabled) {
			background-color: var(--surface-3);
		}
	}

	.selected {
		background-color: var(--surface-3);
		font-weight: var(--font-weight-6);
	}
</style>
