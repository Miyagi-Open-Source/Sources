MenuItem component is used for actions in a Menu.

It's only meant to be used with the Menu component: Check out the [Menu docs](/story/src-components-menu-menu-story-svelte?variantId=_default) for more info.
