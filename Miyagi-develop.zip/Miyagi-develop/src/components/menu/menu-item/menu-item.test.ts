import { cleanup, render } from '@testing-library/svelte';
import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest';
import MenuItem from './menu-item.svelte';

beforeEach(cleanup);
afterEach(() => {
	vi.resetAllMocks();
});

describe('Component: MenuItem', () => {
	test('render', () => {
		render(MenuItem);
	});

	test('render label', () => {
		const label = 'Hello World';
		const { getByText } = render(MenuItem, { label });
		expect(getByText(label)).toBeDefined();
	});

	test('forward click event', () => {
		const mock = vi.fn();
		const { getByRole, component } = render(MenuItem);
		component.$on('click', mock);
		getByRole('menuitem').click();
		expect(mock).toHaveBeenCalledOnce();
	});

	test("don't forward click event when disabled", () => {
		const mock = vi.fn();
		const { getByRole, component } = render(MenuItem, { disabled: true });
		component.$on('click', mock);
		getByRole('menuitem').click();
		expect(mock).not.toHaveBeenCalled();
	});

	test('render as link', () => {
		const { getByRole } = render(MenuItem, {
			href: 'https://clancy.digital/',
		});
		expect(getByRole('menuitem').tagName).toBe('A');
	});
});
