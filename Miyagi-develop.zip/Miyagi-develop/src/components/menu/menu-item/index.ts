export { default } from './menu-item.svelte';
