<script>
	import { hstEvent } from 'histoire/client';
	import IcRocketLaunch from '~icons/ic/round-rocket-launch';
	import MenuItem from '.';
	export let Hst;

	let label = 'Launch rockets';
	let disabled = false;
	let href = '';
	let external = false;
	let stayOnSelect = false;

	const source = `<MenuItem
	disabled={invalid}
	stayOnSelect={true}
	on:click={handleClick}
>
	<IcRocketLaunch />{label}
</MenuItem>`;
	const handleClick = (e) => hstEvent('click', e);
</script>

<Hst.Story title="MenuItem" {source}>
	<svelte:fragment slot="controls">
		<Hst.Text bind:value={label} title="label" />
		<Hst.Checkbox bind:value={disabled} title="disabled" />
		<Hst.Text bind:value={href} title="href" />
		<Hst.Checkbox bind:value={external} title="external" />
		<Hst.Checkbox bind:value={stayOnSelect} title="stayOnSelect" />
	</svelte:fragment>
	<MenuItem {disabled} {href} {external} {stayOnSelect} on:click={handleClick}><IcRocketLaunch />{label}</MenuItem>
</Hst.Story>
