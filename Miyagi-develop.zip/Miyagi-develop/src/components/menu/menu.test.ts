import { act, cleanup, render } from '@testing-library/svelte';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, test, vi } from 'vitest';
import MenuTestHelper from './menu-test-helper.svelte';
import Menu from './menu.svelte';

beforeEach(() => {
	cleanup();
});

describe('Component: Menu', () => {
	test('render', () => {
		render(Menu);
	});

	test('render label', () => {
		const label = 'Open Menu';
		const { getByText } = render(Menu, { label });
		expect(getByText(label)).toBeDefined();
	});

	test('forward click event', () => {
		const mock = vi.fn();
		const { getByRole, component } = render(Menu);
		component.$on('click', mock);
		getByRole('button').click();
		expect(mock).toHaveBeenCalledOnce();
	});

	test('conditionally render content', async () => {
		const content = 'Hello World';
		const { getByText, queryByText, getByRole } = render(Menu, { content });
		expect(queryByText(content)).toBeNull();
		getByRole('button').click();
		await act();
		expect(getByText(content)).toBeDefined();
	});

	test('keyboard navigation', async () => {
		const user = userEvent.setup();
		const { getByTestId, getByRole } = render(MenuTestHelper);

		const menuTrigger = getByRole('button');

		menuTrigger.focus();
		await user.keyboard('{Enter}');
		await act();
		const option1 = getByTestId('option1');
		const option2 = getByTestId('option2');
		expect(document.activeElement).toBe(option1);
		await user.keyboard('{ArrowDown}');
		expect(document.activeElement).toBe(option2);
		await user.keyboard('{ArrowDown}');
		expect(document.activeElement).toBe(option1);
		await user.keyboard('{Escape}');
		expect(document.activeElement).toBe(menuTrigger);
	});
});
