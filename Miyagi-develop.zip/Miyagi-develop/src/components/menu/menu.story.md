Menu component is used to house different actions in a pop-over pane.
