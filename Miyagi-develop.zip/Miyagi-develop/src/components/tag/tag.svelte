<script lang="ts">
	import type Children from '$types/children';

	export let label: Children = '';
</script>

<span {...$$restProps}>
	<slot>
		{label}
	</slot>
</span>

<style>
	span {
		display: inline-flex;
		flex-direction: row;
		align-items: center;
		justify-content: center;
		gap: var(--size-2);
		border: 1px solid var(--app-background);
		border-radius: var(--size-1);
		padding-block: var(--size-1);
		padding-inline: var(--size-2);
		background-color: var(--background-color, var(--surface-2));
		color: var(--color, var(--text-1));
		font-family: --var(--font-mono);
		font-size: var(--font-size-0-5);
		font-weight: var(--font-weight-4);
		transition-property: color, background-color;
		transition-duration: 0.2s;
		transition-timing-function: var(--ease-out-1);
		white-space: nowrap;
	}
</style>
