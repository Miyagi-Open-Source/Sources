<script>
	import Tag from '.';
	export let Hst;

	let label = '13pts';

	const source = `<Tag>
	{label}
</Tag>`;
</script>

<Hst.Story title="Tag" {source}>
	<svelte:fragment slot="controls">
		<Hst.Text bind:value={label} title="label" />
	</svelte:fragment>
	<Tag>
		{label}
	</Tag>
</Hst.Story>
