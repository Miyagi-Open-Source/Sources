Tag component is used to display info of things in a container.
