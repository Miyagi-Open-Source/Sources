import { cleanup, render } from '@testing-library/svelte';
import { beforeEach, describe, expect, test } from 'vitest';
import Tag from './tag.svelte';

beforeEach(cleanup);

describe('Component: Tag', () => {
	test('render', () => {
		render(Tag);
	});

	test('render label', () => {
		const label = 'Hello World';
		const { getByText } = render(Tag, { label });
		expect(getByText(label)).toBeDefined();
	});
});
