export { default } from './tag.svelte';
