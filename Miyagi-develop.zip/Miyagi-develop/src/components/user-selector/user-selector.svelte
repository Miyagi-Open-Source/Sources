<script lang="ts">
	import Avatar from '$components/avatar';
	import Menu from '$components/menu';
	import MenuItem from '$components/menu/menu-item';
	import type { Member } from '$types/member';

	type RequiredMember = Pick<Member, 'username'>;

	export let users: RequiredMember[];
	export let value: RequiredMember | null = null;
	export let unassign = 'No One';
</script>

<Menu variant="ghost" forceIconOnly={true} on:dblClick on:click on:contextmenu>
	<svelte:fragment slot="label">
		<Avatar size="small" profile={value} />
	</svelte:fragment>
	<MenuItem on:click={() => (value = null)}>
		<Avatar size="small" />
		{unassign}
	</MenuItem>
	<hr />
	{#each users as user}
		<MenuItem selected={value === user} on:click={() => (value = user)}>
			<Avatar size="small" profile={user} />
			{user.username}
		</MenuItem>
	{/each}
</Menu>
