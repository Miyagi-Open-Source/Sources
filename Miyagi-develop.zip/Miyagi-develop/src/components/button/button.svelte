<script context="module" lang="ts">
	export type ButtonVariants = 'primary' | 'regular' | 'ghost' | 'warn' | 'hover-warn';
</script>

<script lang="ts">
	import type { ActionArray } from '$lib/actions/types';
	import { useActions } from '$lib/actions/use-actions';
	import type Children from '$types/children';
	/** different styles of buttons. use cases described below */
	export let variant: ButtonVariants = 'regular';
	export let label: Children = '';
	export let title = '';
	export let href = '';
	export let external = false;
	export let disabled = false;
	export let type: 'button' | 'reset' | 'submit' = 'button';
	export let use: ActionArray = [];
	export let forceActive = false;
	/** DOM reference of rendered button or a element */
	export let elementRef: HTMLElement | null = null;
	export let forceIconOnly = false;
	$: iconOnly = !elementRef?.textContent || forceIconOnly;
</script>

{#if href}
	<a
		bind:this={elementRef}
		type={href ? null : type}
		href={href || null}
		rel={external ? 'nofollow noopener noreferrer' : null}
		target={external ? '_blank' : null}
		{...$$restProps}
		data-force-active={forceActive}
		class:icon-only={iconOnly}
		class="btn {variant}"
		on:click
		on:focus
		on:dblclick
		on:blur
		on:mouseup
		on:contextmenu
		use:useActions={use}
	>
		<slot>{label}</slot>
	</a>
{:else}
	<button
		bind:this={elementRef}
		disabled={disabled || null}
		{...$$restProps}
		data-force-active={forceActive}
		class:icon-only={iconOnly}
		class="btn {variant}"
		{title}
		{type}
		on:click
		on:dblclick
		on:focus
		on:blur
		on:mouseup
		on:contextmenu
		use:useActions={use}
	>
		<slot>{label}</slot>
	</button>
{/if}

<style lang="postcss">
	.btn {
		align-self: var(--align-self);
		display: inline-flex;
		flex-direction: row;
		align-items: center;
		justify-content: center;
		gap: var(--size-2);
		width: var(--width);
		border-radius: var(--size-1);
		border-width: 0;
		margin: var(--margin, 0);
		padding-block: var(--size-1);
		padding-inline: var(--size-3);
		font-weight: bold;
		text-decoration: none;
		cursor: pointer;
		transition-property: box-shadow, filter, background-color, border-color, color;
		transition-duration: 0.1s;
		transition-timing-function: var(--ease-out-1);

		&.icon-only {
			padding-inline: var(--size-1);
		}

		&.primary {
			background-color: var(--violet-9);
			color: var(--violet-0);
		}

		&.regular {
			border: 1px solid var(--surface-3);
			background-color: var(--surface-3);
			color: var(--text-1);
		}

		&.ghost {
			background-color: transparent;
			color: var(--text-1);

			&:is(:hover, :active, [data-force-active='true']):not(:disabled) {
				background-color: var(--surface-2);
			}
		}

		&.warn {
			border: 1px solid var(--red-9);
			background-color: transparent;
			color: var(--red-9);

			&:hover {
				background-color: var(--red-9);
				color: var(--red-0);
			}
		}

		&.hover-warn {
			--danger-color: var(--red-9);

			border: 1px solid var(--text-1);
			background-color: transparent;
			color: var(--text-1);

			&:hover:not(:disabled) {
				border: 1px solid var(--danger-color);
				background-color: var(--danger-color);
				color: var(--red-0);
			}
		}

		&:disabled {
			background-color: var(--surface-2);
			color: var(--gray-5);
			cursor: default;
		}

		&:hover:not(:disabled, .ghost) {
			box-shadow: var(--shadow-3);
			filter: brightness(110%);
		}

		&:is(:active, [data-force-active='true']):not(:disabled, .ghost) {
			box-shadow: var(--shadow-1);
			filter: brightness(90%);
		}
	}
</style>
