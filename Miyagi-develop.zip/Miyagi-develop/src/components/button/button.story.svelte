<script>
	import { hstEvent } from 'histoire/client';
	import IconPlus from '~icons/ic/round-plus';
	import Button from '.';
	export let Hst;

	let disabled = false;
	let label = 'Button Label';

	const variants = ['primary', 'regular', 'ghost', 'warn', 'hover-warn'];
	const handleClick = (e) => hstEvent('click', e);
</script>

<Hst.Story title="Button" layout={{ type: 'grid', width: 200 }}>
	<svelte:fragment slot="controls">
		<Hst.Text bind:value={label} title="label" />
		<Hst.Checkbox bind:value={disabled} title="disabled" />
	</svelte:fragment>

	{#each variants as variant}
		<Hst.Variant
			title={variant}
			source={`<Button on:click={handleClick} variant="${variant}">
	${label}
</Button>`}
		>
			<Button {disabled} {variant} on:click={handleClick}>
				<IconPlus />
				{label}
			</Button>
		</Hst.Variant>
	{/each}
	<Hst.Variant
		title="href"
		source={`<Button external href="https://clancy.digital/">
	Visit Clancy Digital
</Button>`}
	>
		<Button external href="https://clancy.digital/">Visit Clancy Digital</Button>
	</Hst.Variant>
</Hst.Story>
