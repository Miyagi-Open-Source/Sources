Button component is used to trigger an action or to navigate to a new page. Labels are set with the slot and should preferably include an Icon.

# Props

- `variant`: different styles of buttons. use cases described below
- `label`: used for testing, since we can't programmatically set slot. prefer using slot
- `href`: turns component to an anchor tag for links
- `external`: sets target to `_blank` when `href` is set
- `disabled`: disables the button (doesn't work on links)
- `type`: sets type e.g. `button` or `submit` (useful for forms)
- `use`: pass an array of Svelte actions to the rendered element
- `elementRef`: use with `bind:` to get the dom element reference

## Variants

- Regular buttons are the default. If you are not sure, just use this one.
- Primary button should only be on the page or dialog once, and be the primary action of that page or dialog.
- Ghost buttons are for actions with less visual weight.
- Warn buttons are for actions that should be handled with care and attention, e.g. deleting something.
