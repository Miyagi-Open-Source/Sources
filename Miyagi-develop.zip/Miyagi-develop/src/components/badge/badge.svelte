<script lang="ts">
	export let count = 0;
</script>

<div class="root">
	{#if count !== 0}
		<div class="badge">{count}</div>
	{/if}
	<slot />
</div>

<style>
	.root {
		position: relative;
	}

	.badge {
		position: absolute;
		top: 0;
		right: 0;
		display: flex;
		align-items: center;
		justify-content: center;
		width: 1.5em;
		height: 1.5em;
		border-radius: 100%;
		background-color: var(--red-9);
		font-size: 0.75rem;
		font-weight: bold;
		transform: translate(0.55rem, -0.45rem);
	}
</style>
