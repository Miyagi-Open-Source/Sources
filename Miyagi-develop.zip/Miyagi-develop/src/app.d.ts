/// <reference types="@sveltejs/kit" />
/// <reference types="unplugin-icons/types/svelte" />

// See https://kit.svelte.dev/docs/types#the-app-namespace
// for information about these interfaces
declare namespace App {
	// interface Locals {}
	// interface Platform {}
	// interface Session {}
	// interface Stuff {}
	interface Supabase {
		Database: import('$types/db-types').Database;
		SchemaName: 'public';
	}

	// interface Locals {}
	interface PageData {
		session: import('@supabase/supabase-js').Session | null;
	}
	// interface Error {}
	// interface Platform {}
}

// fix ts error
declare module 'svelte-frappe-charts';
declare module '@svelte-plugins/tooltips';

declare namespace svelteHTML {
	interface HTMLAttributes<T> {
		'on:handleMiddleClick'?: CompositionEventHandler<T>;
	}
}
