interface ImportMetaEnv {
	readonly VITE_SUPABASE_URL: string;
	readonly VITE_SUPABASE_KEY: string;
	readonly VITE_SUPABASE_SERVICE_ROLE: string;
	readonly VITE_DISABLE_CACHE: string;
	readonly VITE_DISABLE_LAZY_LOADING: string;
	readonly VITE_DISABLE_BATCH_UPDATE: string;
}

interface ImportMeta {
	readonly env: ImportMetaEnv;
}
