import type { Focusable, TypeCreator } from './helper';

export type Task = TypeCreator<'task'> & Focusable;
