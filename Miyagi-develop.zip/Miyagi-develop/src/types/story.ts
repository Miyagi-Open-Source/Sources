import type { Focusable, TypeCreator } from './helper';

export type Story = TypeCreator<'story'> & Focusable;
