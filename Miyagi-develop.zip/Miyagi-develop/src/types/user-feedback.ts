import type { Db_UserFeedback } from './db-types';

export type Feedback = Db_UserFeedback;
