import type { TypeCreator } from './helper';

export type Organization = TypeCreator<'organization'>;
