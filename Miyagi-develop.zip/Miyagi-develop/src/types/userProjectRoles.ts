import type { Db_UserProjectRoles } from './db-types';

export type Role = 'owner' | 'admin' | 'member' | 'guest' | 'unknown';

export type UserProjectRoles = Db_UserProjectRoles & {
	role: Role;
};
