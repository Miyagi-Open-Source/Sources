import type { Database as Generated } from '$types/generated2';

export type Database = {
	public: {
		Tables: {
			[K in 'sprint' | 'story' | 'task']: {
				Insert: {
					displayId?: Generated['public']['Tables'][K]['Insert']['displayId'];
				} & Omit<Generated['public']['Tables'][K]['Insert'], 'displayId'>;
			} & Omit<Generated['public']['Tables'][K], 'Insert'>;
		} & Omit<Generated['public']['Tables'], 'sprint' | 'story' | 'task'>;
	} & Omit<Generated['public'], 'Tables'>;
} & Omit<Generated, 'public'>;

export type Tables = Database['public']['Tables'];

// type Test = Tables['sprint']['Insert']['displayId'];

type Organization = Tables['organization'];
export type Db_Organization = Organization['Row'];
export type Db_Organization_Insert = Organization['Insert'];
export type Db_Organization_Update = Organization['Update'];

type Project = Tables['project'];
export type Db_Project = Project['Row'];
export type Db_Project_Insert = Project['Insert'];
export type Db_Project_Update = Project['Update'];

type Sprint = Tables['sprint'];
export type Db_Sprint = Sprint['Row'];
export type Db_Sprint_Insert = Sprint['Insert'];
export type Db_Sprint_Update = Sprint['Update'];

type Story = Tables['story'];
export type Db_Story = Story['Row'];
export type Db_Story_Insert = Story['Insert'];
export type Db_Story_Update = Story['Update'];

type Task = Tables['task'];
export type Db_Task = Task['Row'];
export type Db_Task_Insert = Task['Insert'];
export type Db_Task_Update = Task['Update'];

type userProjectRoles = Tables['userProjectRoles'];
export type Db_UserProjectRoles = userProjectRoles['Row'];
export type Db_UserProjectRoles_Insert = userProjectRoles['Insert'];
export type Db_UserProjectRoles_Update = userProjectRoles['Update'];

type Profiles = Tables['profiles'];
export type Db_Profiles = Profiles['Row'];
export type Db_Profiles_Insert = Profiles['Insert'];
export type Db_Profiles_Update = Profiles['Update'];

type UserFeedback = Tables['user-feedback'];
export type Db_UserFeedback = UserFeedback['Row'];
export type Db_UserFeedback_Insert = UserFeedback['Insert'];
export type Db_UserFeedback_Update = UserFeedback['Update'];

type InviteCode = Tables['inviteCode'];
export type Db_InviteCode = InviteCode['Row'];
export type Db_InviteCode_Insert = InviteCode['Insert'];
export type Db_InviteCode_Update = InviteCode['Update'];
