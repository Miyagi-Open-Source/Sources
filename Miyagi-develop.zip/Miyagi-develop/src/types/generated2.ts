export type Json = string | number | boolean | null | { [key: string]: Json } | Json[];

export interface Database {
	public: {
		Tables: {
			event: {
				Row: {
					count: number | null;
					date: string;
					id: number;
					type: string;
				};
				Insert: {
					count?: number | null;
					date: string;
					id?: number;
					type: string;
				};
				Update: {
					count?: number | null;
					date?: string;
					id?: number;
					type?: string;
				};
			};
			inviteCode: {
				Row: {
					code: string;
					created_at: string;
					endDate: string | null;
					maxUses: number | null;
					projectId: string;
					role: string;
					useCount: number;
				};
				Insert: {
					code: string;
					created_at?: string;
					endDate?: string | null;
					maxUses?: number | null;
					projectId: string;
					role: string;
					useCount?: number;
				};
				Update: {
					code?: string;
					created_at?: string;
					endDate?: string | null;
					maxUses?: number | null;
					projectId?: string;
					role?: string;
					useCount?: number;
				};
			};
			knownBugs: {
				Row: {
					body: string;
					created_at: string;
					id: number;
					status: string;
				};
				Insert: {
					body: string;
					created_at?: string;
					id?: number;
					status?: string;
				};
				Update: {
					body?: string;
					created_at?: string;
					id?: number;
					status?: string;
				};
			};
			organization: {
				Row: {
					created_at: string | null;
					id: string;
					name: string;
					owner: string;
				};
				Insert: {
					created_at?: string | null;
					id?: string;
					name: string;
					owner: string;
				};
				Update: {
					created_at?: string | null;
					id?: string;
					name?: string;
					owner?: string;
				};
			};
			profiles: {
				Row: {
					avatarUrl: string | null;
					dismissedDonate: boolean;
					id: string;
					updatedAt: string | null;
					username: string;
				};
				Insert: {
					avatarUrl?: string | null;
					dismissedDonate?: boolean;
					id: string;
					updatedAt?: string | null;
					username: string;
				};
				Update: {
					avatarUrl?: string | null;
					dismissedDonate?: boolean;
					id?: string;
					updatedAt?: string | null;
					username?: string;
				};
			};
			project: {
				Row: {
					createdAt: string;
					displayId: string;
					id: string;
					name: string;
					nextSprintDisplayId: number | null;
					nextStoryDisplayId: number | null;
					nextTaskDisplayId: number | null;
					organizationId: string;
					stati: string[];
					tag: string;
					TimerEndsAt: string | null;
					TimerPausedAt: string | null;
					vision: string | null;
				};
				Insert: {
					createdAt?: string;
					displayId?: string;
					id: string;
					name: string;
					nextSprintDisplayId?: number | null;
					nextStoryDisplayId?: number | null;
					nextTaskDisplayId?: number | null;
					organizationId: string;
					stati?: string[];
					tag?: string;
					TimerEndsAt?: string | null;
					TimerPausedAt?: string | null;
					vision?: string | null;
				};
				Update: {
					createdAt?: string;
					displayId?: string;
					id?: string;
					name?: string;
					nextSprintDisplayId?: number | null;
					nextStoryDisplayId?: number | null;
					nextTaskDisplayId?: number | null;
					organizationId?: string;
					stati?: string[];
					tag?: string;
					TimerEndsAt?: string | null;
					TimerPausedAt?: string | null;
					vision?: string | null;
				};
			};
			sprint: {
				Row: {
					createdAt: string | null;
					displayId: number;
					duration: number;
					endDate: string | null;
					goal: Json | null;
					id: string;
					isActive: boolean;
					isProjectBacklog: boolean;
					isRunning: boolean;
					name: string;
					projectId: string;
					sequence: number;
					startDate: string | null;
					updated_at: string;
				};
				Insert: {
					createdAt?: string | null;
					displayId: number;
					duration?: number;
					endDate?: string | null;
					goal?: Json | null;
					id: string;
					isActive?: boolean;
					isProjectBacklog?: boolean;
					isRunning?: boolean;
					name: string;
					projectId: string;
					sequence?: number;
					startDate?: string | null;
					updated_at?: string;
				};
				Update: {
					createdAt?: string | null;
					displayId?: number;
					duration?: number;
					endDate?: string | null;
					goal?: Json | null;
					id?: string;
					isActive?: boolean;
					isProjectBacklog?: boolean;
					isRunning?: boolean;
					name?: string;
					projectId?: string;
					sequence?: number;
					startDate?: string | null;
					updated_at?: string;
				};
			};
			story: {
				Row: {
					addedToSprintAt: string;
					createdAt: string | null;
					description: Json | null;
					displayId: number;
					id: string;
					points: number;
					sequence: number;
					sprintId: string;
					status: string;
					taskCount: number;
					title: string;
					updated_at: string;
				};
				Insert: {
					addedToSprintAt?: string;
					createdAt?: string | null;
					description?: Json | null;
					displayId: number;
					id: string;
					points?: number;
					sequence?: number;
					sprintId: string;
					status?: string;
					taskCount?: number;
					title?: string;
					updated_at?: string;
				};
				Update: {
					addedToSprintAt?: string;
					createdAt?: string | null;
					description?: Json | null;
					displayId?: number;
					id?: string;
					points?: number;
					sequence?: number;
					sprintId?: string;
					status?: string;
					taskCount?: number;
					title?: string;
					updated_at?: string;
				};
			};
			task: {
				Row: {
					assigneeId: string | null;
					completedAt: string | null;
					createdAt: string | null;
					description: Json | null;
					displayId: number;
					id: string;
					sequence: number;
					status: string;
					storyId: string;
					title: string;
					updated_at: string;
				};
				Insert: {
					assigneeId?: string | null;
					completedAt?: string | null;
					createdAt?: string | null;
					description?: Json | null;
					displayId: number;
					id: string;
					sequence?: number;
					status?: string;
					storyId: string;
					title?: string;
					updated_at?: string;
				};
				Update: {
					assigneeId?: string | null;
					completedAt?: string | null;
					createdAt?: string | null;
					description?: Json | null;
					displayId?: number;
					id?: string;
					sequence?: number;
					status?: string;
					storyId?: string;
					title?: string;
					updated_at?: string;
				};
			};
			'user-feedback': {
				Row: {
					created_at: string;
					email: string | null;
					id: number;
					message: string;
					subject: string | null;
				};
				Insert: {
					created_at?: string;
					email?: string | null;
					id?: number;
					message: string;
					subject?: string | null;
				};
				Update: {
					created_at?: string;
					email?: string | null;
					id?: number;
					message?: string;
					subject?: string | null;
				};
			};
			userProjectRoles: {
				Row: {
					accepted: boolean;
					created_at: string | null;
					lastSeenCurrentSprint: string;
					projectId: string;
					role: string;
					userId: string;
				};
				Insert: {
					accepted?: boolean;
					created_at?: string | null;
					lastSeenCurrentSprint?: string;
					projectId: string;
					role?: string;
					userId: string;
				};
				Update: {
					accepted?: boolean;
					created_at?: string | null;
					lastSeenCurrentSprint?: string;
					projectId?: string;
					role?: string;
					userId?: string;
				};
			};
		};
		Views: {
			users: {
				Row: {
					aud: string | null;
					banned_until: string | null;
					confirmation_sent_at: string | null;
					confirmation_token: string | null;
					confirmed_at: string | null;
					created_at: string | null;
					email: string | null;
					email_change: string | null;
					email_change_confirm_status: number | null;
					email_change_sent_at: string | null;
					email_change_token_current: string | null;
					email_change_token_new: string | null;
					email_confirmed_at: string | null;
					encrypted_password: string | null;
					id: string | null;
					instance_id: string | null;
					invited_at: string | null;
					is_super_admin: boolean | null;
					last_sign_in_at: string | null;
					phone: string | null;
					phone_change: string | null;
					phone_change_sent_at: string | null;
					phone_change_token: string | null;
					phone_confirmed_at: string | null;
					raw_app_meta_data: Json | null;
					raw_user_meta_data: Json | null;
					reauthentication_sent_at: string | null;
					reauthentication_token: string | null;
					recovery_sent_at: string | null;
					recovery_token: string | null;
					role: string | null;
					updated_at: string | null;
				};
				Insert: {
					aud?: string | null;
					banned_until?: string | null;
					confirmation_sent_at?: string | null;
					confirmation_token?: string | null;
					confirmed_at?: string | null;
					created_at?: string | null;
					email?: string | null;
					email_change?: string | null;
					email_change_confirm_status?: number | null;
					email_change_sent_at?: string | null;
					email_change_token_current?: string | null;
					email_change_token_new?: string | null;
					email_confirmed_at?: string | null;
					encrypted_password?: string | null;
					id?: string | null;
					instance_id?: string | null;
					invited_at?: string | null;
					is_super_admin?: boolean | null;
					last_sign_in_at?: string | null;
					phone?: string | null;
					phone_change?: string | null;
					phone_change_sent_at?: string | null;
					phone_change_token?: string | null;
					phone_confirmed_at?: string | null;
					raw_app_meta_data?: Json | null;
					raw_user_meta_data?: Json | null;
					reauthentication_sent_at?: string | null;
					reauthentication_token?: string | null;
					recovery_sent_at?: string | null;
					recovery_token?: string | null;
					role?: string | null;
					updated_at?: string | null;
				};
				Update: {
					aud?: string | null;
					banned_until?: string | null;
					confirmation_sent_at?: string | null;
					confirmation_token?: string | null;
					confirmed_at?: string | null;
					created_at?: string | null;
					email?: string | null;
					email_change?: string | null;
					email_change_confirm_status?: number | null;
					email_change_sent_at?: string | null;
					email_change_token_current?: string | null;
					email_change_token_new?: string | null;
					email_confirmed_at?: string | null;
					encrypted_password?: string | null;
					id?: string | null;
					instance_id?: string | null;
					invited_at?: string | null;
					is_super_admin?: boolean | null;
					last_sign_in_at?: string | null;
					phone?: string | null;
					phone_change?: string | null;
					phone_change_sent_at?: string | null;
					phone_change_token?: string | null;
					phone_confirmed_at?: string | null;
					raw_app_meta_data?: Json | null;
					raw_user_meta_data?: Json | null;
					reauthentication_sent_at?: string | null;
					reauthentication_token?: string | null;
					recovery_sent_at?: string | null;
					recovery_token?: string | null;
					role?: string | null;
					updated_at?: string | null;
				};
			};
		};
		Functions: {
			decEventOrCreate: {
				Args: {
					type: string;
				};
				Returns: undefined;
			};
			get_random_string: {
				Args: {
					string_length?: number;
					possible_chars?: string;
				};
				Returns: string;
			};
			incEventOrCreate: {
				Args: {
					type: string;
				};
				Returns: undefined;
			};
			setEventOrCreate: {
				Args: {
					type: string;
					value: number;
				};
				Returns: undefined;
			};
		};
		Enums: {
			[_ in never]: never;
		};
		CompositeTypes: {
			[_ in never]: never;
		};
	};
}
