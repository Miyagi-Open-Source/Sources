import type { childrenPropertiesType } from '$lib/stores/hierarchy';
import type { Tables } from './db-types';
import type { Organization } from './organization';
import type { Project } from './project';
import type { Sprint } from './sprint';
import type { Story } from './story';
import type { Task } from './task';

export type TypeHierarchy = {
	// @ts-ignore
	[K in keyof childrenPropertiesType]: childrenPropertiesType[K]['type'];
};

type TypeHierarchyParentHelper<T extends TypeString, TSearch extends TypeString> = T extends (
	TSearch extends TypeHierarchy[T] ? T : never
)
	? T
	: never;
export type TypeHierarchyParent = {
	[K in keyof TypeHierarchy]: TypeHierarchyParentHelper<TypeString, K>;
};

export type TypeType = StringToType<TypeString>;
export type TypeString = keyof TypeHierarchy;
export type TypeTable = Tables[TypeString];

export type TableToType<T extends TypeTable> = T extends Tables['organization']
	? Organization
	: T extends Tables['project']
	? Project
	: T extends Tables['story']
	? Story
	: T extends Tables['task']
	? Task
	: T extends Tables['sprint']
	? Sprint
	: never;

type TypeToTableHelper<T extends TypeTable, TSearch extends TypeType> = T extends (
	TableToType<T> extends TSearch ? T : never
)
	? T
	: never;
export type TypeToTable<TType extends TypeType> = TypeToTableHelper<TypeTable, TType>;

export type TableToStringHelper<T extends TypeString, TSearch extends TypeTable> = T extends (
	Tables[T] extends TSearch ? T : never
)
	? T
	: never;
export type TableToString<TSearch extends TypeTable> = TableToStringHelper<TypeString, TSearch>;

export type StringToTable<TSearch extends TypeString> = Tables[TSearch];
export type StringToType<TSearch extends TypeString> = TableToType<StringToTable<TSearch>>;
export type TypeToString<TSearch extends TypeType> = TableToString<TypeToTable<TSearch>>;

/* Tests */
type TableToTypeTestOrganization = TableToType<Tables['organization']> extends Organization ? true : false;
type TableToTypeTestProject = TableToType<Tables['project']> extends Project ? true : false;
type TableToTypeTestSprint = TableToType<Tables['sprint']> extends Sprint ? true : false;
type TableToTypeTestStory = TableToType<Tables['story']> extends Story ? true : false;
type TableToTypeTestTask = TableToType<Tables['task']> extends Task ? true : false;
type TableToTypeTest = TableToTypeTestOrganization &
	TableToTypeTestProject &
	TableToTypeTestSprint &
	TableToTypeTestStory &
	TableToTypeTestTask;

type TableToStringTestOrganization = TableToString<Tables['organization']> extends 'organization' ? true : false;
type TableToStringTestProject = TableToString<Tables['project']> extends 'project' ? true : false;
type TableToStringTestSprint = TableToString<Tables['sprint']> extends 'sprint' ? true : false;
type TableToStringTestStory = TableToString<Tables['story']> extends 'story' ? true : false;
type TableToStringTestTask = TableToString<Tables['task']> extends 'task' ? true : false;
type TableToStringTest = TableToStringTestOrganization &
	TableToStringTestProject &
	TableToStringTestSprint &
	TableToStringTestStory &
	TableToStringTestTask;

type StringToTableTestOrganization = StringToTable<'organization'> extends Tables['organization'] ? true : false;
type StringToTableTestProject = StringToTable<'project'> extends Tables['project'] ? true : false;
type StringToTableTestSprint = StringToTable<'sprint'> extends Tables['sprint'] ? true : false;
type StringToTableTestStory = StringToTable<'story'> extends Tables['story'] ? true : false;
type StringToTableTestTask = StringToTable<'task'> extends Tables['task'] ? true : false;
type StringToTableTest = StringToTableTestOrganization &
	StringToTableTestProject &
	StringToTableTestSprint &
	StringToTableTestStory &
	StringToTableTestTask;

type StringToTypeTestOrganization = StringToType<'organization'> extends Organization ? true : false;
type StringToTypeTestProject = StringToType<'project'> extends Project ? true : false;
type StringToTypeTestSprint = StringToType<'sprint'> extends Sprint ? true : false;
type StringToTypeTestStory = StringToType<'story'> extends Story ? true : false;
type StringToTypeTestTask = StringToType<'task'> extends Task ? true : false;
type StringToTypeTest = StringToTypeTestOrganization &
	StringToTypeTestProject &
	StringToTypeTestSprint &
	StringToTypeTestStory &
	StringToTypeTestTask;

type TypeToStringTestOrganization = TypeToString<Organization> extends 'organization' ? true : false;
type TypeToStringTestProject = TypeToString<Project> extends 'project' ? true : false;
type TypeToStringTestSprint = TypeToString<Sprint> extends 'sprint' ? true : false;
type TypeToStringTestStory = TypeToString<Story> extends 'story' ? true : false;
type TypeToStringTestTask = TypeToString<Task> extends 'task' ? true : false;
type TypeToStringTest = TypeToStringTestOrganization &
	TypeToStringTestProject &
	TypeToStringTestSprint &
	TypeToStringTestStory &
	TypeToStringTestTask;

type TypeToTableTestOrganization = TypeToTable<Organization> extends Tables['organization'] ? true : false;
type TypeToTableTestProject = TypeToTable<Project> extends Tables['project'] ? true : false;
type TypeToTableTestSprint = TypeToTable<Sprint> extends Tables['sprint'] ? true : false;
type TypeToTableTestStory = TypeToTable<Story> extends Tables['story'] ? true : false;
type TypeToTableTestTask = TypeToTable<Task> extends Tables['task'] ? true : false;
type TypeToTableTest = TypeToTableTestOrganization &
	TypeToTableTestProject &
	TypeToTableTestSprint &
	TypeToTableTestStory &
	TypeToTableTestTask;

type AssertTestSuccess<T extends true> = T;
// eslint-disable-next-line @typescript-eslint/no-unused-vars
type TestSuccess = AssertTestSuccess<
	TableToTypeTest & TableToStringTest & StringToTableTest & StringToTypeTest & TypeToStringTest & TypeToTableTest
>;
