import type { editingDisabled } from '$lib/symbols';
import type { Filter } from './helper';
import type { TypeType } from './hierarchy';
export interface LocalId {
	localId: number;
}

export interface TypeInformation {
	type: 'sprint' | 'story' | 'task' | 'backlog' | 'pastSprints' | 'currentSprints' | 'futureSprints' | 'backlog';
}

export type ListItem = {
	update: (update: { sequence: number }) => unknown;
} & Pick<Filter<TypeType, { sequence: unknown }>, 'sequence' | 'localId'>;

// export interface Cacheable {
// 	[fromCache]: boolean;
// }

export interface Editable {
	[editingDisabled]?: boolean;
}
