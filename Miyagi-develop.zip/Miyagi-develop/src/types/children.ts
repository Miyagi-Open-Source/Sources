type Children = string | number;

export default Children;
