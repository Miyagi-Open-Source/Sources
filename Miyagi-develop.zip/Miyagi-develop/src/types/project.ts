import type { Db_InviteCode } from './db-types';
import type { TypeCreator } from './helper';
import type { Member } from './member';
import type { UserProfile } from './user';

export type Project = TypeCreator<'project'> & {
	members: Member[];
	inviteMember: (email: string) => Promise<{ data: true; error: null } | { error: string; data: null }>;
	removeMember: (userId: UserProfile['id']) => void;
	updateMemberRole: (userId: UserProfile['id'], role: Member['role']) => void;
} & {
	inviteCodes: Omit<Db_InviteCode, 'created_at' | 'projectId'>[];
	createInviteCode: (code: string, role: Db_InviteCode['role'], maxUses: number, endDate: Date | null) => void;
	deleteInviteCode: (code: string) => void;
};
