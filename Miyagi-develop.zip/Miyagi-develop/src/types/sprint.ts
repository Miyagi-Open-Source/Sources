import type { Focusable, TypeCreator } from './helper';

export type Sprint = TypeCreator<'sprint'> &
	Focusable & {
		start: () => void;
		end: () => void;
	};
