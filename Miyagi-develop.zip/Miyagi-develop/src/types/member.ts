import type { UserProfile } from './user';
import type { UserProjectRoles } from './userProjectRoles';

export type Member = UserProjectRoles & UserProfile;
