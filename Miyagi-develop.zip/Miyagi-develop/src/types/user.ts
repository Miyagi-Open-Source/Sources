import type { Db_Profiles } from './db-types';

export type UserProfile = Db_Profiles;
