import type { childrenPropertiesType } from '$lib/stores/hierarchy';
import type { editingDisabled, focus } from '$lib/symbols';
import { awaitLoaded } from '$lib/handlers';
import type {
	StringToTable,
	StringToType,
	TypeHierarchy,
	TypeHierarchyParent,
	TypeString,
	TypeType,
} from './hierarchy';

export type addPrefixToObject<T, P extends string> = {
	[K in keyof T as K extends string ? `${P}${K}` : never]: T[K];
};

export type AtLeast<T extends object, K extends keyof T = never> = Partial<T> & Required<Pick<T, K>>;

/* Automatic Type generation */
type createFunction<TString extends TypeString> = {
	[K in `create${Capitalize<TypeHierarchy[TString]>}`]: (
		// @ts-ignore
		data: Compute<Omit<StringToTable<TypeHierarchy[TString]>['Insert'], TString | `${TString}Id` | 'id'>>,
		property?: childrenPropertiesType[TString]['key']
	) => Promise<StringToType<TypeHierarchy[TString]>>;
};

type deleteUpdateFunction<TString extends TypeString> = {
	delete: () => void;
	update: (
		this: StringToType<TString>,
		data: StringToTable<TString>['Update']
	) => Promise<StringToTable<TString>['Update'] | null>;
};
type childrenProperty<T extends TypeString> = {
	[K in childrenPropertiesType[T]['key']]: StringToType<TypeHierarchy[T]>[];
};

type parentProperty<T extends TypeString> = {
	[K in TypeHierarchyParent[T]]: StringToType<TypeHierarchyParent[T]>;
};

type symbols = {
	[editingDisabled]?: boolean;
};

export type Focusable = {
	[focus]?: () => void;
};

export type TypeCreator<TString extends TypeString> = deleteUpdateFunction<TString> &
	createFunction<TString> &
	childrenProperty<TString> &
	parentProperty<TString> &
	symbols &
	StringToTable<TString>['Row'] & {
		type: TString;
		localId: number;
	} & {
		[awaitLoaded]: <TArg extends keyof childrenProperty<TString>>(
			arg: TArg
		) => Promise<childrenProperty<TString>[TArg]>;
	};

export type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

export type XOR<T, U> = T | U extends object ? (Without<T, U> & U) | (Without<U, T> & T) : T | U;

export type Filter<T, TMatch> = T extends TMatch ? T : never;

export type valueOf<T> = T[keyof T];

// Make types more readable
export type Compute<T> = { [K in keyof T]: T[K] } & unknown;

export type WithDisplayId<T extends TypeType> = T extends { displayId: number | null } ? T : never;

export type NotNull<T> = T extends null ? never : T;

export type Optional<T extends object, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;
