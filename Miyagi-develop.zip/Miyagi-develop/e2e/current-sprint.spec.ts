import { expect, test } from '@playwright/test';
// NOTICE: We import from .ts files as .js because of https://github.com/microsoft/playwright/issues/14053
import { dataTestId, dragAndDrop, waitForNetworkSettled } from './helpers.js';

test.describe('/current-sprint', () => {
	test.beforeEach(async ({ page }) => {
		page.on('pageerror', (exception) => {
			console.error(`Uncaught exception: "${JSON.stringify(exception)}"`);
		});
		await page.goto('/', { waitUntil: 'networkidle' });
		await page.locator('text=Go to Backlog').click();
		await new Promise((resolve) => setTimeout(resolve, 4000));
		await page.locator('a:has-text("Sprint")').click();
	});

	test('move task from todo to in progress via drag and drop', async ({ page }) => {
		const listWithTaskInBacklogSel = `li:has(${dataTestId('list-status-backlog')} ${dataTestId('list-item-0')})`;
		const listEl = await page.locator(listWithTaskInBacklogSel).first().elementHandle();
		const listItemNumber = await listEl.getAttribute('data-testid');
		const backlogTaskSel = `${dataTestId(listItemNumber)}
		${dataTestId('list-status-backlog')}
		${dataTestId('list-item-0')}`;
		const movedTaskTitle = await page.locator(`${backlogTaskSel} ${dataTestId('task-title')}`).textContent();

		await waitForNetworkSettled(page, async () => {
			await dragAndDrop(page, backlogTaskSel, `${dataTestId(listItemNumber)} ${dataTestId('list-status-inProgress')}`);
		});

		const movedStoriesel = `${dataTestId('list-status-inProgress')}:has-text("${movedTaskTitle}")`;
		const movedStoryEl = await page.locator(movedStoriesel).elementHandle();
		expect(movedStoryEl).toBeDefined();
	});

	test('move task from todo to in progress via dropdown', async ({ page }) => {
		const listWithTaskInBacklogSel = `li:has(${dataTestId('list-status-backlog')} ${dataTestId('list-item-0')})`;
		const listEl = await page.locator(listWithTaskInBacklogSel).first().elementHandle();
		const listItemNumber = await listEl.getAttribute('data-testid');
		const backlogTaskSel = `${dataTestId(listItemNumber)}
		${dataTestId('list-status-backlog')}
		${dataTestId('list-item-0')}`;
		const movedTaskTitle = await page.locator(`${backlogTaskSel} ${dataTestId('task-title')}`).textContent();

		await page.click(`${backlogTaskSel} ${dataTestId('move-menu')}`);
		await waitForNetworkSettled(page, async () => {
			await page.click(`${backlogTaskSel} ${dataTestId('move-to-status-inProgress')}`);
		});

		const movedStoriesel = `${dataTestId('list-status-inProgress')}:has-text("${movedTaskTitle}")`;
		const movedStoryEl = await page.locator(movedStoriesel).elementHandle();
		expect(movedStoryEl).toBeDefined();
	});
});
