import type { Page } from 'playwright-core';

export const screenshotPath = './reports/screenshots/';

export const dataTestId = (id: string, operator = '') => `[data-testid${operator}="${id}"]`;

const LIST_DELAY = 300;
export const dragAndDrop = async (page: Page, srcSel: string, targetSel: string) => {
	await page.locator(srcSel).hover({ position: { x: 4, y: 25 } });
	await page.mouse.down();
	await page.waitForTimeout(LIST_DELAY);
	await page.mouse.move(0, 0);
	await page.waitForTimeout(LIST_DELAY);
	await page.locator(targetSel).hover({ position: { x: 16, y: 16 } });
	await page.waitForTimeout(LIST_DELAY);
	await page.mouse.up();
	await page.waitForTimeout(LIST_DELAY);
};

/** Wraps an action in a counter that checks if all emitted requests have responses.
 * Based upon this Gist by one of the Playwright devs: https://gist.github.com/dgozman/d1c46f966eb9854ee1fe24960b603b28
 */
export async function waitForNetworkSettled(page: Page, action: () => unknown, longPolls = 0) {
	let networkSettledCallback: (value?: unknown) => void;
	const networkSettledPromise = new Promise((f) => (networkSettledCallback = f));

	let requestCounter = 0;
	let actionDone = false;

	const maybeSettle = () => {
		// Wait for additional 500ms to check if network is really settled
		setTimeout(() => {
			if (actionDone && requestCounter <= longPolls) networkSettledCallback();
		}, 500);
	};

	const onRequest = () => {
		++requestCounter;
	};

	const onRequestDone = () => {
		// Let the page handle responses asynchronously (via setTimeout(0)).
		// Note: this might be changed to use delay, e.g. setTimeout(f, 100),
		// when the page uses delay itself.
		const evaluate = page.evaluate(() => new Promise((f) => setTimeout(f, 0)));
		evaluate
			.catch((e) => {
				throw e;
			})
			.then(() => {
				--requestCounter;
				maybeSettle();
			});
	};

	page.on('request', onRequest);
	page.on('requestfinished', onRequestDone);
	page.on('requestfailed', onRequestDone);

	const result = await action();
	actionDone = true;
	maybeSettle();
	await networkSettledPromise;

	page.removeListener('request', onRequest);
	page.removeListener('requestfinished', onRequestDone);
	page.removeListener('requestfailed', onRequestDone);

	return result;
}
