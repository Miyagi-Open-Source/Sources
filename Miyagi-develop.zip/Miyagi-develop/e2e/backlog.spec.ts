import { expect, test } from '@playwright/test';
// NOTICE: We import from .ts files as .js because of https://github.com/microsoft/playwright/issues/14053
import { dataTestId, dragAndDrop, waitForNetworkSettled } from './helpers.js';

test.describe('/backlog', () => {
	test.beforeEach(async ({ page }) => {
		page.on('pageerror', (exception) => {
			console.error(`Uncaught exception: "${JSON.stringify(exception)}"`);
		});
		await page.goto('/', { waitUntil: 'networkidle' });
		await page.locator('text=Go to Backlog').click();
		await new Promise((resolve) => setTimeout(resolve, 4000));
	});

	test('backlog displays test data', async ({ page }) => {
		expect(await page.textContent('h2')).toContain('Sprint');
		const story1Loc = page.locator(`${dataTestId('story-card')} summary:has-text("Story 1")`);
		const story1Ele = await story1Loc.elementHandle();
		expect(story1Ele).toBeDefined();
		await story1Loc.click();
		const task1Ele = await page.locator(`${dataTestId('task-card')}:has-text("Task 1")`).elementHandle();
		expect(task1Ele).toBeDefined();
		const story2Ele = await page.locator(`${dataTestId('story-card')}:has-text("Story 2")`).elementHandle();
		expect(story2Ele).toBeDefined();
	});

	test('create new story', async ({ page }) => {
		await waitForNetworkSettled(page, async () => {
			await page.click(dataTestId('create-story'));
		});

		await page.reload({ waitUntil: 'networkidle' });

		const newStoryLoc = page.locator(`${dataTestId('story-card')}:has-text("New Story")`);
		const newStoryEle = await newStoryLoc.elementHandle();
		expect(newStoryEle).toBeDefined();
	});

	test('create new task', async ({ page }) => {
		const story1Sel = `${dataTestId('story-card')}:has-text("Story 1")`;
		await page.click(story1Sel);

		await waitForNetworkSettled(page, async () => {
			await page.click(`${story1Sel} ${dataTestId('create-task')}`);
		});
		await page.reload({ waitUntil: 'networkidle' });

		const newTaskEle = await page.locator('text=New Task').elementHandle();
		expect(newTaskEle).toBeDefined();
	});

	test('edit story title', async ({ page }) => {
		const story1Sel = `${dataTestId('story-card')}:has-text("Story 1")`;
		await page.click(story1Sel);
		const input = page.locator(`${story1Sel} ${dataTestId('story-title-form')}`);
		const newStoryTitle = 'Other Story Title';

		await input.fill(newStoryTitle);
		await waitForNetworkSettled(page, async () => {
			await input.evaluate((e) => e.blur());
		});
		await page.reload({ waitUntil: 'networkidle' });

		const renamedStory = await page.locator(`${dataTestId('story-card')}:has-text("${newStoryTitle}")`).elementHandle();
		expect(renamedStory).toBeDefined();
	});

	test('edit story description', async ({ page }) => {
		const firstStoriesel = `${dataTestId('list-current-sprint')} ${dataTestId('list-item-0')}`;
		await page.click(firstStoriesel);
		const descriptionFormInput = page.locator(
			`${firstStoriesel} ${dataTestId('story-description-form')} > [contenteditable]`
		);
		const newStoryDescription = 'Different Story Description';

		await descriptionFormInput.fill(newStoryDescription);
		await waitForNetworkSettled(page, async () => {
			await descriptionFormInput.evaluate((e) => e.blur());
		});

		await page.reload({ waitUntil: 'networkidle' });

		await page.click(firstStoriesel);
		const renameStoryDescSel = `${dataTestId('story-card')}:has-text("${newStoryDescription}")`;
		const renamedStoryDesc = await page.locator(renameStoryDescSel).elementHandle();
		expect(renamedStoryDesc).toBeDefined();
	});

	test('edit task title', async ({ page }) => {
		const storyWithTaskSel = `${dataTestId('story-card')}:has-text("Task 1")`;
		await page.click(`${storyWithTaskSel} summary`);
		const task1Sel = `${dataTestId('task-card')}:has-text("Task 1")`;
		await page.click(`${task1Sel} summary`);
		const input = page.locator(`${task1Sel} ${dataTestId('task-title-form')}`);
		const newTaskTitle = 'Other Task Title';

		await input.fill(newTaskTitle);
		await waitForNetworkSettled(page, async () => {
			await input.evaluate((e) => e.blur());
		});
		await page.reload({ waitUntil: 'networkidle' });

		const renamedTask = await page.locator(`${dataTestId('task-card')}:has-text("${newTaskTitle}")`).elementHandle();
		expect(renamedTask).toBeDefined();
	});

	test('change story sequence via drag and drop', async ({ page }) => {
		const secondStoriesel = `${dataTestId('list-current-sprint')} ${dataTestId('list-item-1')} ${dataTestId(
			'story-card'
		)}`;
		const movedStoryTitle = await page.locator(`${secondStoriesel} ${dataTestId('story-title')}`).textContent();

		await waitForNetworkSettled(page, async () => {
			await dragAndDrop(page, secondStoriesel, dataTestId('list-current-sprint'));
		});
		await page.reload({ waitUntil: 'networkidle' });

		const firstStoriesel = `${dataTestId('list-current-sprint')} ${dataTestId('list-item-0')}`;
		expect(await page.textContent(firstStoriesel)).toContain(movedStoryTitle);
	});

	test('change story sequence via dropdown', async ({ page }) => {
		const secondStoriesel = `${dataTestId('list-current-sprint')} ${dataTestId('list-item-1')} ${dataTestId(
			'story-card'
		)}`;
		const movedStoryTitle = await page.locator(`${secondStoriesel} ${dataTestId('story-title')}`).textContent();

		await page.click(`${secondStoriesel} ${dataTestId('move-menu')}`);
		await waitForNetworkSettled(page, async () => {
			await page.click(`${secondStoriesel} ${dataTestId('move-up')}`);
		});
		await page.reload({ waitUntil: 'networkidle' });

		const firstStoriesel = `${dataTestId('list-current-sprint')} ${dataTestId('list-item-0')}`;
		expect(await page.textContent(firstStoriesel)).toContain(movedStoryTitle);
	});

	test('move story from product backlog to current sprint via drag and drop', async ({ page }) => {
		const backlogStoriesel = `${dataTestId('list-product-backlog')} ${dataTestId('list-item-0')}`;
		const movedStoryTitle = await page.locator(`${backlogStoriesel} ${dataTestId('story-title')}`).textContent();

		await waitForNetworkSettled(page, async () => {
			await dragAndDrop(page, backlogStoriesel, dataTestId('list-current-sprint'));
		});
		await page.reload({ waitUntil: 'networkidle' });

		const movedStoriesel = `${dataTestId('list-current-sprint')}:has-text("${movedStoryTitle}")`;
		const movedStoryEl = await page.locator(movedStoriesel).elementHandle();
		expect(movedStoryEl).toBeDefined();
		const firstStoriesel = `${dataTestId('list-current-sprint')} ${dataTestId('list-item-0')}`;
		expect(await page.textContent(firstStoriesel)).toContain(movedStoryTitle);
	});

	test('move story from product backlog to current sprint via dropdown', async ({ page }) => {
		const backlogStoriesel = `${dataTestId('list-product-backlog')} ${dataTestId('list-item-0')}`;
		const movedStoryTitle = await page.locator(`${backlogStoriesel} ${dataTestId('story-title')}`).textContent();

		await page.click(`${backlogStoriesel} ${dataTestId('move-menu')}`);
		await waitForNetworkSettled(page, async () => {
			await page.click(`${backlogStoriesel} ${dataTestId('move-to-current-sprint')}`);
		});
		await page.reload({ waitUntil: 'networkidle' });

		const movedStoriesel = `${dataTestId('list-current-sprint')}:has-text("${movedStoryTitle}")`;
		const movedStoryEl = await page.locator(movedStoriesel).elementHandle();
		expect(movedStoryEl).toBeDefined();
	});

	test('create new sprint via drag and drop', async ({ page }) => {
		const backlogStoriesel = `${dataTestId('list-product-backlog')} ${dataTestId('list-item-0')}`;
		const movedStoryTitle = await page.locator(`${backlogStoriesel} ${dataTestId('story-title')}`).textContent();

		await waitForNetworkSettled(page, async () => {
			await dragAndDrop(page, backlogStoriesel, dataTestId('list-new-sprint'));
		});
		await page.reload({ waitUntil: 'networkidle' });

		const newSprintSel = `${dataTestId('future-sprint', '^')}:has-text("New Sprint 1 Story")`;
		const movedStoriesel = `${newSprintSel}:has-text("${movedStoryTitle}")`;
		const movedStoryEl = await page.locator(movedStoriesel).elementHandle();
		expect(movedStoryEl).toBeDefined();
	});

	test('end current sprint', async ({ page }) => {
		// const currentSprintTitle = await page
		// 	.locator(`${dataTestId('current-sprint')} ${dataTestId('sprint-title')}`)
		// 	.textContent();
		// const nextSprintTitle = await page
		// 	.locator(`${dataTestId('future-sprint-0')} ${dataTestId('sprint-title')}`)
		// 	.textContent();

		await page.click(dataTestId('end-sprint'));
		await waitForNetworkSettled(page, async () => {
			await page.click(dataTestId('confirm'));
		});
		await page.reload({ waitUntil: 'networkidle' });

		// TODO find out why test fails, code seems to work
		// const prevSprintSel = `${dataTestId('current-sprint')}:has-text("${currentSprintTitle}")`;
		// await expect(page.locator(prevSprintSel)).toHaveCount(0);
		// const nextSprintSel = `${dataTestId('current-sprint')}:has-text("${nextSprintTitle}")`;
		// const nextSprintEl = await page.locator(nextSprintSel).elementHandle();
		// expect(nextSprintEl).toBeDefined();

		// expect(await page.textContent('h2')).toContain('Next Sprint');
	});

	test('start next sprint', async ({ page }) => {
		await page.click(dataTestId('start-sprint'));

		await waitForNetworkSettled(page, async () => {
			await page.click(dataTestId('confirm'));
		});
		await page.reload({ waitUntil: 'networkidle' });

		expect(await page.textContent('h2')).toContain('Current Sprint');
	});
});
