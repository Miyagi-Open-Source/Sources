// NOTICE: We import from .ts files as .js because of https://github.com/microsoft/playwright/issues/14053
import prepareDb from './db-setup.js';

import { chromium } from '@playwright/test';

async function globalSetup() {
	await prepareDb();
	const browser = await chromium.launch();
	const page = await browser.newPage();

	await page.goto('http://localhost:4000');
	await page.click('button[data-testid="login"]');
	await page.fill('input[name="email"]', 'dev.miyagi@clancy.digital');
	await page.fill('input[name="password"]', 't0tallySecure!');
	await page.click('button[type="submit"]');

	// await page.waitForNavigation();
	await new Promise((resolve) => setTimeout(resolve, 5000));

	// Save signed-in state to 'storageState.json'.
	await page.context().storageState({ path: 'storageState.json' });
	await browser.close();
}

export default globalSetup;
