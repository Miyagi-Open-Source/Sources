import { createClient } from '@supabase/supabase-js';
import 'dotenv/config';

import type { Database } from '../src/types/db-types';

const supabaseUrl = process.env.VITE_SUPABASE_URL;

if (!supabaseUrl) {
	throw new Error('VITE_SUPABASE_URL is not defined');
} else if (
	/* PROD Instance Fail Save */
	supabaseUrl.includes('euimttcmodocnpqnialv') /* DEV */ ||
	supabaseUrl.includes('ovhqekokhifkazbppkak') /* PROD */
) {
	throw new Error('Detected Superbase dev or prod instance! Change ENV variables to a different instance.');
}

export const supabase = createClient<Database>(supabaseUrl as string, process.env.VITE_SUPABASE_KEY as string);

export async function deleteAllData() {
	log('Deleting data...');
	const TABLES_TO_DELETE = ['task', 'story', 'sprint', 'project', 'user-feedback'];
	for await (const table of TABLES_TO_DELETE) {
		log(`Deleting all rows of ${table} table...`);
		const { error } = await supabase.from(table).delete().neq('id', 0);
		if (error) throw error;
	}
	log('Deleting done!');
}

export async function writeTestData() {
	log('Writing test data...');

	log('Writing organization...');
	const { error: organizationErr, data: organizationData } = await supabase
		.from('organization')
		.insert({
			name: 'E2E Test Organization',
		})
		.select('*');

	if (organizationErr) throw organizationErr;
	const organizationId = organizationData[0].id;

	log('adding testuser as owner of organization...');
	const testAccountId = '02e98ba5-ad60-4dc4-9f6e-03476b22cede';
	const { error: userProjectRolesErr } = await supabase.from('userProjectRoles').insert({
		role: 'owner',
		userId: testAccountId,
		organizationId: organizationId,
	});
	if (userProjectRolesErr) throw userProjectRolesErr;

	log('Writing project...');
	const { error: projectErr, data: projectData } = await supabase
		.from('project')
		.insert({
			name: 'E2E Test Project',
			organizationId: organizationId,
		})
		.select('*');
	if (projectErr) throw projectErr;
	const projectId = projectData[0].id;

	log('Writing Sprint 1 (active)...');
	const { error: sprint1Err, data: sprint1Data } = await supabase
		.from('sprint')
		.insert({
			name: 'Sprint 1',
			projectId: projectId,
			isRunning: true,
			isActive: true,
		})
		.select('*');
	if (sprint1Err) throw sprint1Err;
	const sprint1Id = sprint1Data[0].id;

	log('Writing Story...');
	const { error: storyErr, data: story1Data } = await supabase
		.from('story')
		.insert({
			title: 'Story 1',
			sprintId: sprint1Id,
		})
		.select('*');
	if (storyErr) throw storyErr;
	const story1Id = story1Data[0].id;

	log('Writing Story2...');
	const { error: story2Err, data: story2Data } = await supabase
		.from('story')
		.insert({
			title: 'Story 2',
			sprintId: sprint1Id,
			sequence: 1,
		})
		.select('*');
	if (story2Err) throw story2Err;
	const story2Id = story2Data[0].id;

	log('Writing Task1...');
	await supabase.from('task').insert({
		title: 'Task 1',
		storyId: story1Id,
	});

	log('Writing Task2...');
	await supabase.from('task').insert({
		title: 'Task 2',
		storyId: story2Id,
	});

	log('Writing Sprint 2 (planned)...');
	const { error: sprint2Err, data: sprint2Data } = await supabase
		.from('sprint')
		.insert({
			name: 'Sprint 2',
			projectId: projectId,
		})
		.select('*');
	if (sprint2Err) throw sprint2Err;
	const sprint2Id = sprint2Data[0].id;

	log('Writing Story3...');
	const { error: story3Err } = await supabase.from('story').insert({
		title: 'Story 4',
		sprintId: sprint2Id,
		sequence: 1,
	});
	if (story3Err) throw story3Err;

	log('Writing Backlog "Sprint"...');
	const { error: backlogErr, data: backlogData } = await supabase
		.from('sprint')
		.insert({
			name: 'Backlog',
			projectId: projectId,
			isProjectBacklog: true,
		})
		.select('*');
	if (backlogErr) throw backlogErr;
	const backlogId = backlogData[0].id;

	log('Writing Story4...');
	const { error: story4Err } = await supabase.from('story').insert({
		title: 'Story 3',
		sprintId: backlogId,
		sequence: 1,
	});
	if (story4Err) throw story4Err;

	log('Writing Story5...');
	const { error: story5Err } = await supabase.from('story').insert({
		title: 'Story 5',
		sprintId: backlogId,
		sequence: 1,
	});
	if (story5Err) throw story5Err;

	log('Writing done!');
}

export default async function () {
	log('Setting up database...');
	try {
		await deleteAllData();
		await writeTestData();
		log('Setup complete 🎉');
	} catch (error) {
		log('Setup failed 😢');
		throw error;
	}
}

const log = (message: string) => console.info(`# db-setup # ${message}`);
