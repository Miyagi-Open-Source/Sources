import { expect, test } from '@playwright/test';
import { dataTestId } from './helpers.js';

test.describe('App', () => {
	test.beforeEach(async ({ page }) => {
		page.on('pageerror', (exception) => {
			console.error(`Uncaught exception: "${JSON.stringify(exception)}"`);
		});
		await page.goto('/', { waitUntil: 'networkidle' });
	});

	test('starts up and renders index', async ({ page }) => {
		expect(await page.textContent('h1')).toContain('Miyagi');
	});

	test('user can submit feedback', async ({ page }) => {
		await page.click(dataTestId('open-user-feedback-form'));
		await page.fill(dataTestId('feedback-message'), 'Test Feedback');
		await page.locator(dataTestId('feedback-data-consent')).check();
		await page.click(dataTestId('feedback-submit'));
		expect(await page.locator(dataTestId('feedback-affirmation')).textContent()).toContain('Thank you');
	});
});
