import { defineConfig } from 'histoire';
import { HstSvelte } from '@histoire/plugin-svelte';
import path from 'path';

// List of dependencies that should be inlined into the bundle
// FIXME: but @supabase/postgrest-js is not even in our package.json
const INLINE_DEPS = ['date-fns', '@supabase/postgrest-js'].map((it) => new RegExp(it));

export default defineConfig({
	plugins: [HstSvelte()],
	vite: {
		resolve: {
			alias: {
				$lib: path.resolve(__dirname, 'src/lib'),
				$app: path.resolve(__dirname, 'histoire/app'),
			},
		},
	},
	viteNodeInlineDeps: INLINE_DEPS,
	setupFile: 'histoire/setup.ts',
});
