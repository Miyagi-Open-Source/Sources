# Orga

- Dailys Mo-Fr 13:30 im [Discord](***) - Was war, was wird, was hält mich auf
- Montag: **Wochenplanung** mit Hilfe von [Github Projects](***)
- ~Jeden zweiten Freitag Retro, üblicherweise via Discord und [Miro Board](***)
