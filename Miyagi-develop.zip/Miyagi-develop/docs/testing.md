**Unit / Component Testing:**

- Funktionen und Komopnenten können mittels **Vitest** und **@testing-library** getestet werden

- Vitest als moderner ersatz für Jest

  - Der Vorteil ist, dass es auf Vite basiert: keine eigene Konfiguration für eine Testumgebung benötigt → daher sind Entwicklungs-, Produktions- und Test-Umgebung näher aneinander

- Innerhalb von Vitest testfiles kann **@testing-library/svelte** um Komponenten mittels JSDom zu rendern und zu testen

  - render funktion returned ein RenderResult, welches User-Interaktion-orientierte-Selektoren (i.e. getByText, getByRole) oder die Komponenten instzanz (um z.B. auf Events zu hören) enthält

  - Mit **@testing-library/user-event** können zu dem Nutzer events emuliert werden, um zum Beispiel Keyboard Navigation zu testen.

- Vitest lässt sich über den test key in der **vite.config.js** konfigurieren.

  - setupFiles: globale konfigurationen die bei jedem Test durchgeführt werden z.B. Mocken von $app/environment Sveltekit export.

  - environment: jsdom zum rendern von Komopnenten

  - reporters: default + junit (für GitHub Actions Test summary)

  - outputFile: Reporters schreiben dort rein. wird von GitHub Action Test summary ausgelesen.

  - exclude: e2e ordner ist für playwright bestimmt, der rest ist vom default aus den docs kopiert.

  - deps.inline: date-fns und supabase machen teilweise issues in vite umgebungen, welche hiermit umgangen werden können

**Playwright:** e2e Testing

- global setup + auth session: login a hardcoded test user via ui and save session in JSON. JSON gets used for each test afterwards.

- db-setup: Script zum Seeden der zentralen Test Supabase Datenbank Instanz

- e2e Tests werden auf der gesamten App inklusive (noch) zentraler Datenbank durchgeführt

  - Problematik mit parallelen Testläufen und bei Änderung der Datenstruktur

  - hier sollte auf eine lokale Supabase Instanz gewechselt werden (was evlt. komplexer ist)

- Helper für Drag and Drop und "waitForNetworkSettled"

- **playwright.config.ts**:

  - globalSetup: path to global setup file that gets called before anything else (path gets resolved with requrie.resolve)

  - use: options for tests. use authed session storage and save video on failure.

  - webServer: host the frontend for test

  - testMatch: run all files imporetd in /e2e/test-list.ts

  - reportes: default + junit for Github Actions Test summary

  - retries: 3 times in CI, otheriwise 0
