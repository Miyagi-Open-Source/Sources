# Accounts

Wir haben Accounts bei:

- Supabase (Datenbank)
- Vercel (Host / Previews)
- Github
- Cloudflare

Außerdem haben wir einen eigenen **Discord** Server, **Google Calendar**, **Miro Board** und **Miyagi**.

Sollten Zugangsdaten benötigt werden, bitte an Christian wenden.
