Vor der Entwicklung der UI wurde meist ein Mockup, also eine Visualisierung des gewollten Endergebnis erstellt. Dies is nützlich, um Absprachen und Feedback vor der eigentlichen Umsetzung zu ermöglichen, und im Team ein gemeinsames Ziel vor Augen zu haben. Umsetzung von Designs passiert mit (Post)CSS innerhalb unserer Svelte Komponenten.

- **Figma** für kollaborative Erstellung von visuellen UI Komponenten und Screen Mockups

- **Open Props** ist eine Sammlung von vordefinierten Design-Tokens, die mit CSS Custom Propertiers implementiert werden können.

  - Open Props bietet also eine Reihe von Farben, Gradients, Schatten, Größen, Animationen, etc. an, damit wir eine einheitliche Grundlage für unsere Designs und für unser CSS haben.

  - OpenProps Farben wurden in das Miyagi Figma Projekt des Clancy Digital Teams importiert, damit diese dort ebenfalls verwendet werden können.

- **Iconify bzw. Unplugin-Icons** werden für Icons genutzt. Wir haben uns bisher an die Google Material Design Icons gehalten, jedoch kann technisch gesehen jedes Iconify Paket verwendet werden, falls mal ein Icon fehlt. Unter icones.js.org kann eine Auflistung aller verfügbaren Icons gefunden werden und schnell z.B. als SVG kopiert werden, um diese in Figma einzufügen.

**Skills:**

- Prototyping und Mockups (z.B. mit Figma)

- Kreativität

- Verständnis für User Experience, Usability und Accessibility
