Technologien und Tools die wir nutzen und deren Zweck:

**Netlify:**

- CD

- Hosting

**GitHub:**

- Git Repo

- Code Review

- CI (Linting, Testing)

**Supabase**

- Authorization

- Datenbank + Realtime Updates

- DB Trigger und Funktionen

  - handle_new_user

  - set_addedToSprintAt

  - set_completedAt

  - setXYZDisplayId

  - setStoryStatus

  - updateStoryTaskCountTrigger

- Generieren von Typen via openapi-typescript

3 Instanzen: Prod, Dev & Test (die letzen beiden sollten evtl. in Zukunft auf lokale Supabase CLI gewechselt werden)

**SvelteKit:**

- Frontend UI

- Routing

- Datenanbindung über Stores (client-only)

- Svelte Preprocess: TypeScript, PostCSS (s.o.)

**Vitest:**

- unit testing

- **+ @testing-library:** component testing

**Playwright:** e2e Testing

- db-setup Script zum Seeden der Test Supabase Datenbank Instanz

**Histoire:** Komponenten in isolation erstellen und dokumentieren (Vite basierte Storybook alternative)

**Husky + lint-staged:** Git commit hook, verwendet folgende Tools, um den Code vor dem commit zu prüfen:

- **Prettier:** Code formatter

- **ESLint:** TS linter

- **Stylelint:** CSS linter

- **svelte-check:** Code and Type checker

**PostCSS:** CSS post processing

- autoprefixer

- nesting support

- **Open Props:** vorgefertigte CSS custom props für konsistente Styles

**Weitere Dependencies:**

- **svelte-dnd-action:** Drag and Drop Listen

- **svelte-popperjs:** Menu popover positioning

- **@tiptap:** headless WYSIWYG Editor

- **date-fns:** JavaScript Date Hilfsfunktionen

- **cross-env:** env variablen os-unabhängig in NPM scripten setzen

- **dotenv:** laden von der .env im db-setup.ts Script

- **ts-toolbelt:** utility types

- **unplugin-icons:** tree shakable Iconify icons
