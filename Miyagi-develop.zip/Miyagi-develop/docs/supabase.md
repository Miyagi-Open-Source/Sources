# Supabase

Wir verwenden als Datenbank für Miyagi aktuell [Supabase](app.supabase.com).

Wir haben 3 Instanzen:

- [Dev](***) - ***
- [Test](***) - ***
- [Prod](***) - *** (pro instanz)

Wie der Name schon vermuten lässt, ist die Dev Instanz für das Programmieren von neuen Features gedacht.
Sollten dafür Änderungen an der Datenbank vorgenommen wurden sein, müssen diese auf die anderen Instanzen übertragen werden, hierfür verwenden wir [DBeaver](https://dbeaver.io/download/). Nach der Installation von DBeaver muss zudem noch eine [PostgreSQL Engine](https://www.postgresql.org/download/) installiert werden. Die unter Windows mitgelieferte Engine kann unter Umständen leider nicht funktionieren. Wenn beides installiert ist, kann DBeaver gestartet werden und die Instanzen hinzugefügt werden, dafür in den oberen Menü auf "Database" -> "new Database Connection" gehen, hier "PostgreSQL" auswählen und mit "next" bestätigen. Im folgenden Menü müssen die Anmeldedaten für die jeweilige Superbase Instanz angegeben werden. Diese sind allgemein Host: `db.{die ausgewählte Instanz}.supabase.co` (z.B. `db.***.supabase.co`), Port: `6543` und Password: `Bei Denis anfragen`. Mit "finish" kann die Datenbankverbindung gespeichert werden. Im linken Panel sollte die Instanz nun als "postgres" zu sehen sein. Wenn wir nun Änderungen von einer Instanz auf eine andere bewegen wollen, navigieren wir zu der relevanten Stelle im linken Panel (z.B. `postgres -> Databases -> postgres -> Schemas -> public`) und wählen im Rechtsklick-Menü `Tools -> Backup`. Im folgenden Menü kann ausgewählt werden, welche Änderungen gebackuped werden sollen. Unten links müssen wir jedoch zuerst den `Local Client` zu den von uns installierten ändern, dafür im Dropdown-Menü "Browse" auswählen, auf "Add Home" gehen und den Pfad angeben, an dem Postgres installiert wurde (z.B. `C:\Program Files\PostgreSQL\14\bin`). Auf der nächsten Seite, "Backup Settings", muss der "Output folder pattern" angegeben werden, hier wird das Backup gespeichert. Mit Start wird nun das Backup erstellt.
Wenn alles gut gegangen ist, kann auf die gleiche Art und Weise auf einer anderen Instanz das Backup hochgeladen werden, nur das dafür statt "Backup", "Restore" ausgewählt werden muss.
