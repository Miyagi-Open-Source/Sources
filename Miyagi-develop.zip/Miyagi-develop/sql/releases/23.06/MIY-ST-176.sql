START TRANSACTION;
-- drop column vision if exists
ALTER TABLE public.project DROP COLUMN IF EXISTS vision;

-- add column vision
ALTER TABLE public.project ADD COLUMN vision text NULL;
COMMIT;