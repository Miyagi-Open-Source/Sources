START TRANSACTION;
ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_username_tag_key;
ALTER TABLE public.profiles DROP COLUMN IF EXISTS tag;
--  Change the contraint username_length to be: length of trimmed username to >= 1 and make username required
ALTER TABLE public.profiles ALTER COLUMN username SET NOT NULL;
ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS username_length;
ALTER TABLE public.profiles ADD CONSTRAINT username_length CHECK ((char_length(trim(username)) >= 1));


CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$


begin

  insert into public.profiles (id, username)
    values (new.id, new.raw_user_meta_data ->> 'name', 0);

  insert into public.organization (name, owner)
    values ((new.raw_user_meta_data ->> 'name') || E'\'s Workspace', new.id);

  return new;

end;
$function$
;

COMMIT;