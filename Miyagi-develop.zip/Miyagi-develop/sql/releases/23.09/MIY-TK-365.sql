START TRANSACTION;
ALTER TABLE public.organization ALTER COLUMN "owner" DROP DEFAULT;
ALTER TABLE public.organization ADD CONSTRAINT organization_name_length CHECK (char_length("name") >= 1);
COMMIT;