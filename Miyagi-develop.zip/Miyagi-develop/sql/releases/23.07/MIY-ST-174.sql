START TRANSACTION;
--ALTER TABLE public.project DROP CONSTRAINT IF EXISTS project_tag_uk;
--ALTER TABLE public.project DROP CONSTRAINT IF EXISTS project_tag_ck;
--ALTER TABLE public.project DROP COLUMN IF EXISTS tag;
--DROP FUNCTION IF EXISTS get_random_string;

CREATE OR REPLACE FUNCTION get_random_string(
        IN string_length integer default 3,
        IN possible_chars TEXT DEFAULT 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    ) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    output TEXT = '';
    i INT4;
    pos INT4;
BEGIN
    FOR i IN 1..string_length LOOP
        pos := 1 + cast( random() * ( length(possible_chars) - 1) as INT4 );
        output := output || substr(possible_chars, pos, 1);
    END LOOP;
    RETURN output;
END;
$$;

-- add column tag and set default value to random 3 uppercase letters string  (e.g. 'ABC')
--ALTER TABLE public.project ADD COLUMN tag varchar(3) NOT NULL DEFAULT upper(substring(md5(random()::text) from 1 for 3));
ALTER TABLE public.project ADD COLUMN tag varchar(3) NOT NULL DEFAULT get_random_string();
ALTER TABLE public.project ADD CONSTRAINT project_tag_uk UNIQUE (tag, "organizationId");
ALTER TABLE public.project ADD CONSTRAINT project_tag_ck CHECK (tag ~ '^[A-Z]{1,3}$');

COMMIT;