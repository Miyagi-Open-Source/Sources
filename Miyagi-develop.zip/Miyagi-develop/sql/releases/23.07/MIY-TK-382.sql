START TRANSACTION;

ALTER TABLE public.project DROP CONSTRAINT IF EXISTS "project_organizationId_fkey";
ALTER TABLE public.sprint DROP CONSTRAINT IF EXISTS "sprint_projectId_fkey";
ALTER TABLE public."userProjectRoles" DROP CONSTRAINT IF EXISTS "userProjectRoles_projectId_fkey";

ALTER TABLE public.project ADD	CONSTRAINT "project_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public.organization(id) ON DELETE CASCADE;
ALTER TABLE public.sprint ADD CONSTRAINT "sprint_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.project(id) ON DELETE CASCADE;
ALTER TABLE public."userProjectRoles" ADD CONSTRAINT "userProjectRoles_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public.project(id) ON DELETE cascade;

COMMIT;