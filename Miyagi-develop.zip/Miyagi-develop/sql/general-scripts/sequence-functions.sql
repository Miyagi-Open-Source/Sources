START TRANSACTION;
-- drop functions
drop function if exists sequence_create(text);
drop function if exists sequence_drop(text);
drop function if exists sequence_nextval(text);

-- Function to create a sequence
create or replace function sequence_drop(sequencename_input text)
returns void
-- alternative: return text
language plpgsql 
as $$  
BEGIN
  EXECUTE 'CREATE SEQUENCE ' || sequencename_input;
  -- return sequencename_input || ' created';
END;
$$;

-- Function to drop a sequence
create or replace function sequence_create(sequencename_input text)
returns void
-- alternative: return text
language plpgsql 
as $$  
BEGIN
  EXECUTE 'DROP SEQUENCE ' || sequencename_input;
  -- return sequencename_input || ' dropped';
END;
$$;

-- Function to get the next value of a sequence
create or replace function sequence_nextval(sequencename_input text )
returns int
language sql
as $$ 
  select nextval(sequencename_input); 
$$;

commit;