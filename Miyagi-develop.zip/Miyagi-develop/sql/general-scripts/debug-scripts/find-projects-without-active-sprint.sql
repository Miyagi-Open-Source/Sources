select "projectId" FROM public.sprint where "isActive" = false group by "projectId"
except  
select "projectId" FROM public.sprint where "isActive" = true group by "projectId";
