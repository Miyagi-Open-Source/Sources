const autoprefixer = require('autoprefixer');
const postcssNesting = require('postcss-nesting');
const postcssJitProps = require('postcss-jit-props');
const OpenProps = require('open-props');

const config = {
	plugins: [autoprefixer, postcssNesting, postcssJitProps(OpenProps)],
};

module.exports = config;
