import './panels.css';
import '../src/global.css';
