import { writable } from 'svelte/store';

export const page = writable({
	url: new URL('/backlog', 'https://localhost:6006/'),
});
