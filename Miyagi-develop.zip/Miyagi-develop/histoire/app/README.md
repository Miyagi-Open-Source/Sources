This is used by Histoire to mock the SvelteKit provided `$app` imports.
