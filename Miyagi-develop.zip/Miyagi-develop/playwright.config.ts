import type { PlaywrightTestConfig } from '@playwright/test';
import { createRequire } from 'module';

// @ts-ignore
const require = createRequire(import.meta.url);

const config: PlaywrightTestConfig = {
	globalSetup: require.resolve('./e2e/global-setup'),
	use: {
		// Tell all tests to load signed-in state from 'storageState.json'.
		storageState: 'storageState.json',
		video: 'retain-on-failure',
	},
	webServer: {
		command: 'pnpm run build && pnpm run preview --port 4000',
		port: 4000,
	},
	testMatch: '**/e2e/test.list.ts',
	reporter: [['list'], ['junit', { outputFile: 'reports/playwright.junit.xml' }]],
	retries: process.env.CI ? 3 : 0,
};

export default config;
